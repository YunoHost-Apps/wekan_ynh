(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var slugify = Package['yasaricli:slugify'].slugify;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var SHA256 = Package.sha.SHA256;
var Accounts = Package['accounts-base'].Accounts;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"wekan:wekan-ldap":{"server":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan_wekan-ldap/server/index.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.watch(require("./loginHandler"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ldap.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan_wekan-ldap/server/ldap.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  default: () => LDAP
});
let ldapjs;
module.watch(require("ldapjs"), {
  default(v) {
    ldapjs = v;
  }

}, 0);
let util;
module.watch(require("util"), {
  default(v) {
    util = v;
  }

}, 1);
let Bunyan;
module.watch(require("bunyan"), {
  default(v) {
    Bunyan = v;
  }

}, 2);
let log_debug, log_info, log_warn, log_error;
module.watch(require("./logger"), {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 3);

class LDAP {
  constructor() {
    this.ldapjs = ldapjs;
    this.connected = false;
    this.options = {
      host: this.constructor.settings_get('LDAP_HOST'),
      port: this.constructor.settings_get('LDAP_PORT'),
      Reconnect: this.constructor.settings_get('LDAP_RECONNECT'),
      timeout: this.constructor.settings_get('LDAP_TIMEOUT'),
      connect_timeout: this.constructor.settings_get('LDAP_CONNECT_TIMEOUT'),
      idle_timeout: this.constructor.settings_get('LDAP_IDLE_TIMEOUT'),
      encryption: this.constructor.settings_get('LDAP_ENCRYPTION'),
      ca_cert: this.constructor.settings_get('LDAP_CA_CERT'),
      reject_unauthorized: this.constructor.settings_get('LDAP_REJECT_UNAUTHORIZED') || false,
      Authentication: this.constructor.settings_get('LDAP_AUTHENTIFICATION'),
      Authentication_UserDN: this.constructor.settings_get('LDAP_AUTHENTIFICATION_USERDN'),
      Authentication_Password: this.constructor.settings_get('LDAP_AUTHENTIFICATION_PASSWORD'),
      Authentication_Fallback: this.constructor.settings_get('LDAP_LOGIN_FALLBACK'),
      BaseDN: this.constructor.settings_get('LDAP_BASEDN'),
      Internal_Log_Level: this.constructor.settings_get('INTERNAL_LOG_LEVEL'),
      User_Search_Filter: this.constructor.settings_get('LDAP_USER_SEARCH_FILTER'),
      User_Search_Scope: this.constructor.settings_get('LDAP_USER_SEARCH_SCOPE'),
      User_Search_Field: this.constructor.settings_get('LDAP_USER_SEARCH_FIELD'),
      Search_Page_Size: this.constructor.settings_get('LDAP_SEARCH_PAGE_SIZE'),
      Search_Size_Limit: this.constructor.settings_get('LDAP_SEARCH_SIZE_LIMIT'),
      group_filter_enabled: this.constructor.settings_get('LDAP_GROUP_FILTER_ENABLE'),
      group_filter_object_class: this.constructor.settings_get('LDAP_GROUP_FILTER_OBJECTCLASS'),
      group_filter_group_id_attribute: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_ID_ATTRIBUTE'),
      group_filter_group_member_attribute: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_MEMBER_ATTRIBUTE'),
      group_filter_group_member_format: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_MEMBER_FORMAT'),
      group_filter_group_name: this.constructor.settings_get('LDAP_GROUP_FILTER_GROUP_NAME')
    };
  }

  static settings_get(name, ...args) {
    let value = process.env[name];

    if (value !== undefined) {
      if (value === 'true' || value === 'false') {
        value = JSON.parse(value);
      } else if (value !== '' && !isNaN(value)) {
        value = Number(value);
      }

      return value;
    } else {
      log_warn(`Lookup for unset variable: ${name}`);
    }
  }

  connectSync(...args) {
    if (!this._connectSync) {
      this._connectSync = Meteor.wrapAsync(this.connectAsync, this);
    }

    return this._connectSync(...args);
  }

  searchAllSync(...args) {
    if (!this._searchAllSync) {
      this._searchAllSync = Meteor.wrapAsync(this.searchAllAsync, this);
    }

    return this._searchAllSync(...args);
  }

  connectAsync(callback) {
    log_info('Init setup');
    let replied = false;
    const connectionOptions = {
      url: `${this.options.host}:${this.options.port}`,
      timeout: this.options.timeout,
      connectTimeout: this.options.connect_timeout,
      idleTimeout: this.options.idle_timeout,
      reconnect: this.options.Reconnect
    };

    if (this.options.Internal_Log_Level !== 'disabled') {
      connectionOptions.log = new Bunyan({
        name: 'ldapjs',
        component: 'client',
        stream: process.stderr,
        level: this.options.Internal_Log_Level
      });
    }

    const tlsOptions = {
      rejectUnauthorized: this.options.reject_unauthorized
    };

    if (this.options.ca_cert && this.options.ca_cert !== '') {
      // Split CA cert into array of strings
      const chainLines = this.constructor.settings_get('LDAP_CA_CERT').split('\n');
      let cert = [];
      const ca = [];
      chainLines.forEach(line => {
        cert.push(line);

        if (line.match(/-END CERTIFICATE-/)) {
          ca.push(cert.join('\n'));
          cert = [];
        }
      });
      tlsOptions.ca = ca;
    }

    if (this.options.encryption === 'ssl') {
      connectionOptions.url = `ldaps://${connectionOptions.url}`;
      connectionOptions.tlsOptions = tlsOptions;
    } else {
      connectionOptions.url = `ldap://${connectionOptions.url}`;
    }

    log_info('Connecting', connectionOptions.url);
    log_debug(`connectionOptions${util.inspect(connectionOptions)}`);
    this.client = ldapjs.createClient(connectionOptions);
    this.bindSync = Meteor.wrapAsync(this.client.bind, this.client);
    this.client.on('error', error => {
      log_error('connection', error);

      if (replied === false) {
        replied = true;
        callback(error, null);
      }
    });
    this.client.on('idle', () => {
      log_info('Idle');
      this.disconnect();
    });
    this.client.on('close', () => {
      log_info('Closed');
    });

    if (this.options.encryption === 'tls') {
      // Set host parameter for tls.connect which is used by ldapjs starttls. This shouldn't be needed in newer nodejs versions (e.g v5.6.0).
      // https://github.com/RocketChat/Rocket.Chat/issues/2035
      // https://github.com/mcavage/node-ldapjs/issues/349
      tlsOptions.host = this.options.host;
      log_info('Starting TLS');
      log_debug('tlsOptions', tlsOptions);
      this.client.starttls(tlsOptions, null, (error, response) => {
        if (error) {
          log_error('TLS connection', error);

          if (replied === false) {
            replied = true;
            callback(error, null);
          }

          return;
        }

        log_info('TLS connected');
        this.connected = true;

        if (replied === false) {
          replied = true;
          callback(null, response);
        }
      });
    } else {
      this.client.on('connect', response => {
        log_info('LDAP connected');
        this.connected = true;

        if (replied === false) {
          replied = true;
          callback(null, response);
        }
      });
    }

    setTimeout(() => {
      if (replied === false) {
        log_error('connection time out', connectionOptions.connectTimeout);
        replied = true;
        callback(new Error('Timeout'));
      }
    }, connectionOptions.connectTimeout);
  }

  getUserFilter(username) {
    const filter = [];

    if (this.options.User_Search_Filter !== '') {
      if (this.options.User_Search_Filter[0] === '(') {
        filter.push(`${this.options.User_Search_Filter}`);
      } else {
        filter.push(`(${this.options.User_Search_Filter})`);
      }
    }

    const usernameFilter = this.options.User_Search_Field.split(',').map(item => `(${item}=${username})`);

    if (usernameFilter.length === 0) {
      log_error('LDAP_LDAP_User_Search_Field not defined');
    } else if (usernameFilter.length === 1) {
      filter.push(`${usernameFilter[0]}`);
    } else {
      filter.push(`(|${usernameFilter.join('')})`);
    }

    return `(&${filter.join('')})`;
  }

  bindIfNecessary() {
    if (this.domainBinded === true) {
      return;
    }

    if (this.options.Authentication !== true) {
      return;
    }

    log_info('Binding UserDN', this.options.Authentication_UserDN);
    this.bindSync(this.options.Authentication_UserDN, this.options.Authentication_Password);
    this.domainBinded = true;
  }

  searchUsersSync(username, page) {
    this.bindIfNecessary();
    const searchOptions = {
      filter: this.getUserFilter(username),
      scope: this.options.User_Search_Scope || 'sub',
      sizeLimit: this.options.Search_Size_Limit
    };

    if (this.options.Search_Page_Size > 0) {
      searchOptions.paged = {
        pageSize: this.options.Search_Page_Size,
        pagePause: !!page
      };
    }

    log_info('Searching user', username);
    log_debug('searchOptions', searchOptions);
    log_debug('BaseDN', this.options.BaseDN);

    if (page) {
      return this.searchAllPaged(this.options.BaseDN, searchOptions, page);
    }

    return this.searchAllSync(this.options.BaseDN, searchOptions);
  }

  getUserByIdSync(id, attribute) {
    this.bindIfNecessary();
    const Unique_Identifier_Field = this.constructor.settings_get('LDAP_UNIQUE_IDENTIFIER_FIELD').split(',');
    let filter;

    if (attribute) {
      filter = new this.ldapjs.filters.EqualityFilter({
        attribute,
        value: new Buffer(id, 'hex')
      });
    } else {
      const filters = [];
      Unique_Identifier_Field.forEach(item => {
        filters.push(new this.ldapjs.filters.EqualityFilter({
          attribute: item,
          value: new Buffer(id, 'hex')
        }));
      });
      filter = new this.ldapjs.filters.OrFilter({
        filters
      });
    }

    const searchOptions = {
      filter,
      scope: 'sub'
    };
    log_info('Searching by id', id);
    log_debug('search filter', searchOptions.filter.toString());
    log_debug('BaseDN', this.options.BaseDN);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return;
    }

    if (result.length > 1) {
      log_error('Search by id', id, 'returned', result.length, 'records');
    }

    return result[0];
  }

  getUserByUsernameSync(username) {
    this.bindIfNecessary();
    const searchOptions = {
      filter: this.getUserFilter(username),
      scope: this.options.User_Search_Scope || 'sub'
    };
    log_info('Searching user', username);
    log_debug('searchOptions', searchOptions);
    log_debug('BaseDN', this.options.BaseDN);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return;
    }

    if (result.length > 1) {
      log_error('Search by username', username, 'returned', result.length, 'records');
    }

    return result[0];
  }

  getUserGroups(username, ldapUser) {
    if (!this.options.group_filter_enabled) {
      return true;
    }

    const filter = ['(&'];

    if (this.options.group_filter_object_class !== '') {
      filter.push(`(objectclass=${this.options.group_filter_object_class})`);
    }

    if (this.options.group_filter_group_member_attribute !== '') {
      const format_value = ldapUser[this.options.group_filter_group_member_format];

      if (format_value) {
        filter.push(`(${this.options.group_filter_group_member_attribute}=${format_value})`);
      }
    }

    filter.push(')');
    const searchOptions = {
      filter: filter.join('').replace(/#{username}/g, username),
      scope: 'sub'
    };
    log_debug('Group list filter LDAP:', searchOptions.filter);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return [];
    }

    const grp_identifier = this.options.group_filter_group_id_attribute || 'cn';
    const groups = [];
    result.map(item => {
      groups.push(item[grp_identifier]);
    });
    log_debug(`Groups: ${groups.join(', ')}`);
    return groups;
  }

  isUserInGroup(username, ldapUser) {
    if (!this.options.group_filter_enabled) {
      return true;
    }

    const grps = this.getUserGroups(username, ldapUser);
    const filter = ['(&'];

    if (this.options.group_filter_object_class !== '') {
      filter.push(`(objectclass=${this.options.group_filter_object_class})`);
    }

    if (this.options.group_filter_group_member_attribute !== '') {
      const format_value = ldapUser[this.options.group_filter_group_member_format];

      if (format_value) {
        filter.push(`(${this.options.group_filter_group_member_attribute}=${format_value})`);
      }
    }

    if (this.options.group_filter_group_id_attribute !== '') {
      filter.push(`(${this.options.group_filter_group_id_attribute}=${this.options.group_filter_group_name})`);
    }

    filter.push(')');
    const searchOptions = {
      filter: filter.join('').replace(/#{username}/g, username),
      scope: 'sub'
    };
    log_debug('Group filter LDAP:', searchOptions.filter);
    const result = this.searchAllSync(this.options.BaseDN, searchOptions);

    if (!Array.isArray(result) || result.length === 0) {
      return false;
    }

    return true;
  }

  extractLdapEntryData(entry) {
    const values = {
      _raw: entry.raw
    };
    Object.keys(values._raw).forEach(key => {
      const value = values._raw[key];

      if (!['thumbnailPhoto', 'jpegPhoto'].includes(key)) {
        if (value instanceof Buffer) {
          values[key] = value.toString();
        } else {
          values[key] = value;
        }
      }
    });
    return values;
  }

  searchAllPaged(BaseDN, options, page) {
    this.bindIfNecessary();

    const processPage = ({
      entries,
      title,
      end,
      next
    }) => {
      log_info(title); // Force LDAP idle to wait the record processing

      this.client._updateIdle(true);

      page(null, entries, {
        end,
        next: () => {
          // Reset idle timer
          this.client._updateIdle();

          next && next();
        }
      });
    };

    this.client.search(BaseDN, options, (error, res) => {
      if (error) {
        log_error(error);
        page(error);
        return;
      }

      res.on('error', error => {
        log_error(error);
        page(error);
        return;
      });
      let entries = [];
      const internalPageSize = options.paged && options.paged.pageSize > 0 ? options.paged.pageSize * 2 : 500;
      res.on('searchEntry', entry => {
        entries.push(this.extractLdapEntryData(entry));

        if (entries.length >= internalPageSize) {
          processPage({
            entries,
            title: 'Internal Page',
            end: false
          });
          entries = [];
        }
      });
      res.on('page', (result, next) => {
        if (!next) {
          this.client._updateIdle(true);

          processPage({
            entries,
            title: 'Final Page',
            end: true
          });
        } else if (entries.length) {
          log_info('Page');
          processPage({
            entries,
            title: 'Page',
            end: false,
            next
          });
          entries = [];
        }
      });
      res.on('end', () => {
        if (entries.length) {
          processPage({
            entries,
            title: 'Final Page',
            end: true
          });
          entries = [];
        }
      });
    });
  }

  searchAllAsync(BaseDN, options, callback) {
    this.bindIfNecessary();
    this.client.search(BaseDN, options, (error, res) => {
      if (error) {
        log_error(error);
        callback(error);
        return;
      }

      res.on('error', error => {
        log_error(error);
        callback(error);
        return;
      });
      const entries = [];
      res.on('searchEntry', entry => {
        entries.push(this.extractLdapEntryData(entry));
      });
      res.on('end', () => {
        log_info('Search result count', entries.length);
        callback(null, entries);
      });
    });
  }

  authSync(dn, password) {
    log_info('Authenticating', dn);

    try {
      if (password === '') {
        throw new Error('Password is not provided');
      }

      this.bindSync(dn, password);
      log_info('Authenticated', dn);
      return true;
    } catch (error) {
      log_info('Not authenticated', dn);
      log_debug('error', error);
      return false;
    }
  }

  disconnect() {
    this.connected = false;
    this.domainBinded = false;
    log_info('Disconecting');
    this.client.unbind();
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan_wekan-ldap/server/logger.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
    log: () => log,
    log_debug: () => log_debug,
    log_info: () => log_info,
    log_warn: () => log_warn,
    log_error: () => log_error
});
const isLogEnabled = process.env.LDAP_LOG_ENABLED === 'true';

function log(level, message, data) {
    if (isLogEnabled) {
        console.log(`[${level}] ${message} ${data ? JSON.stringify(data, null, 2) : ''}`);
    }
}

function log_debug(...args) {
    log('DEBUG', ...args);
}

function log_info(...args) {
    log('INFO', ...args);
}

function log_warn(...args) {
    log('WARN', ...args);
}

function log_error(...args) {
    log('ERROR', ...args);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginHandler.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan_wekan-ldap/server/loginHandler.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let slug, getLdapUsername, getLdapEmail, getLdapUserUniqueID, syncUserData, addLdapUser;
module.watch(require("./sync"), {
  slug(v) {
    slug = v;
  },

  getLdapUsername(v) {
    getLdapUsername = v;
  },

  getLdapEmail(v) {
    getLdapEmail = v;
  },

  getLdapUserUniqueID(v) {
    getLdapUserUniqueID = v;
  },

  syncUserData(v) {
    syncUserData = v;
  },

  addLdapUser(v) {
    addLdapUser = v;
  }

}, 0);
let LDAP;
module.watch(require("./ldap"), {
  default(v) {
    LDAP = v;
  }

}, 1);
let log_debug, log_info, log_warn, log_error;
module.watch(require("./logger"), {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 2);

function fallbackDefaultAccountSystem(bind, username, password) {
  if (typeof username === 'string') {
    if (username.indexOf('@') === -1) {
      username = {
        username
      };
    } else {
      username = {
        email: username
      };
    }
  }

  log_info('Fallback to default account system: ', username);
  const loginRequest = {
    user: username,
    password: {
      digest: SHA256(password),
      algorithm: 'sha-256'
    }
  };
  log_debug('Fallback options: ', loginRequest);
  return Accounts._runLoginHandlers(bind, loginRequest);
}

Accounts.registerLoginHandler('ldap', function (loginRequest) {
  if (!loginRequest.ldap || !loginRequest.ldapOptions) {
    return undefined;
  }

  log_info('Init LDAP login', loginRequest.username);

  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    return fallbackDefaultAccountSystem(this, loginRequest.username, loginRequest.ldapPass);
  }

  const self = this;
  const ldap = new LDAP();
  let ldapUser;

  try {
    ldap.connectSync();
    const users = ldap.searchUsersSync(loginRequest.username);

    if (users.length !== 1) {
      log_info('Search returned', users.length, 'record(s) for', loginRequest.username);
      throw new Error('User not Found');
    }

    if (ldap.authSync(users[0].dn, loginRequest.ldapPass) === true) {
      if (ldap.isUserInGroup(loginRequest.username, users[0])) {
        ldapUser = users[0];
      } else {
        throw new Error('User not in a valid group');
      }
    } else {
      log_info('Wrong password for', loginRequest.username);
    }
  } catch (error) {
    log_error(error);
  }

  if (ldapUser === undefined) {
    if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') === true) {
      return fallbackDefaultAccountSystem(self, loginRequest.username, loginRequest.ldapPass);
    }

    throw new Meteor.Error('LDAP-login-error', `LDAP Authentication failed with provided username [${loginRequest.username}]`);
  } // Look to see if user already exists


  let userQuery;
  const Unique_Identifier_Field = getLdapUserUniqueID(ldapUser);
  let user; // Attempt to find user by unique identifier

  if (Unique_Identifier_Field) {
    userQuery = {
      'services.ldap.id': Unique_Identifier_Field.value
    };
    log_info('Querying user');
    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Attempt to find user by username


  let username;
  let email;

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
    username = slug(getLdapUsername(ldapUser));
  } else {
    username = slug(loginRequest.username);
  }

  if (LDAP.settings_get('LDAP_EMAIL_FIELD') !== '') {
    email = getLdapEmail(ldapUser);
  }

  if (!user) {
    if (email && LDAP.settings_get('LDAP_EMAIL_MATCH_REQUIRE') === true) {
      if (LDAP.settings_get('LDAP_EMAIL_MATCH_VERIFIED') === true) {
        userQuery = {
          '_id': username,
          'emails.0.address': email,
          'emails.0.verified': true
        };
      } else {
        userQuery = {
          '_id': username,
          'emails.0.address': email
        };
      }
    } else {
      userQuery = {
        username
      };
    }

    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Attempt to find user by e-mail address only


  if (!user && email && LDAP.settings_get('LDAP_EMAIL_MATCH_ENABLE') === true) {
    log_info('No user exists with username', username, '- attempting to find by e-mail address instead');

    if (LDAP.settings_get('LDAP_EMAIL_MATCH_VERIFIED') === true) {
      userQuery = {
        'emails.0.address': email,
        'emails.0.verified': true
      };
    } else {
      userQuery = {
        'emails.0.address': email
      };
    }

    log_debug('userQuery', userQuery);
    user = Meteor.users.findOne(userQuery);
  } // Login user if they exist


  if (user) {
    if (user.authenticationMethod !== 'ldap' && LDAP.settings_get('LDAP_MERGE_EXISTING_USERS') !== true) {
      log_info('User exists without "authenticationMethod : ldap"');
      throw new Meteor.Error('LDAP-login-error', `LDAP Authentication succeded, but there's already a matching Wekan account in MongoDB`);
    }

    log_info('Logging user');

    const stampedToken = Accounts._generateStampedLoginToken();

    const update_data = {
      $push: {
        'services.resume.loginTokens': Accounts._hashStampedToken(stampedToken)
      }
    };

    if (LDAP.settings_get('LDAP_SYNC_GROUP_ROLES') === true) {
      log_debug('Updating Groups/Roles');
      const groups = ldap.getUserGroups(username, ldapUser);

      if (groups.length > 0) {
        Roles.setUserRoles(user._id, groups);
        log_info(`Updated roles to:${groups.join(',')}`);
      }
    }

    Meteor.users.update(user._id, update_data);
    syncUserData(user, ldapUser);

    if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') === true) {
      Accounts.setPassword(user._id, loginRequest.ldapPass, {
        logout: false
      });
    }

    return {
      userId: user._id,
      token: stampedToken.token
    };
  } // Create new user


  log_info('User does not exist, creating', username);

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') === '') {
    username = undefined;
  }

  if (LDAP.settings_get('LDAP_LOGIN_FALLBACK') !== true) {
    loginRequest.ldapPass = undefined;
  }

  const result = addLdapUser(ldapUser, username, loginRequest.ldapPass);

  if (LDAP.settings_get('LDAP_SYNC_GROUP_ROLES') === true) {
    const groups = ldap.getUserGroups(username, ldapUser);

    if (groups.length > 0) {
      Roles.setUserRoles(result.userId, groups);
      log_info(`Set roles to:${groups.join(',')}`);
    }
  }

  if (result instanceof Error) {
    throw result;
  }

  return result;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sync.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/wekan_wekan-ldap/server/sync.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  slug: () => slug,
  getPropertyValue: () => getPropertyValue,
  getLdapUsername: () => getLdapUsername,
  getLdapEmail: () => getLdapEmail,
  getLdapFullname: () => getLdapFullname,
  getLdapUserUniqueID: () => getLdapUserUniqueID,
  getDataToSyncUserData: () => getDataToSyncUserData,
  syncUserData: () => syncUserData,
  addLdapUser: () => addLdapUser,
  importNewUsers: () => importNewUsers
});

let _;

module.watch(require("underscore"), {
  default(v) {
    _ = v;
  }

}, 0);
let LDAP;
module.watch(require("./ldap"), {
  default(v) {
    LDAP = v;
  }

}, 1);
let log_debug, log_info, log_warn, log_error;
module.watch(require("./logger"), {
  log_debug(v) {
    log_debug = v;
  },

  log_info(v) {
    log_info = v;
  },

  log_warn(v) {
    log_warn = v;
  },

  log_error(v) {
    log_error = v;
  }

}, 2);
Object.defineProperty(Object.prototype, "getLDAPValue", {
  value: function (prop) {
    const self = this;

    for (let key in self) {
      if (key.toLowerCase() == prop.toLowerCase()) {
        return self[key];
      }
    }
  },
  enumerable: false
});

function slug(text) {
  if (LDAP.settings_get('LDAP_UTF8_NAMES_SLUGIFY') !== true) {
    return text;
  }

  text = slugify(text, '.');
  return text.replace(/[^0-9a-z-_.]/g, '');
}

function templateVarHandler(variable, object) {
  const templateRegex = /#{([\w\-]+)}/gi;
  let match = templateRegex.exec(variable);
  let tmpVariable = variable;

  if (match == null) {
    if (!object.hasOwnProperty(variable)) {
      return;
    }

    return object[variable];
  } else {
    while (match != null) {
      const tmplVar = match[0];
      const tmplAttrName = match[1];

      if (!object.hasOwnProperty(tmplAttrName)) {
        return;
      }

      const attrVal = object[tmplAttrName];
      tmpVariable = tmpVariable.replace(tmplVar, attrVal);
      match = templateRegex.exec(variable);
    }

    return tmpVariable;
  }
}

function getPropertyValue(obj, key) {
  try {
    return _.reduce(key.split('.'), (acc, el) => acc[el], obj);
  } catch (err) {
    return undefined;
  }
}

function getLdapUsername(ldapUser) {
  const usernameField = LDAP.settings_get('LDAP_USERNAME_FIELD');

  if (usernameField.indexOf('#{') > -1) {
    return usernameField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(usernameField);
}

function getLdapEmail(ldapUser) {
  const emailField = LDAP.settings_get('LDAP_EMAIL_FIELD');

  if (emailField.indexOf('#{') > -1) {
    return emailField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(emailField);
}

function getLdapFullname(ldapUser) {
  const fullnameField = LDAP.settings_get('LDAP_FULLNAME_FIELD');

  if (fullnameField.indexOf('#{') > -1) {
    return fullnameField.replace(/#{(.+?)}/g, function (match, field) {
      return ldapUser.getLDAPValue(field);
    });
  }

  return ldapUser.getLDAPValue(fullnameField);
}

function getLdapUserUniqueID(ldapUser) {
  let Unique_Identifier_Field = LDAP.settings_get('LDAP_UNIQUE_IDENTIFIER_FIELD');

  if (Unique_Identifier_Field !== '') {
    Unique_Identifier_Field = Unique_Identifier_Field.replace(/\s/g, '').split(',');
  } else {
    Unique_Identifier_Field = [];
  }

  let User_Search_Field = LDAP.settings_get('LDAP_USER_SEARCH_FIELD');

  if (User_Search_Field !== '') {
    User_Search_Field = User_Search_Field.replace(/\s/g, '').split(',');
  } else {
    User_Search_Field = [];
  }

  Unique_Identifier_Field = Unique_Identifier_Field.concat(User_Search_Field);

  if (Unique_Identifier_Field.length > 0) {
    Unique_Identifier_Field = Unique_Identifier_Field.find(field => {
      return !_.isEmpty(ldapUser._raw.getLDAPValue(field));
    });

    if (Unique_Identifier_Field) {
      log_debug(`Identifying user with: ${Unique_Identifier_Field}`);
      Unique_Identifier_Field = {
        attribute: Unique_Identifier_Field,
        value: ldapUser._raw.getLDAPValue(Unique_Identifier_Field).toString('hex')
      };
    }

    return Unique_Identifier_Field;
  }
}

function getDataToSyncUserData(ldapUser, user) {
  const syncUserData = LDAP.settings_get('LDAP_SYNC_USER_DATA');
  const syncUserDataFieldMap = LDAP.settings_get('LDAP_SYNC_USER_DATA_FIELDMAP').trim();
  const userData = {};

  if (syncUserData && syncUserDataFieldMap) {
    const whitelistedUserFields = ['email', 'name', 'customFields'];
    const fieldMap = JSON.parse(syncUserDataFieldMap);
    const emailList = [];

    _.map(fieldMap, function (userField, ldapField) {
      log_debug(`Mapping field ${ldapField} -> ${userField}`);

      switch (userField) {
        case 'email':
          if (!ldapUser.hasOwnProperty(ldapField)) {
            log_debug(`user does not have attribute: ${ldapField}`);
            return;
          }

          if (_.isObject(ldapUser[ldapField])) {
            _.map(ldapUser[ldapField], function (item) {
              emailList.push({
                address: item,
                verified: true
              });
            });
          } else {
            emailList.push({
              address: ldapUser[ldapField],
              verified: true
            });
          }

          break;

        default:
          const [outerKey, innerKeys] = userField.split(/\.(.+)/);

          if (!_.find(whitelistedUserFields, el => el === outerKey)) {
            log_debug(`user attribute not whitelisted: ${userField}`);
            return;
          }

          if (outerKey === 'customFields') {
            let customFieldsMeta;

            try {
              customFieldsMeta = JSON.parse(LDAP.settings_get('Accounts_CustomFields'));
            } catch (e) {
              log_debug('Invalid JSON for Custom Fields');
              return;
            }

            if (!getPropertyValue(customFieldsMeta, innerKeys)) {
              log_debug(`user attribute does not exist: ${userField}`);
              return;
            }
          }

          const tmpUserField = getPropertyValue(user, userField);
          const tmpLdapField = templateVarHandler(ldapField, ldapUser);

          if (tmpLdapField && tmpUserField !== tmpLdapField) {
            // creates the object structure instead of just assigning 'tmpLdapField' to
            // 'userData[userField]' in order to avoid the "cannot use the part (...)
            // to traverse the element" (MongoDB) error that can happen. Do not handle
            // arrays.
            // TODO: Find a better solution.
            const dKeys = userField.split('.');

            const lastKey = _.last(dKeys);

            _.reduce(dKeys, (obj, currKey) => currKey === lastKey ? obj[currKey] = tmpLdapField : obj[currKey] = obj[currKey] || {}, userData);

            log_debug(`user.${userField} changed to: ${tmpLdapField}`);
          }

      }
    });

    if (emailList.length > 0) {
      if (JSON.stringify(user.emails) !== JSON.stringify(emailList)) {
        userData.emails = emailList;
      }
    }
  }

  const uniqueId = getLdapUserUniqueID(ldapUser);

  if (uniqueId && (!user.services || !user.services.ldap || user.services.ldap.id !== uniqueId.value || user.services.ldap.idAttribute !== uniqueId.attribute)) {
    userData['services.ldap.id'] = uniqueId.value;
    userData['services.ldap.idAttribute'] = uniqueId.attribute;
  }

  if (user.authenticationMethod !== 'ldap') {
    userData.ldap = true;
  }

  if (_.size(userData)) {
    return userData;
  }
}

function syncUserData(user, ldapUser) {
  log_info('Syncing user data');
  log_debug('user', {
    'email': user.email,
    '_id': user._id
  }); // log_debug('ldapUser', ldapUser.object);

  if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
    const username = slug(getLdapUsername(ldapUser));

    if (user && user._id && username !== user.username) {
      log_info('Syncing user username', user.username, '->', username);
      Meteor.users.findOne({
        _id: user._id
      }, {
        $set: {
          username
        }
      });
    }
  }

  if (LDAP.settings_get('LDAP_FULLNAME_FIELD') !== '') {
    const fullname = getLdapFullname(ldapUser);
    log_debug('fullname=', fullname);

    if (user && user._id && fullname !== '') {
      log_info('Syncing user fullname:', fullname);
      Meteor.users.update({
        _id: user._id
      }, {
        $set: {
          'profile.fullname': fullname
        }
      });
    }
  }
}

function addLdapUser(ldapUser, username, password) {
  const uniqueId = getLdapUserUniqueID(ldapUser);
  const userObject = {};

  if (username) {
    userObject.username = username;
  }

  const userData = getDataToSyncUserData(ldapUser, {});

  if (userData && userData.emails && userData.emails[0] && userData.emails[0].address) {
    if (Array.isArray(userData.emails[0].address)) {
      userObject.email = userData.emails[0].address[0];
    } else {
      userObject.email = userData.emails[0].address;
    }
  } else if (ldapUser.mail && ldapUser.mail.indexOf('@') > -1) {
    userObject.email = ldapUser.mail;
  } else if (LDAP.settings_get('LDAP_DEFAULT_DOMAIN') !== '') {
    userObject.email = `${username || uniqueId.value}@${LDAP.settings_get('LDAP_DEFAULT_DOMAIN')}`;
  } else {
    const error = new Meteor.Error('LDAP-login-error', 'LDAP Authentication succeded, there is no email to create an account. Have you tried setting your Default Domain in LDAP Settings?');
    log_error(error);
    throw error;
  }

  log_debug('New user data', userObject);

  if (password) {
    userObject.password = password;
  }

  try {
    // This creates the account with password service
    userObject.ldap = true;
    userObject._id = Accounts.createUser(userObject); // Add the services.ldap identifiers

    Meteor.users.update({
      _id: userObject._id
    }, {
      $set: {
        'services.ldap': {
          id: uniqueId.value
        },
        'emails.0.verified': true,
        'authenticationMethod': 'ldap'
      }
    });
  } catch (error) {
    log_error('Error creating user', error);
    return error;
  }

  syncUserData(userObject, ldapUser);
  return {
    userId: userObject._id
  };
}

function importNewUsers(ldap) {
  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    log_error('Can\'t run LDAP Import, LDAP is disabled');
    return;
  }

  if (!ldap) {
    ldap = new LDAP();
    ldap.connectSync();
  }

  let count = 0;
  ldap.searchUsersSync('*', Meteor.bindEnvironment((error, ldapUsers, {
    next,
    end
  } = {}) => {
    if (error) {
      throw error;
    }

    ldapUsers.forEach(ldapUser => {
      count++;
      const uniqueId = getLdapUserUniqueID(ldapUser); // Look to see if user already exists

      const userQuery = {
        'services.ldap.id': uniqueId.value
      };
      log_debug('userQuery', userQuery);
      let username;

      if (LDAP.settings_get('LDAP_USERNAME_FIELD') !== '') {
        username = slug(getLdapUsername(ldapUser));
      } // Add user if it was not added before


      let user = Meteor.users.findOne(userQuery);

      if (!user && username && LDAP.settings_get('LDAP_MERGE_EXISTING_USERS') === true) {
        const userQuery = {
          username
        };
        log_debug('userQuery merge', userQuery);
        user = Meteor.users.findOne(userQuery);

        if (user) {
          syncUserData(user, ldapUser);
        }
      }

      if (!user) {
        addLdapUser(ldapUser, username);
      }

      if (count % 100 === 0) {
        log_info('Import running. Users imported until now:', count);
      }
    });

    if (end) {
      log_info('Import finished. Users imported:', count);
    }

    next(count);
  }));
}

function sync() {
  if (LDAP.settings_get('LDAP_ENABLE') !== true) {
    return;
  }

  const ldap = new LDAP();

  try {
    ldap.connectSync();
    let users;

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_KEEP_EXISTANT_USERS_UPDATED') === true) {
      users = Meteor.users.find({
        'services.ldap': {
          $exists: true
        }
      });
    }

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_IMPORT_NEW_USERS') === true) {
      importNewUsers(ldap);
    }

    if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_KEEP_EXISTANT_USERS_UPDATED') === true) {
      users.forEach(function (user) {
        let ldapUser;

        if (user.services && user.services.ldap && user.services.ldap.id) {
          ldapUser = ldap.getUserByIdSync(user.services.ldap.id, user.services.ldap.idAttribute);
        } else {
          ldapUser = ldap.getUserByUsernameSync(user.username);
        }

        if (ldapUser) {
          syncUserData(user, ldapUser);
        } else {
          log_info('Can\'t sync user', user.username);
        }
      });
    }
  } catch (error) {
    log_error(error);
    return error;
  }

  return true;
}

const jobName = 'LDAP_Sync';

const addCronJob = _.debounce(Meteor.bindEnvironment(function addCronJobDebounced() {
  if (LDAP.settings_get('LDAP_BACKGROUND_SYNC') !== true) {
    log_info('Disabling LDAP Background Sync');

    if (SyncedCron.nextScheduledAtDate(jobName)) {
      SyncedCron.remove(jobName);
    }

    return;
  }

  if (LDAP.settings_get('LDAP_BACKGROUND_SYNC_INTERVAL')) {
    log_info('Enabling LDAP Background Sync');
    SyncedCron.add({
      name: jobName,
      schedule: parser => parser.text(LDAP.settings_get('LDAP_BACKGROUND_SYNC_INTERVAL')),

      job() {
        sync();
      }

    });
    SyncedCron.start();
  }
}), 500);

Meteor.startup(() => {
  Meteor.defer(() => {
    LDAP.settings_get('LDAP_BACKGROUND_SYNC', addCronJob);
    LDAP.settings_get('LDAP_BACKGROUND_SYNC_INTERVAL', addCronJob);
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"ldapjs":{"package.json":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// .npm/package/node_modules/ldapjs/package.json                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.name = "ldapjs";
exports.version = "1.0.2";
exports.main = "lib/index.js";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan_wekan-ldap/node_modules/ldapjs/lib/index.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Copyright 2011 Mark Cavage, Inc.  All rights reserved.

var Logger = require('bunyan');

var client = require('./client');
var Attribute = require('./attribute');
var Change = require('./change');
var Protocol = require('./protocol');
var Server = require('./server');

var assert = require('assert');
var controls = require('./controls');
var persistentSearch = require('./persistent_search');
var dn = require('./dn');
var errors = require('./errors');
var filters = require('./filters');
var messages = require('./messages');
var url = require('./url');


///--- API

module.exports = {
  Client: client.Client,
  createClient: client.createClient,

  Server: Server,
  createServer: function (options) {
    if (options === undefined)
      options = {};

    if (typeof (options) !== 'object')
      throw new TypeError('options (object) required');

    if (!options.log) {
      options.log = new Logger({
        name: 'ldapjs',
        component: 'client',
        stream: process.stderr
      });
    }

    return new Server(options);
  },

  Attribute: Attribute,
  Change: Change,

  dn: dn,
  DN: dn.DN,
  RDN: dn.RDN,
  parseDN: dn.parse,

  persistentSearch: persistentSearch,
  PersistentSearchCache: persistentSearch.PersistentSearchCache,

  filters: filters,
  parseFilter: filters.parseString,

  url: url,
  parseURL: url.parse
};


///--- Export all the childrenz

var k;

for (k in Protocol) {
  if (Protocol.hasOwnProperty(k))
    module.exports[k] = Protocol[k];
}

for (k in messages) {
  if (messages.hasOwnProperty(k))
    module.exports[k] = messages[k];
}

for (k in controls) {
  if (controls.hasOwnProperty(k))
    module.exports[k] = controls[k];
}

for (k in filters) {
  if (filters.hasOwnProperty(k)) {
    if (k !== 'parse' && k !== 'parseString')
      module.exports[k] = filters[k];
  }
}

for (k in errors) {
  if (errors.hasOwnProperty(k)) {
    module.exports[k] = errors[k];
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"bunyan":{"package.json":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// .npm/package/node_modules/bunyan/package.json                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.name = "bunyan";
exports.version = "1.8.12";
exports.main = "./lib/bunyan.js";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"bunyan.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/wekan_wekan-ldap/node_modules/bunyan/lib/bunyan.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**
 * Copyright (c) 2017 Trent Mick.
 * Copyright (c) 2017 Joyent Inc.
 *
 * The bunyan logging library for node.js.
 *
 * -*- mode: js -*-
 * vim: expandtab:ts=4:sw=4
 */

var VERSION = '1.8.12';

/*
 * Bunyan log format version. This becomes the 'v' field on all log records.
 * This will be incremented if there is any backward incompatible change to
 * the log record format. Details will be in 'CHANGES.md' (the change log).
 */
var LOG_VERSION = 0;


var xxx = function xxx(s) {     // internal dev/debug logging
    var args = ['XX' + 'X: '+s].concat(
        Array.prototype.slice.call(arguments, 1));
    console.error.apply(this, args);
};
var xxx = function xxx() {};  // comment out to turn on debug logging


/*
 * Runtime environment notes:
 *
 * Bunyan is intended to run in a number of runtime environments. Here are
 * some notes on differences for those envs and how the code copes.
 *
 * - node.js: The primary target environment.
 * - NW.js: http://nwjs.io/  An *app* environment that feels like both a
 *   node env -- it has node-like globals (`process`, `global`) and
 *   browser-like globals (`window`, `navigator`). My *understanding* is that
 *   bunyan can operate as if this is vanilla node.js.
 * - browser: Failing the above, we sniff using the `window` global
 *   <https://developer.mozilla.org/en-US/docs/Web/API/Window/window>.
 *      - browserify: http://browserify.org/  A browser-targetting bundler of
 *        node.js deps. The runtime is a browser env, so can't use fs access,
 *        etc. Browserify's build looks for `require(<single-string>)` imports
 *        to bundle. For some imports it won't be able to handle, we "hide"
 *        from browserify with `require('frobshizzle' + '')`.
 * - Other? Please open issues if things are broken.
 */
var runtimeEnv;
if (typeof (process) !== 'undefined' && process.versions) {
    if (process.versions.nw) {
        runtimeEnv = 'nw';
    } else if (process.versions.node) {
        runtimeEnv = 'node';
    }
}
if (!runtimeEnv && typeof (window) !== 'undefined' &&
    window.window === window) {
    runtimeEnv = 'browser';
}
if (!runtimeEnv) {
    throw new Error('unknown runtime environment');
}


var os, fs, dtrace;
if (runtimeEnv === 'browser') {
    os = {
        hostname: function () {
            return window.location.host;
        }
    };
    fs = {};
    dtrace = null;
} else {
    os = require('os');
    fs = require('fs');
    try {
        dtrace = require('dtrace-provider' + '');
    } catch (e) {
        dtrace = null;
    }
}
var util = require('util');
var assert = require('assert');
var EventEmitter = require('events').EventEmitter;
var stream = require('stream');

try {
    var safeJsonStringify = require('safe-json-stringify');
} catch (e) {
    safeJsonStringify = null;
}
if (process.env.BUNYAN_TEST_NO_SAFE_JSON_STRINGIFY) {
    safeJsonStringify = null;
}

// The 'mv' module is required for rotating-file stream support.
try {
    var mv = require('mv' + '');
} catch (e) {
    mv = null;
}

try {
    var sourceMapSupport = require('source-map-support' + '');
} catch (_) {
    sourceMapSupport = null;
}


//---- Internal support stuff

/**
 * A shallow copy of an object. Bunyan logging attempts to never cause
 * exceptions, so this function attempts to handle non-objects gracefully.
 */
function objCopy(obj) {
    if (obj == null) {  // null or undefined
        return obj;
    } else if (Array.isArray(obj)) {
        return obj.slice();
    } else if (typeof (obj) === 'object') {
        var copy = {};
        Object.keys(obj).forEach(function (k) {
            copy[k] = obj[k];
        });
        return copy;
    } else {
        return obj;
    }
}

var format = util.format;
if (!format) {
    // If node < 0.6, then use its `util.format`:
    // <https://github.com/joyent/node/blob/master/lib/util.js#L22>:
    var inspect = util.inspect;
    var formatRegExp = /%[sdj%]/g;
    format = function format(f) {
        if (typeof (f) !== 'string') {
            var objects = [];
            for (var i = 0; i < arguments.length; i++) {
                objects.push(inspect(arguments[i]));
            }
            return objects.join(' ');
        }

        var i = 1;
        var args = arguments;
        var len = args.length;
        var str = String(f).replace(formatRegExp, function (x) {
            if (i >= len)
                return x;
            switch (x) {
                case '%s': return String(args[i++]);
                case '%d': return Number(args[i++]);
                case '%j': return fastAndSafeJsonStringify(args[i++]);
                case '%%': return '%';
                default:
                    return x;
            }
        });
        for (var x = args[i]; i < len; x = args[++i]) {
            if (x === null || typeof (x) !== 'object') {
                str += ' ' + x;
            } else {
                str += ' ' + inspect(x);
            }
        }
        return str;
    };
}


/**
 * Gather some caller info 3 stack levels up.
 * See <http://code.google.com/p/v8/wiki/JavaScriptStackTraceApi>.
 */
function getCaller3Info() {
    if (this === undefined) {
        // Cannot access caller info in 'strict' mode.
        return;
    }
    var obj = {};
    var saveLimit = Error.stackTraceLimit;
    var savePrepare = Error.prepareStackTrace;
    Error.stackTraceLimit = 3;

    Error.prepareStackTrace = function (_, stack) {
        var caller = stack[2];
        if (sourceMapSupport) {
            caller = sourceMapSupport.wrapCallSite(caller);
        }
        obj.file = caller.getFileName();
        obj.line = caller.getLineNumber();
        var func = caller.getFunctionName();
        if (func)
            obj.func = func;
    };
    Error.captureStackTrace(this, getCaller3Info);
    this.stack;

    Error.stackTraceLimit = saveLimit;
    Error.prepareStackTrace = savePrepare;
    return obj;
}


function _indent(s, indent) {
    if (!indent) indent = '    ';
    var lines = s.split(/\r?\n/g);
    return indent + lines.join('\n' + indent);
}


/**
 * Warn about an bunyan processing error.
 *
 * @param msg {String} Message with which to warn.
 * @param dedupKey {String} Optional. A short string key for this warning to
 *      have its warning only printed once.
 */
function _warn(msg, dedupKey) {
    assert.ok(msg);
    if (dedupKey) {
        if (_warned[dedupKey]) {
            return;
        }
        _warned[dedupKey] = true;
    }
    process.stderr.write(msg + '\n');
}
function _haveWarned(dedupKey) {
    return _warned[dedupKey];
}
var _warned = {};


function ConsoleRawStream() {}
ConsoleRawStream.prototype.write = function (rec) {
    if (rec.level < INFO) {
        console.log(rec);
    } else if (rec.level < WARN) {
        console.info(rec);
    } else if (rec.level < ERROR) {
        console.warn(rec);
    } else {
        console.error(rec);
    }
};


//---- Levels

var TRACE = 10;
var DEBUG = 20;
var INFO = 30;
var WARN = 40;
var ERROR = 50;
var FATAL = 60;

var levelFromName = {
    'trace': TRACE,
    'debug': DEBUG,
    'info': INFO,
    'warn': WARN,
    'error': ERROR,
    'fatal': FATAL
};
var nameFromLevel = {};
Object.keys(levelFromName).forEach(function (name) {
    nameFromLevel[levelFromName[name]] = name;
});

// Dtrace probes.
var dtp = undefined;
var probes = dtrace && {};

/**
 * Resolve a level number, name (upper or lowercase) to a level number value.
 *
 * @param nameOrNum {String|Number} A level name (case-insensitive) or positive
 *      integer level.
 * @api public
 */
function resolveLevel(nameOrNum) {
    var level;
    var type = typeof (nameOrNum);
    if (type === 'string') {
        level = levelFromName[nameOrNum.toLowerCase()];
        if (!level) {
            throw new Error(format('unknown level name: "%s"', nameOrNum));
        }
    } else if (type !== 'number') {
        throw new TypeError(format('cannot resolve level: invalid arg (%s):',
            type, nameOrNum));
    } else if (nameOrNum < 0 || Math.floor(nameOrNum) !== nameOrNum) {
        throw new TypeError(format('level is not a positive integer: %s',
            nameOrNum));
    } else {
        level = nameOrNum;
    }
    return level;
}


function isWritable(obj) {
    if (obj instanceof stream.Writable) {
        return true;
    }
    return typeof (obj.write) === 'function';
}


//---- Logger class

/**
 * Create a Logger instance.
 *
 * @param options {Object} See documentation for full details. At minimum
 *    this must include a 'name' string key. Configuration keys:
 *      - `streams`: specify the logger output streams. This is an array of
 *        objects with these fields:
 *          - `type`: The stream type. See README.md for full details.
 *            Often this is implied by the other fields. Examples are
 *            'file', 'stream' and "raw".
 *          - `level`: Defaults to 'info'.
 *          - `path` or `stream`: The specify the file path or writeable
 *            stream to which log records are written. E.g.
 *            `stream: process.stdout`.
 *          - `closeOnExit` (boolean): Optional. Default is true for a
 *            'file' stream when `path` is given, false otherwise.
 *        See README.md for full details.
 *      - `level`: set the level for a single output stream (cannot be used
 *        with `streams`)
 *      - `stream`: the output stream for a logger with just one, e.g.
 *        `process.stdout` (cannot be used with `streams`)
 *      - `serializers`: object mapping log record field names to
 *        serializing functions. See README.md for details.
 *      - `src`: Boolean (default false). Set true to enable 'src' automatic
 *        field with log call source info.
 *    All other keys are log record fields.
 *
 * An alternative *internal* call signature is used for creating a child:
 *    new Logger(<parent logger>, <child options>[, <child opts are simple>]);
 *
 * @param _childSimple (Boolean) An assertion that the given `_childOptions`
 *    (a) only add fields (no config) and (b) no serialization handling is
 *    required for them. IOW, this is a fast path for frequent child
 *    creation.
 */
function Logger(options, _childOptions, _childSimple) {
    xxx('Logger start:', options)
    if (!(this instanceof Logger)) {
        return new Logger(options, _childOptions);
    }

    // Input arg validation.
    var parent;
    if (_childOptions !== undefined) {
        parent = options;
        options = _childOptions;
        if (!(parent instanceof Logger)) {
            throw new TypeError(
                'invalid Logger creation: do not pass a second arg');
        }
    }
    if (!options) {
        throw new TypeError('options (object) is required');
    }
    if (!parent) {
        if (!options.name) {
            throw new TypeError('options.name (string) is required');
        }
    } else {
        if (options.name) {
            throw new TypeError(
                'invalid options.name: child cannot set logger name');
        }
    }
    if (options.stream && options.streams) {
        throw new TypeError('cannot mix "streams" and "stream" options');
    }
    if (options.streams && !Array.isArray(options.streams)) {
        throw new TypeError('invalid options.streams: must be an array')
    }
    if (options.serializers && (typeof (options.serializers) !== 'object' ||
            Array.isArray(options.serializers))) {
        throw new TypeError('invalid options.serializers: must be an object')
    }

    EventEmitter.call(this);

    // Fast path for simple child creation.
    if (parent && _childSimple) {
        // `_isSimpleChild` is a signal to stream close handling that this child
        // owns none of its streams.
        this._isSimpleChild = true;

        this._level = parent._level;
        this.streams = parent.streams;
        this.serializers = parent.serializers;
        this.src = parent.src;
        var fields = this.fields = {};
        var parentFieldNames = Object.keys(parent.fields);
        for (var i = 0; i < parentFieldNames.length; i++) {
            var name = parentFieldNames[i];
            fields[name] = parent.fields[name];
        }
        var names = Object.keys(options);
        for (var i = 0; i < names.length; i++) {
            var name = names[i];
            fields[name] = options[name];
        }
        return;
    }

    // Start values.
    var self = this;
    if (parent) {
        this._level = parent._level;
        this.streams = [];
        for (var i = 0; i < parent.streams.length; i++) {
            var s = objCopy(parent.streams[i]);
            s.closeOnExit = false; // Don't own parent stream.
            this.streams.push(s);
        }
        this.serializers = objCopy(parent.serializers);
        this.src = parent.src;
        this.fields = objCopy(parent.fields);
        if (options.level) {
            this.level(options.level);
        }
    } else {
        this._level = Number.POSITIVE_INFINITY;
        this.streams = [];
        this.serializers = null;
        this.src = false;
        this.fields = {};
    }

    if (!dtp && dtrace) {
        dtp = dtrace.createDTraceProvider('bunyan');

        for (var level in levelFromName) {
            var probe;

            probes[levelFromName[level]] = probe =
                dtp.addProbe('log-' + level, 'char *');

            // Explicitly add a reference to dtp to prevent it from being GC'd
            probe.dtp = dtp;
        }

        dtp.enable();
    }

    // Handle *config* options (i.e. options that are not just plain data
    // for log records).
    if (options.stream) {
        self.addStream({
            type: 'stream',
            stream: options.stream,
            closeOnExit: false,
            level: options.level
        });
    } else if (options.streams) {
        options.streams.forEach(function (s) {
            self.addStream(s, options.level);
        });
    } else if (parent && options.level) {
        this.level(options.level);
    } else if (!parent) {
        if (runtimeEnv === 'browser') {
            /*
             * In the browser we'll be emitting to console.log by default.
             * Any console.log worth its salt these days can nicely render
             * and introspect objects (e.g. the Firefox and Chrome console)
             * so let's emit the raw log record. Are there browsers for which
             * that breaks things?
             */
            self.addStream({
                type: 'raw',
                stream: new ConsoleRawStream(),
                closeOnExit: false,
                level: options.level
            });
        } else {
            self.addStream({
                type: 'stream',
                stream: process.stdout,
                closeOnExit: false,
                level: options.level
            });
        }
    }
    if (options.serializers) {
        self.addSerializers(options.serializers);
    }
    if (options.src) {
        this.src = true;
    }
    xxx('Logger: ', self)

    // Fields.
    // These are the default fields for log records (minus the attributes
    // removed in this constructor). To allow storing raw log records
    // (unrendered), `this.fields` must never be mutated. Create a copy for
    // any changes.
    var fields = objCopy(options);
    delete fields.stream;
    delete fields.level;
    delete fields.streams;
    delete fields.serializers;
    delete fields.src;
    if (this.serializers) {
        this._applySerializers(fields);
    }
    if (!fields.hostname && !self.fields.hostname) {
        fields.hostname = os.hostname();
    }
    if (!fields.pid) {
        fields.pid = process.pid;
    }
    Object.keys(fields).forEach(function (k) {
        self.fields[k] = fields[k];
    });
}

util.inherits(Logger, EventEmitter);


/**
 * Add a stream
 *
 * @param stream {Object}. Object with these fields:
 *    - `type`: The stream type. See README.md for full details.
 *      Often this is implied by the other fields. Examples are
 *      'file', 'stream' and "raw".
 *    - `path` or `stream`: The specify the file path or writeable
 *      stream to which log records are written. E.g.
 *      `stream: process.stdout`.
 *    - `level`: Optional. Falls back to `defaultLevel`.
 *    - `closeOnExit` (boolean): Optional. Default is true for a
 *      'file' stream when `path` is given, false otherwise.
 *    See README.md for full details.
 * @param defaultLevel {Number|String} Optional. A level to use if
 *      `stream.level` is not set. If neither is given, this defaults to INFO.
 */
Logger.prototype.addStream = function addStream(s, defaultLevel) {
    var self = this;
    if (defaultLevel === null || defaultLevel === undefined) {
        defaultLevel = INFO;
    }

    s = objCopy(s);

    // Implicit 'type' from other args.
    if (!s.type) {
        if (s.stream) {
            s.type = 'stream';
        } else if (s.path) {
            s.type = 'file'
        }
    }
    s.raw = (s.type === 'raw');  // PERF: Allow for faster check in `_emit`.

    if (s.level !== undefined) {
        s.level = resolveLevel(s.level);
    } else {
        s.level = resolveLevel(defaultLevel);
    }
    if (s.level < self._level) {
        self._level = s.level;
    }

    switch (s.type) {
    case 'stream':
        assert.ok(isWritable(s.stream),
                  '"stream" stream is not writable: ' + util.inspect(s.stream));

        if (!s.closeOnExit) {
            s.closeOnExit = false;
        }
        break;
    case 'file':
        if (s.reemitErrorEvents === undefined) {
            s.reemitErrorEvents = true;
        }
        if (!s.stream) {
            s.stream = fs.createWriteStream(s.path,
                                            {flags: 'a', encoding: 'utf8'});
            if (!s.closeOnExit) {
                s.closeOnExit = true;
            }
        } else {
            if (!s.closeOnExit) {
                s.closeOnExit = false;
            }
        }
        break;
    case 'rotating-file':
        assert.ok(!s.stream,
                  '"rotating-file" stream should not give a "stream"');
        assert.ok(s.path);
        assert.ok(mv, '"rotating-file" stream type is not supported: '
                      + 'missing "mv" module');
        s.stream = new RotatingFileStream(s);
        if (!s.closeOnExit) {
            s.closeOnExit = true;
        }
        break;
    case 'raw':
        if (!s.closeOnExit) {
            s.closeOnExit = false;
        }
        break;
    default:
        throw new TypeError('unknown stream type "' + s.type + '"');
    }

    if (s.reemitErrorEvents && typeof (s.stream.on) === 'function') {
        // TODO: When we have `<logger>.close()`, it should remove event
        //      listeners to not leak Logger instances.
        s.stream.on('error', function onStreamError(err) {
            self.emit('error', err, s);
        });
    }

    self.streams.push(s);
    delete self.haveNonRawStreams;  // reset
}


/**
 * Add serializers
 *
 * @param serializers {Object} Optional. Object mapping log record field names
 *    to serializing functions. See README.md for details.
 */
Logger.prototype.addSerializers = function addSerializers(serializers) {
    var self = this;

    if (!self.serializers) {
        self.serializers = {};
    }
    Object.keys(serializers).forEach(function (field) {
        var serializer = serializers[field];
        if (typeof (serializer) !== 'function') {
            throw new TypeError(format(
                'invalid serializer for "%s" field: must be a function',
                field));
        } else {
            self.serializers[field] = serializer;
        }
    });
}



/**
 * Create a child logger, typically to add a few log record fields.
 *
 * This can be useful when passing a logger to a sub-component, e.g. a
 * 'wuzzle' component of your service:
 *
 *    var wuzzleLog = log.child({component: 'wuzzle'})
 *    var wuzzle = new Wuzzle({..., log: wuzzleLog})
 *
 * Then log records from the wuzzle code will have the same structure as
 * the app log, *plus the component='wuzzle' field*.
 *
 * @param options {Object} Optional. Set of options to apply to the child.
 *    All of the same options for a new Logger apply here. Notes:
 *      - The parent's streams are inherited and cannot be removed in this
 *        call. Any given `streams` are *added* to the set inherited from
 *        the parent.
 *      - The parent's serializers are inherited, though can effectively be
 *        overwritten by using duplicate keys.
 *      - Can use `level` to set the level of the streams inherited from
 *        the parent. The level for the parent is NOT affected.
 * @param simple {Boolean} Optional. Set to true to assert that `options`
 *    (a) only add fields (no config) and (b) no serialization handling is
 *    required for them. IOW, this is a fast path for frequent child
 *    creation. See 'tools/timechild.js' for numbers.
 */
Logger.prototype.child = function (options, simple) {
    return new (this.constructor)(this, options || {}, simple);
}


/**
 * A convenience method to reopen 'file' streams on a logger. This can be
 * useful with external log rotation utilities that move and re-open log files
 * (e.g. logrotate on Linux, logadm on SmartOS/Illumos). Those utilities
 * typically have rotation options to copy-and-truncate the log file, but
 * you may not want to use that. An alternative is to do this in your
 * application:
 *
 *      var log = bunyan.createLogger(...);
 *      ...
 *      process.on('SIGUSR2', function () {
 *          log.reopenFileStreams();
 *      });
 *      ...
 *
 * See <https://github.com/trentm/node-bunyan/issues/104>.
 */
Logger.prototype.reopenFileStreams = function () {
    var self = this;
    self.streams.forEach(function (s) {
        if (s.type === 'file') {
            if (s.stream) {
                // Not sure if typically would want this, or more immediate
                // `s.stream.destroy()`.
                s.stream.end();
                s.stream.destroySoon();
                delete s.stream;
            }
            s.stream = fs.createWriteStream(s.path,
                {flags: 'a', encoding: 'utf8'});
            s.stream.on('error', function (err) {
                self.emit('error', err, s);
            });
        }
    });
};


/* BEGIN JSSTYLED */
/**
 * Close this logger.
 *
 * This closes streams (that it owns, as per 'endOnClose' attributes on
 * streams), etc. Typically you **don't** need to bother calling this.
Logger.prototype.close = function () {
    if (this._closed) {
        return;
    }
    if (!this._isSimpleChild) {
        self.streams.forEach(function (s) {
            if (s.endOnClose) {
                xxx('closing stream s:', s);
                s.stream.end();
                s.endOnClose = false;
            }
        });
    }
    this._closed = true;
}
 */
/* END JSSTYLED */


/**
 * Get/set the level of all streams on this logger.
 *
 * Get Usage:
 *    // Returns the current log level (lowest level of all its streams).
 *    log.level() -> INFO
 *
 * Set Usage:
 *    log.level(INFO)       // set all streams to level INFO
 *    log.level('info')     // can use 'info' et al aliases
 */
Logger.prototype.level = function level(value) {
    if (value === undefined) {
        return this._level;
    }
    var newLevel = resolveLevel(value);
    var len = this.streams.length;
    for (var i = 0; i < len; i++) {
        this.streams[i].level = newLevel;
    }
    this._level = newLevel;
}


/**
 * Get/set the level of a particular stream on this logger.
 *
 * Get Usage:
 *    // Returns an array of the levels of each stream.
 *    log.levels() -> [TRACE, INFO]
 *
 *    // Returns a level of the identified stream.
 *    log.levels(0) -> TRACE      // level of stream at index 0
 *    log.levels('foo')           // level of stream with name 'foo'
 *
 * Set Usage:
 *    log.levels(0, INFO)         // set level of stream 0 to INFO
 *    log.levels(0, 'info')       // can use 'info' et al aliases
 *    log.levels('foo', WARN)     // set stream named 'foo' to WARN
 *
 * Stream names: When streams are defined, they can optionally be given
 * a name. For example,
 *       log = new Logger({
 *         streams: [
 *           {
 *             name: 'foo',
 *             path: '/var/log/my-service/foo.log'
 *             level: 'trace'
 *           },
 *         ...
 *
 * @param name {String|Number} The stream index or name.
 * @param value {Number|String} The level value (INFO) or alias ('info').
 *    If not given, this is a 'get' operation.
 * @throws {Error} If there is no stream with the given name.
 */
Logger.prototype.levels = function levels(name, value) {
    if (name === undefined) {
        assert.equal(value, undefined);
        return this.streams.map(
            function (s) { return s.level });
    }
    var stream;
    if (typeof (name) === 'number') {
        stream = this.streams[name];
        if (stream === undefined) {
            throw new Error('invalid stream index: ' + name);
        }
    } else {
        var len = this.streams.length;
        for (var i = 0; i < len; i++) {
            var s = this.streams[i];
            if (s.name === name) {
                stream = s;
                break;
            }
        }
        if (!stream) {
            throw new Error(format('no stream with name "%s"', name));
        }
    }
    if (value === undefined) {
        return stream.level;
    } else {
        var newLevel = resolveLevel(value);
        stream.level = newLevel;
        if (newLevel < this._level) {
            this._level = newLevel;
        }
    }
}


/**
 * Apply registered serializers to the appropriate keys in the given fields.
 *
 * Pre-condition: This is only called if there is at least one serializer.
 *
 * @param fields (Object) The log record fields.
 * @param excludeFields (Object) Optional mapping of keys to `true` for
 *    keys to NOT apply a serializer.
 */
Logger.prototype._applySerializers = function (fields, excludeFields) {
    var self = this;

    xxx('_applySerializers: excludeFields', excludeFields);

    // Check each serializer against these (presuming number of serializers
    // is typically less than number of fields).
    Object.keys(this.serializers).forEach(function (name) {
        if (fields[name] === undefined ||
            (excludeFields && excludeFields[name]))
        {
            return;
        }
        xxx('_applySerializers; apply to "%s" key', name)
        try {
            fields[name] = self.serializers[name](fields[name]);
        } catch (err) {
            _warn(format('bunyan: ERROR: Exception thrown from the "%s" '
                + 'Bunyan serializer. This should never happen. This is a bug '
                + 'in that serializer function.\n%s',
                name, err.stack || err));
            fields[name] = format('(Error in Bunyan log "%s" serializer '
                + 'broke field. See stderr for details.)', name);
        }
    });
}


/**
 * Emit a log record.
 *
 * @param rec {log record}
 * @param noemit {Boolean} Optional. Set to true to skip emission
 *      and just return the JSON string.
 */
Logger.prototype._emit = function (rec, noemit) {
    var i;

    // Lazily determine if this Logger has non-'raw' streams. If there are
    // any, then we need to stringify the log record.
    if (this.haveNonRawStreams === undefined) {
        this.haveNonRawStreams = false;
        for (i = 0; i < this.streams.length; i++) {
            if (!this.streams[i].raw) {
                this.haveNonRawStreams = true;
                break;
            }
        }
    }

    // Stringify the object (creates a warning str on error).
    var str;
    if (noemit || this.haveNonRawStreams) {
        str = fastAndSafeJsonStringify(rec) + '\n';
    }

    if (noemit)
        return str;

    var level = rec.level;
    for (i = 0; i < this.streams.length; i++) {
        var s = this.streams[i];
        if (s.level <= level) {
            xxx('writing log rec "%s" to "%s" stream (%d <= %d): %j',
                rec.msg, s.type, s.level, level, rec);
            s.stream.write(s.raw ? rec : str);
        }
    };

    return str;
}


/**
 * Build a record object suitable for emitting from the arguments
 * provided to the a log emitter.
 */
function mkRecord(log, minLevel, args) {
    var excludeFields, fields, msgArgs;
    if (args[0] instanceof Error) {
        // `log.<level>(err, ...)`
        fields = {
            // Use this Logger's err serializer, if defined.
            err: (log.serializers && log.serializers.err
                ? log.serializers.err(args[0])
                : Logger.stdSerializers.err(args[0]))
        };
        excludeFields = {err: true};
        if (args.length === 1) {
            msgArgs = [fields.err.message];
        } else {
            msgArgs = args.slice(1);
        }
    } else if (typeof (args[0]) !== 'object' || Array.isArray(args[0])) {
        // `log.<level>(msg, ...)`
        fields = null;
        msgArgs = args.slice();
    } else if (Buffer.isBuffer(args[0])) {  // `log.<level>(buf, ...)`
        // Almost certainly an error, show `inspect(buf)`. See bunyan
        // issue #35.
        fields = null;
        msgArgs = args.slice();
        msgArgs[0] = util.inspect(msgArgs[0]);
    } else {  // `log.<level>(fields, msg, ...)`
        fields = args[0];
        if (fields && args.length === 1 && fields.err &&
            fields.err instanceof Error)
        {
            msgArgs = [fields.err.message];
        } else {
            msgArgs = args.slice(1);
        }
    }

    // Build up the record object.
    var rec = objCopy(log.fields);
    var level = rec.level = minLevel;
    var recFields = (fields ? objCopy(fields) : null);
    if (recFields) {
        if (log.serializers) {
            log._applySerializers(recFields, excludeFields);
        }
        Object.keys(recFields).forEach(function (k) {
            rec[k] = recFields[k];
        });
    }
    rec.msg = format.apply(log, msgArgs);
    if (!rec.time) {
        rec.time = (new Date());
    }
    // Get call source info
    if (log.src && !rec.src) {
        rec.src = getCaller3Info()
    }
    rec.v = LOG_VERSION;

    return rec;
};


/**
 * Build an array that dtrace-provider can use to fire a USDT probe. If we've
 * already built the appropriate string, we use it. Otherwise, build the
 * record object and stringify it.
 */
function mkProbeArgs(str, log, minLevel, msgArgs) {
    return [ str || log._emit(mkRecord(log, minLevel, msgArgs), true) ];
}


/**
 * Build a log emitter function for level minLevel. I.e. this is the
 * creator of `log.info`, `log.error`, etc.
 */
function mkLogEmitter(minLevel) {
    return function () {
        var log = this;
        var str = null;
        var rec = null;

        if (!this._emit) {
            /*
             * Show this invalid Bunyan usage warning *once*.
             *
             * See <https://github.com/trentm/node-bunyan/issues/100> for
             * an example of how this can happen.
             */
            var dedupKey = 'unbound';
            if (!_haveWarned[dedupKey]) {
                var caller = getCaller3Info();
                _warn(format('bunyan usage error: %s:%s: attempt to log '
                    + 'with an unbound log method: `this` is: %s',
                    caller.file, caller.line, util.inspect(this)),
                    dedupKey);
            }
            return;
        } else if (arguments.length === 0) {   // `log.<level>()`
            return (this._level <= minLevel);
        }

        var msgArgs = new Array(arguments.length);
        for (var i = 0; i < msgArgs.length; ++i) {
            msgArgs[i] = arguments[i];
        }

        if (this._level <= minLevel) {
            rec = mkRecord(log, minLevel, msgArgs);
            str = this._emit(rec);
        }

        if (probes) {
            probes[minLevel].fire(mkProbeArgs, str, log, minLevel, msgArgs);
        }
    }
}


/**
 * The functions below log a record at a specific level.
 *
 * Usages:
 *    log.<level>()  -> boolean is-trace-enabled
 *    log.<level>(<Error> err, [<string> msg, ...])
 *    log.<level>(<string> msg, ...)
 *    log.<level>(<object> fields, <string> msg, ...)
 *
 * where <level> is the lowercase version of the log level. E.g.:
 *
 *    log.info()
 *
 * @params fields {Object} Optional set of additional fields to log.
 * @params msg {String} Log message. This can be followed by additional
 *    arguments that are handled like
 *    [util.format](http://nodejs.org/docs/latest/api/all.html#util.format).
 */
Logger.prototype.trace = mkLogEmitter(TRACE);
Logger.prototype.debug = mkLogEmitter(DEBUG);
Logger.prototype.info = mkLogEmitter(INFO);
Logger.prototype.warn = mkLogEmitter(WARN);
Logger.prototype.error = mkLogEmitter(ERROR);
Logger.prototype.fatal = mkLogEmitter(FATAL);



//---- Standard serializers
// A serializer is a function that serializes a JavaScript object to a
// JSON representation for logging. There is a standard set of presumed
// interesting objects in node.js-land.

Logger.stdSerializers = {};

// Serialize an HTTP request.
Logger.stdSerializers.req = function (req) {
    if (!req || !req.connection)
        return req;
    return {
        method: req.method,
        url: req.url,
        headers: req.headers,
        remoteAddress: req.connection.remoteAddress,
        remotePort: req.connection.remotePort
    };
    // Trailers: Skipping for speed. If you need trailers in your app, then
    // make a custom serializer.
    //if (Object.keys(trailers).length > 0) {
    //  obj.trailers = req.trailers;
    //}
};

// Serialize an HTTP response.
Logger.stdSerializers.res = function (res) {
    if (!res || !res.statusCode)
        return res;
    return {
        statusCode: res.statusCode,
        header: res._header
    }
};


/*
 * This function dumps long stack traces for exceptions having a cause()
 * method. The error classes from
 * [verror](https://github.com/davepacheco/node-verror) and
 * [restify v2.0](https://github.com/mcavage/node-restify) are examples.
 *
 * Based on `dumpException` in
 * https://github.com/davepacheco/node-extsprintf/blob/master/lib/extsprintf.js
 */
function getFullErrorStack(ex)
{
    var ret = ex.stack || ex.toString();
    if (ex.cause && typeof (ex.cause) === 'function') {
        var cex = ex.cause();
        if (cex) {
            ret += '\nCaused by: ' + getFullErrorStack(cex);
        }
    }
    return (ret);
}

// Serialize an Error object
// (Core error properties are enumerable in node 0.4, not in 0.6).
var errSerializer = Logger.stdSerializers.err = function (err) {
    if (!err || !err.stack)
        return err;
    var obj = {
        message: err.message,
        name: err.name,
        stack: getFullErrorStack(err),
        code: err.code,
        signal: err.signal
    }
    return obj;
};


// A JSON stringifier that handles cycles safely - tracks seen values in a Set.
function safeCyclesSet() {
    var seen = new Set();
    return function (key, val) {
        if (!val || typeof (val) !== 'object') {
            return val;
        }
        if (seen.has(val)) {
            return '[Circular]';
        }
        seen.add(val);
        return val;
    };
}

/**
 * A JSON stringifier that handles cycles safely - tracks seen vals in an Array.
 *
 * Note: This approach has performance problems when dealing with large objects,
 * see trentm/node-bunyan#445, but since this is the only option for node 0.10
 * and earlier (as Set was introduced in Node 0.12), it's used as a fallback
 * when Set is not available.
 */
function safeCyclesArray() {
    var seen = [];
    return function (key, val) {
        if (!val || typeof (val) !== 'object') {
            return val;
        }
        if (seen.indexOf(val) !== -1) {
            return '[Circular]';
        }
        seen.push(val);
        return val;
    };
}

/**
 * A JSON stringifier that handles cycles safely.
 *
 * Usage: JSON.stringify(obj, safeCycles())
 *
 * Choose the best safe cycle function from what is available - see
 * trentm/node-bunyan#445.
 */
var safeCycles = typeof (Set) !== 'undefined' ? safeCyclesSet : safeCyclesArray;

/**
 * A fast JSON.stringify that handles cycles and getter exceptions (when
 * safeJsonStringify is installed).
 *
 * This function attempts to use the regular JSON.stringify for speed, but on
 * error (e.g. JSON cycle detection exception) it falls back to safe stringify
 * handlers that can deal with cycles and/or getter exceptions.
 */
function fastAndSafeJsonStringify(rec) {
    try {
        return JSON.stringify(rec);
    } catch (ex) {
        try {
            return JSON.stringify(rec, safeCycles());
        } catch (e) {
            if (safeJsonStringify) {
                return safeJsonStringify(rec);
            } else {
                var dedupKey = e.stack.split(/\n/g, 3).join('\n');
                _warn('bunyan: ERROR: Exception in '
                    + '`JSON.stringify(rec)`. You can install the '
                    + '"safe-json-stringify" module to have Bunyan fallback '
                    + 'to safer stringification. Record:\n'
                    + _indent(format('%s\n%s', util.inspect(rec), e.stack)),
                    dedupKey);
                return format('(Exception in JSON.stringify(rec): %j. '
                    + 'See stderr for details.)', e.message);
            }
        }
    }
}


var RotatingFileStream = null;
if (mv) {

RotatingFileStream = function RotatingFileStream(options) {
    this.path = options.path;

    this.count = (options.count == null ? 10 : options.count);
    assert.equal(typeof (this.count), 'number',
        format('rotating-file stream "count" is not a number: %j (%s) in %j',
            this.count, typeof (this.count), this));
    assert.ok(this.count >= 0,
        format('rotating-file stream "count" is not >= 0: %j in %j',
            this.count, this));

    // Parse `options.period`.
    if (options.period) {
        // <number><scope> where scope is:
        //    h   hours (at the start of the hour)
        //    d   days (at the start of the day, i.e. just after midnight)
        //    w   weeks (at the start of Sunday)
        //    m   months (on the first of the month)
        //    y   years (at the start of Jan 1st)
        // with special values 'hourly' (1h), 'daily' (1d), "weekly" (1w),
        // 'monthly' (1m) and 'yearly' (1y)
        var period = {
            'hourly': '1h',
            'daily': '1d',
            'weekly': '1w',
            'monthly': '1m',
            'yearly': '1y'
        }[options.period] || options.period;
        var m = /^([1-9][0-9]*)([hdwmy]|ms)$/.exec(period);
        if (!m) {
            throw new Error(format('invalid period: "%s"', options.period));
        }
        this.periodNum = Number(m[1]);
        this.periodScope = m[2];
    } else {
        this.periodNum = 1;
        this.periodScope = 'd';
    }

    var lastModified = null;
    try {
        var fileInfo = fs.statSync(this.path);
        lastModified = fileInfo.mtime.getTime();
    }
    catch (err) {
        // file doesn't exist
    }
    var rotateAfterOpen = false;
    if (lastModified) {
        var lastRotTime = this._calcRotTime(0);
        if (lastModified < lastRotTime) {
            rotateAfterOpen = true;
        }
    }

    // TODO: template support for backup files
    // template: <path to which to rotate>
    //      default is %P.%n
    //      '/var/log/archive/foo.log'  -> foo.log.%n
    //      '/var/log/archive/foo.log.%n'
    //      codes:
    //          XXX support strftime codes (per node version of those)
    //              or whatever module. Pick non-colliding for extra
    //              codes
    //          %P      `path` base value
    //          %n      integer number of rotated log (1,2,3,...)
    //          %d      datetime in YYYY-MM-DD_HH-MM-SS
    //                      XXX what should default date format be?
    //                          prior art? Want to avoid ':' in
    //                          filenames (illegal on Windows for one).

    this.stream = fs.createWriteStream(this.path,
        {flags: 'a', encoding: 'utf8'});

    this.rotQueue = [];
    this.rotating = false;
    if (rotateAfterOpen) {
        this._debug('rotateAfterOpen -> call rotate()');
        this.rotate();
    } else {
        this._setupNextRot();
    }
}

util.inherits(RotatingFileStream, EventEmitter);

RotatingFileStream.prototype._debug = function () {
    // Set this to `true` to add debug logging.
    if (false) {
        if (arguments.length === 0) {
            return true;
        }
        var args = Array.prototype.slice.call(arguments);
        args[0] = '[' + (new Date().toISOString()) + ', '
            + this.path + '] ' + args[0];
        console.log.apply(this, args);
    } else {
        return false;
    }
};

RotatingFileStream.prototype._setupNextRot = function () {
    this.rotAt = this._calcRotTime(1);
    this._setRotationTimer();
}

RotatingFileStream.prototype._setRotationTimer = function () {
    var self = this;
    var delay = this.rotAt - Date.now();
    // Cap timeout to Node's max setTimeout, see
    // <https://github.com/joyent/node/issues/8656>.
    var TIMEOUT_MAX = 2147483647; // 2^31-1
    if (delay > TIMEOUT_MAX) {
        delay = TIMEOUT_MAX;
    }
    this.timeout = setTimeout(
        function () {
            self._debug('_setRotationTimer timeout -> call rotate()');
            self.rotate();
        },
        delay);
    if (typeof (this.timeout.unref) === 'function') {
        this.timeout.unref();
    }
}

RotatingFileStream.prototype._calcRotTime =
function _calcRotTime(periodOffset) {
    this._debug('_calcRotTime: %s%s', this.periodNum, this.periodScope);
    var d = new Date();

    this._debug('  now local: %s', d);
    this._debug('    now utc: %s', d.toISOString());
    var rotAt;
    switch (this.periodScope) {
    case 'ms':
        // Hidden millisecond period for debugging.
        if (this.rotAt) {
            rotAt = this.rotAt + this.periodNum * periodOffset;
        } else {
            rotAt = Date.now() + this.periodNum * periodOffset;
        }
        break;
    case 'h':
        if (this.rotAt) {
            rotAt = this.rotAt + this.periodNum * 60 * 60 * 1000 * periodOffset;
        } else {
            // First time: top of the next hour.
            rotAt = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(),
                d.getUTCDate(), d.getUTCHours() + periodOffset);
        }
        break;
    case 'd':
        if (this.rotAt) {
            rotAt = this.rotAt + this.periodNum * 24 * 60 * 60 * 1000
                * periodOffset;
        } else {
            // First time: start of tomorrow (i.e. at the coming midnight) UTC.
            rotAt = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(),
                d.getUTCDate() + periodOffset);
        }
        break;
    case 'w':
        // Currently, always on Sunday morning at 00:00:00 (UTC).
        if (this.rotAt) {
            rotAt = this.rotAt + this.periodNum * 7 * 24 * 60 * 60 * 1000
                * periodOffset;
        } else {
            // First time: this coming Sunday.
            var dayOffset = (7 - d.getUTCDay());
            if (periodOffset < 1) {
                dayOffset = -d.getUTCDay();
            }
            if (periodOffset > 1 || periodOffset < -1) {
                dayOffset += 7 * periodOffset;
            }
            rotAt = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(),
                d.getUTCDate() + dayOffset);
        }
        break;
    case 'm':
        if (this.rotAt) {
            rotAt = Date.UTC(d.getUTCFullYear(),
                d.getUTCMonth() + this.periodNum * periodOffset, 1);
        } else {
            // First time: the start of the next month.
            rotAt = Date.UTC(d.getUTCFullYear(),
                d.getUTCMonth() + periodOffset, 1);
        }
        break;
    case 'y':
        if (this.rotAt) {
            rotAt = Date.UTC(d.getUTCFullYear() + this.periodNum * periodOffset,
                0, 1);
        } else {
            // First time: the start of the next year.
            rotAt = Date.UTC(d.getUTCFullYear() + periodOffset, 0, 1);
        }
        break;
    default:
        assert.fail(format('invalid period scope: "%s"', this.periodScope));
    }

    if (this._debug()) {
        this._debug('  **rotAt**: %s (utc: %s)', rotAt,
            new Date(rotAt).toUTCString());
        var now = Date.now();
        this._debug('        now: %s (%sms == %smin == %sh to go)',
            now,
            rotAt - now,
            (rotAt-now)/1000/60,
            (rotAt-now)/1000/60/60);
    }
    return rotAt;
};

RotatingFileStream.prototype.rotate = function rotate() {
    // XXX What about shutdown?
    var self = this;

    // If rotation period is > ~25 days, we have to break into multiple
    // setTimeout's. See <https://github.com/joyent/node/issues/8656>.
    if (self.rotAt && self.rotAt > Date.now()) {
        return self._setRotationTimer();
    }

    this._debug('rotate');
    if (self.rotating) {
        throw new TypeError('cannot start a rotation when already rotating');
    }
    self.rotating = true;

    self.stream.end();  // XXX can do moves sync after this? test at high rate

    function del() {
        var toDel = self.path + '.' + String(n - 1);
        if (n === 0) {
            toDel = self.path;
        }
        n -= 1;
        self._debug('  rm %s', toDel);
        fs.unlink(toDel, function (delErr) {
            //XXX handle err other than not exists
            moves();
        });
    }

    function moves() {
        if (self.count === 0 || n < 0) {
            return finish();
        }
        var before = self.path;
        var after = self.path + '.' + String(n);
        if (n > 0) {
            before += '.' + String(n - 1);
        }
        n -= 1;
        fs.exists(before, function (exists) {
            if (!exists) {
                moves();
            } else {
                self._debug('  mv %s %s', before, after);
                mv(before, after, function (mvErr) {
                    if (mvErr) {
                        self.emit('error', mvErr);
                        finish(); // XXX finish here?
                    } else {
                        moves();
                    }
                });
            }
        })
    }

    function finish() {
        self._debug('  open %s', self.path);
        self.stream = fs.createWriteStream(self.path,
            {flags: 'a', encoding: 'utf8'});
        var q = self.rotQueue, len = q.length;
        for (var i = 0; i < len; i++) {
            self.stream.write(q[i]);
        }
        self.rotQueue = [];
        self.rotating = false;
        self.emit('drain');
        self._setupNextRot();
    }

    var n = this.count;
    del();
};

RotatingFileStream.prototype.write = function write(s) {
    if (this.rotating) {
        this.rotQueue.push(s);
        return false;
    } else {
        return this.stream.write(s);
    }
};

RotatingFileStream.prototype.end = function end(s) {
    this.stream.end();
};

RotatingFileStream.prototype.destroy = function destroy(s) {
    this.stream.destroy();
};

RotatingFileStream.prototype.destroySoon = function destroySoon(s) {
    this.stream.destroySoon();
};

} /* if (mv) */



/**
 * RingBuffer is a Writable Stream that just stores the last N records in
 * memory.
 *
 * @param options {Object}, with the following fields:
 *
 *    - limit: number of records to keep in memory
 */
function RingBuffer(options) {
    this.limit = options && options.limit ? options.limit : 100;
    this.writable = true;
    this.records = [];
    EventEmitter.call(this);
}

util.inherits(RingBuffer, EventEmitter);

RingBuffer.prototype.write = function (record) {
    if (!this.writable)
        throw (new Error('RingBuffer has been ended already'));

    this.records.push(record);

    if (this.records.length > this.limit)
        this.records.shift();

    return (true);
};

RingBuffer.prototype.end = function () {
    if (arguments.length > 0)
        this.write.apply(this, Array.prototype.slice.call(arguments));
    this.writable = false;
};

RingBuffer.prototype.destroy = function () {
    this.writable = false;
    this.emit('close');
};

RingBuffer.prototype.destroySoon = function () {
    this.destroy();
};


//---- Exports

module.exports = Logger;

module.exports.TRACE = TRACE;
module.exports.DEBUG = DEBUG;
module.exports.INFO = INFO;
module.exports.WARN = WARN;
module.exports.ERROR = ERROR;
module.exports.FATAL = FATAL;
module.exports.resolveLevel = resolveLevel;
module.exports.levelFromName = levelFromName;
module.exports.nameFromLevel = nameFromLevel;

module.exports.VERSION = VERSION;
module.exports.LOG_VERSION = LOG_VERSION;

module.exports.createLogger = function createLogger(options) {
    return new Logger(options);
};

module.exports.RingBuffer = RingBuffer;
module.exports.RotatingFileStream = RotatingFileStream;

// Useful for custom `type == 'raw'` streams that may do JSON stringification
// of log records themselves. Usage:
//    var str = JSON.stringify(rec, bunyan.safeCycles());
module.exports.safeCycles = safeCycles;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/wekan:wekan-ldap/server/index.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['wekan:wekan-ldap'] = exports;

})();

//# sourceURL=meteor://💻app/packages/wekan_wekan-ldap.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvd2VrYW46d2VrYW4tbGRhcC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3dla2FuOndla2FuLWxkYXAvc2VydmVyL2xkYXAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3dla2FuOndla2FuLWxkYXAvc2VydmVyL2xvZ2dlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvd2VrYW46d2VrYW4tbGRhcC9zZXJ2ZXIvbG9naW5IYW5kbGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy93ZWthbjp3ZWthbi1sZGFwL3NlcnZlci9zeW5jLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImV4cG9ydCIsImRlZmF1bHQiLCJMREFQIiwibGRhcGpzIiwidiIsInV0aWwiLCJCdW55YW4iLCJsb2dfZGVidWciLCJsb2dfaW5mbyIsImxvZ193YXJuIiwibG9nX2Vycm9yIiwiY29uc3RydWN0b3IiLCJjb25uZWN0ZWQiLCJvcHRpb25zIiwiaG9zdCIsInNldHRpbmdzX2dldCIsInBvcnQiLCJSZWNvbm5lY3QiLCJ0aW1lb3V0IiwiY29ubmVjdF90aW1lb3V0IiwiaWRsZV90aW1lb3V0IiwiZW5jcnlwdGlvbiIsImNhX2NlcnQiLCJyZWplY3RfdW5hdXRob3JpemVkIiwiQXV0aGVudGljYXRpb24iLCJBdXRoZW50aWNhdGlvbl9Vc2VyRE4iLCJBdXRoZW50aWNhdGlvbl9QYXNzd29yZCIsIkF1dGhlbnRpY2F0aW9uX0ZhbGxiYWNrIiwiQmFzZUROIiwiSW50ZXJuYWxfTG9nX0xldmVsIiwiVXNlcl9TZWFyY2hfRmlsdGVyIiwiVXNlcl9TZWFyY2hfU2NvcGUiLCJVc2VyX1NlYXJjaF9GaWVsZCIsIlNlYXJjaF9QYWdlX1NpemUiLCJTZWFyY2hfU2l6ZV9MaW1pdCIsImdyb3VwX2ZpbHRlcl9lbmFibGVkIiwiZ3JvdXBfZmlsdGVyX29iamVjdF9jbGFzcyIsImdyb3VwX2ZpbHRlcl9ncm91cF9pZF9hdHRyaWJ1dGUiLCJncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2F0dHJpYnV0ZSIsImdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0IiwiZ3JvdXBfZmlsdGVyX2dyb3VwX25hbWUiLCJuYW1lIiwiYXJncyIsInZhbHVlIiwicHJvY2VzcyIsImVudiIsInVuZGVmaW5lZCIsIkpTT04iLCJwYXJzZSIsImlzTmFOIiwiTnVtYmVyIiwiY29ubmVjdFN5bmMiLCJfY29ubmVjdFN5bmMiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJjb25uZWN0QXN5bmMiLCJzZWFyY2hBbGxTeW5jIiwiX3NlYXJjaEFsbFN5bmMiLCJzZWFyY2hBbGxBc3luYyIsImNhbGxiYWNrIiwicmVwbGllZCIsImNvbm5lY3Rpb25PcHRpb25zIiwidXJsIiwiY29ubmVjdFRpbWVvdXQiLCJpZGxlVGltZW91dCIsInJlY29ubmVjdCIsImxvZyIsImNvbXBvbmVudCIsInN0cmVhbSIsInN0ZGVyciIsImxldmVsIiwidGxzT3B0aW9ucyIsInJlamVjdFVuYXV0aG9yaXplZCIsImNoYWluTGluZXMiLCJzcGxpdCIsImNlcnQiLCJjYSIsImZvckVhY2giLCJsaW5lIiwicHVzaCIsIm1hdGNoIiwiam9pbiIsImluc3BlY3QiLCJjbGllbnQiLCJjcmVhdGVDbGllbnQiLCJiaW5kU3luYyIsImJpbmQiLCJvbiIsImVycm9yIiwiZGlzY29ubmVjdCIsInN0YXJ0dGxzIiwicmVzcG9uc2UiLCJzZXRUaW1lb3V0IiwiRXJyb3IiLCJnZXRVc2VyRmlsdGVyIiwidXNlcm5hbWUiLCJmaWx0ZXIiLCJ1c2VybmFtZUZpbHRlciIsIm1hcCIsIml0ZW0iLCJsZW5ndGgiLCJiaW5kSWZOZWNlc3NhcnkiLCJkb21haW5CaW5kZWQiLCJzZWFyY2hVc2Vyc1N5bmMiLCJwYWdlIiwic2VhcmNoT3B0aW9ucyIsInNjb3BlIiwic2l6ZUxpbWl0IiwicGFnZWQiLCJwYWdlU2l6ZSIsInBhZ2VQYXVzZSIsInNlYXJjaEFsbFBhZ2VkIiwiZ2V0VXNlckJ5SWRTeW5jIiwiaWQiLCJhdHRyaWJ1dGUiLCJVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCIsImZpbHRlcnMiLCJFcXVhbGl0eUZpbHRlciIsIkJ1ZmZlciIsIk9yRmlsdGVyIiwidG9TdHJpbmciLCJyZXN1bHQiLCJBcnJheSIsImlzQXJyYXkiLCJnZXRVc2VyQnlVc2VybmFtZVN5bmMiLCJnZXRVc2VyR3JvdXBzIiwibGRhcFVzZXIiLCJmb3JtYXRfdmFsdWUiLCJyZXBsYWNlIiwiZ3JwX2lkZW50aWZpZXIiLCJncm91cHMiLCJpc1VzZXJJbkdyb3VwIiwiZ3JwcyIsImV4dHJhY3RMZGFwRW50cnlEYXRhIiwiZW50cnkiLCJ2YWx1ZXMiLCJfcmF3IiwicmF3IiwiT2JqZWN0Iiwia2V5cyIsImtleSIsImluY2x1ZGVzIiwicHJvY2Vzc1BhZ2UiLCJlbnRyaWVzIiwidGl0bGUiLCJlbmQiLCJuZXh0IiwiX3VwZGF0ZUlkbGUiLCJzZWFyY2giLCJyZXMiLCJpbnRlcm5hbFBhZ2VTaXplIiwiYXV0aFN5bmMiLCJkbiIsInBhc3N3b3JkIiwidW5iaW5kIiwiaXNMb2dFbmFibGVkIiwiTERBUF9MT0dfRU5BQkxFRCIsIm1lc3NhZ2UiLCJkYXRhIiwiY29uc29sZSIsInN0cmluZ2lmeSIsInNsdWciLCJnZXRMZGFwVXNlcm5hbWUiLCJnZXRMZGFwRW1haWwiLCJnZXRMZGFwVXNlclVuaXF1ZUlEIiwic3luY1VzZXJEYXRhIiwiYWRkTGRhcFVzZXIiLCJmYWxsYmFja0RlZmF1bHRBY2NvdW50U3lzdGVtIiwiaW5kZXhPZiIsImVtYWlsIiwibG9naW5SZXF1ZXN0IiwidXNlciIsImRpZ2VzdCIsIlNIQTI1NiIsImFsZ29yaXRobSIsIkFjY291bnRzIiwiX3J1bkxvZ2luSGFuZGxlcnMiLCJyZWdpc3RlckxvZ2luSGFuZGxlciIsImxkYXAiLCJsZGFwT3B0aW9ucyIsImxkYXBQYXNzIiwic2VsZiIsInVzZXJzIiwidXNlclF1ZXJ5IiwiZmluZE9uZSIsImF1dGhlbnRpY2F0aW9uTWV0aG9kIiwic3RhbXBlZFRva2VuIiwiX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW4iLCJ1cGRhdGVfZGF0YSIsIiRwdXNoIiwiX2hhc2hTdGFtcGVkVG9rZW4iLCJSb2xlcyIsInNldFVzZXJSb2xlcyIsIl9pZCIsInVwZGF0ZSIsInNldFBhc3N3b3JkIiwibG9nb3V0IiwidXNlcklkIiwidG9rZW4iLCJnZXRQcm9wZXJ0eVZhbHVlIiwiZ2V0TGRhcEZ1bGxuYW1lIiwiZ2V0RGF0YVRvU3luY1VzZXJEYXRhIiwiaW1wb3J0TmV3VXNlcnMiLCJfIiwiZGVmaW5lUHJvcGVydHkiLCJwcm90b3R5cGUiLCJwcm9wIiwidG9Mb3dlckNhc2UiLCJlbnVtZXJhYmxlIiwidGV4dCIsInNsdWdpZnkiLCJ0ZW1wbGF0ZVZhckhhbmRsZXIiLCJ2YXJpYWJsZSIsIm9iamVjdCIsInRlbXBsYXRlUmVnZXgiLCJleGVjIiwidG1wVmFyaWFibGUiLCJoYXNPd25Qcm9wZXJ0eSIsInRtcGxWYXIiLCJ0bXBsQXR0ck5hbWUiLCJhdHRyVmFsIiwib2JqIiwicmVkdWNlIiwiYWNjIiwiZWwiLCJlcnIiLCJ1c2VybmFtZUZpZWxkIiwiZmllbGQiLCJnZXRMREFQVmFsdWUiLCJlbWFpbEZpZWxkIiwiZnVsbG5hbWVGaWVsZCIsImNvbmNhdCIsImZpbmQiLCJpc0VtcHR5Iiwic3luY1VzZXJEYXRhRmllbGRNYXAiLCJ0cmltIiwidXNlckRhdGEiLCJ3aGl0ZWxpc3RlZFVzZXJGaWVsZHMiLCJmaWVsZE1hcCIsImVtYWlsTGlzdCIsInVzZXJGaWVsZCIsImxkYXBGaWVsZCIsImlzT2JqZWN0IiwiYWRkcmVzcyIsInZlcmlmaWVkIiwib3V0ZXJLZXkiLCJpbm5lcktleXMiLCJjdXN0b21GaWVsZHNNZXRhIiwiZSIsInRtcFVzZXJGaWVsZCIsInRtcExkYXBGaWVsZCIsImRLZXlzIiwibGFzdEtleSIsImxhc3QiLCJjdXJyS2V5IiwiZW1haWxzIiwidW5pcXVlSWQiLCJzZXJ2aWNlcyIsImlkQXR0cmlidXRlIiwic2l6ZSIsIiRzZXQiLCJmdWxsbmFtZSIsInVzZXJPYmplY3QiLCJtYWlsIiwiY3JlYXRlVXNlciIsImNvdW50IiwiYmluZEVudmlyb25tZW50IiwibGRhcFVzZXJzIiwic3luYyIsIiRleGlzdHMiLCJqb2JOYW1lIiwiYWRkQ3JvbkpvYiIsImRlYm91bmNlIiwiYWRkQ3JvbkpvYkRlYm91bmNlZCIsIlN5bmNlZENyb24iLCJuZXh0U2NoZWR1bGVkQXREYXRlIiwicmVtb3ZlIiwiYWRkIiwic2NoZWR1bGUiLCJwYXJzZXIiLCJqb2IiLCJzdGFydCIsInN0YXJ0dXAiLCJkZWZlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBQUYsT0FBT0csTUFBUCxDQUFjO0FBQUNDLFdBQVEsTUFBSUM7QUFBYixDQUFkO0FBQWtDLElBQUlDLE1BQUo7QUFBV04sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDRSxVQUFRRyxDQUFSLEVBQVU7QUFBQ0QsYUFBT0MsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJQyxJQUFKO0FBQVNSLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0UsVUFBUUcsQ0FBUixFQUFVO0FBQUNDLFdBQUtELENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUUsTUFBSjtBQUFXVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNFLFVBQVFHLENBQVIsRUFBVTtBQUFDRSxhQUFPRixDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlHLFNBQUosRUFBY0MsUUFBZCxFQUF1QkMsUUFBdkIsRUFBZ0NDLFNBQWhDO0FBQTBDYixPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNRLFlBQVVILENBQVYsRUFBWTtBQUFDRyxnQkFBVUgsQ0FBVjtBQUFZLEdBQTFCOztBQUEyQkksV0FBU0osQ0FBVCxFQUFXO0FBQUNJLGVBQVNKLENBQVQ7QUFBVyxHQUFsRDs7QUFBbURLLFdBQVNMLENBQVQsRUFBVztBQUFDSyxlQUFTTCxDQUFUO0FBQVcsR0FBMUU7O0FBQTJFTSxZQUFVTixDQUFWLEVBQVk7QUFBQ00sZ0JBQVVOLENBQVY7QUFBWTs7QUFBcEcsQ0FBakMsRUFBdUksQ0FBdkk7O0FBS25RLE1BQU1GLElBQU4sQ0FBVztBQUN4QlMsZ0JBQWE7QUFDWCxTQUFLUixNQUFMLEdBQWNBLE1BQWQ7QUFFQSxTQUFLUyxTQUFMLEdBQWlCLEtBQWpCO0FBRUEsU0FBS0MsT0FBTCxHQUFlO0FBQ2JDLFlBQU0sS0FBS0gsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsV0FBOUIsQ0FETztBQUViQyxZQUFNLEtBQUtMLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLFdBQTlCLENBRk87QUFHYkUsaUJBQVcsS0FBS04sV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsZ0JBQTlCLENBSEU7QUFJYkcsZUFBUyxLQUFLUCxXQUFMLENBQWlCSSxZQUFqQixDQUE4QixjQUE5QixDQUpJO0FBS2JJLHVCQUFpQixLQUFLUixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixzQkFBOUIsQ0FMSjtBQU1iSyxvQkFBYyxLQUFLVCxXQUFMLENBQWlCSSxZQUFqQixDQUE4QixtQkFBOUIsQ0FORDtBQU9iTSxrQkFBWSxLQUFLVixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixpQkFBOUIsQ0FQQztBQVFiTyxlQUFTLEtBQUtYLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGNBQTlCLENBUkk7QUFTYlEsMkJBQXFCLEtBQUtaLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDBCQUE5QixLQUE2RCxLQVRyRTtBQVViUyxzQkFBZ0IsS0FBS2IsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsdUJBQTlCLENBVkg7QUFXYlUsNkJBQXVCLEtBQUtkLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDhCQUE5QixDQVhWO0FBWWJXLCtCQUF5QixLQUFLZixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixnQ0FBOUIsQ0FaWjtBQWFiWSwrQkFBeUIsS0FBS2hCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHFCQUE5QixDQWJaO0FBY2JhLGNBQVEsS0FBS2pCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGFBQTlCLENBZEs7QUFlYmMsMEJBQW9CLEtBQUtsQixXQUFMLENBQWlCSSxZQUFqQixDQUE4QixvQkFBOUIsQ0FmUDtBQWdCYmUsMEJBQW9CLEtBQUtuQixXQUFMLENBQWlCSSxZQUFqQixDQUE4Qix5QkFBOUIsQ0FoQlA7QUFpQmJnQix5QkFBbUIsS0FBS3BCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHdCQUE5QixDQWpCTjtBQWtCYmlCLHlCQUFtQixLQUFLckIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsd0JBQTlCLENBbEJOO0FBbUJia0Isd0JBQWtCLEtBQUt0QixXQUFMLENBQWlCSSxZQUFqQixDQUE4Qix1QkFBOUIsQ0FuQkw7QUFvQmJtQix5QkFBbUIsS0FBS3ZCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHdCQUE5QixDQXBCTjtBQXFCYm9CLDRCQUFzQixLQUFLeEIsV0FBTCxDQUFpQkksWUFBakIsQ0FBOEIsMEJBQTlCLENBckJUO0FBc0JicUIsaUNBQTJCLEtBQUt6QixXQUFMLENBQWlCSSxZQUFqQixDQUE4QiwrQkFBOUIsQ0F0QmQ7QUF1QmJzQix1Q0FBaUMsS0FBSzFCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHNDQUE5QixDQXZCcEI7QUF3QmJ1QiwyQ0FBcUMsS0FBSzNCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDBDQUE5QixDQXhCeEI7QUF5QmJ3Qix3Q0FBa0MsS0FBSzVCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLHVDQUE5QixDQXpCckI7QUEwQmJ5QiwrQkFBeUIsS0FBSzdCLFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLDhCQUE5QjtBQTFCWixLQUFmO0FBNEJEOztBQUVELFNBQU9BLFlBQVAsQ0FBb0IwQixJQUFwQixFQUEwQixHQUFHQyxJQUE3QixFQUFtQztBQUNqQyxRQUFJQyxRQUFRQyxRQUFRQyxHQUFSLENBQVlKLElBQVosQ0FBWjs7QUFDQSxRQUFJRSxVQUFVRyxTQUFkLEVBQXlCO0FBQ3ZCLFVBQUlILFVBQVUsTUFBVixJQUFvQkEsVUFBVSxPQUFsQyxFQUEyQztBQUN6Q0EsZ0JBQVFJLEtBQUtDLEtBQUwsQ0FBV0wsS0FBWCxDQUFSO0FBQ0QsT0FGRCxNQUVPLElBQUlBLFVBQVUsRUFBVixJQUFnQixDQUFDTSxNQUFNTixLQUFOLENBQXJCLEVBQW1DO0FBQ3hDQSxnQkFBUU8sT0FBT1AsS0FBUCxDQUFSO0FBQ0Q7O0FBQ0QsYUFBT0EsS0FBUDtBQUNELEtBUEQsTUFPTztBQUNMbEMsZUFBVSw4QkFBNkJnQyxJQUFLLEVBQTVDO0FBQ0Q7QUFDRjs7QUFDRFUsY0FBWSxHQUFHVCxJQUFmLEVBQXFCO0FBQ25CLFFBQUksQ0FBQyxLQUFLVSxZQUFWLEVBQXdCO0FBQ3RCLFdBQUtBLFlBQUwsR0FBb0JDLE9BQU9DLFNBQVAsQ0FBaUIsS0FBS0MsWUFBdEIsRUFBb0MsSUFBcEMsQ0FBcEI7QUFDRDs7QUFDRCxXQUFPLEtBQUtILFlBQUwsQ0FBa0IsR0FBR1YsSUFBckIsQ0FBUDtBQUNEOztBQUVEYyxnQkFBYyxHQUFHZCxJQUFqQixFQUF1QjtBQUNyQixRQUFJLENBQUMsS0FBS2UsY0FBVixFQUEwQjtBQUN4QixXQUFLQSxjQUFMLEdBQXNCSixPQUFPQyxTQUFQLENBQWlCLEtBQUtJLGNBQXRCLEVBQXNDLElBQXRDLENBQXRCO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLRCxjQUFMLENBQW9CLEdBQUdmLElBQXZCLENBQVA7QUFDRDs7QUFFRGEsZUFBYUksUUFBYixFQUF1QjtBQUNyQm5ELGFBQVMsWUFBVDtBQUVBLFFBQUlvRCxVQUFVLEtBQWQ7QUFFQSxVQUFNQyxvQkFBb0I7QUFDeEJDLFdBQU0sR0FBRyxLQUFLakQsT0FBTCxDQUFhQyxJQUFNLElBQUksS0FBS0QsT0FBTCxDQUFhRyxJQUFNLEVBRDNCO0FBRXhCRSxlQUFTLEtBQUtMLE9BQUwsQ0FBYUssT0FGRTtBQUd4QjZDLHNCQUFnQixLQUFLbEQsT0FBTCxDQUFhTSxlQUhMO0FBSXhCNkMsbUJBQWEsS0FBS25ELE9BQUwsQ0FBYU8sWUFKRjtBQUt4QjZDLGlCQUFXLEtBQUtwRCxPQUFMLENBQWFJO0FBTEEsS0FBMUI7O0FBUUEsUUFBSSxLQUFLSixPQUFMLENBQWFnQixrQkFBYixLQUFvQyxVQUF4QyxFQUFvRDtBQUNsRGdDLHdCQUFrQkssR0FBbEIsR0FBd0IsSUFBSTVELE1BQUosQ0FBVztBQUNqQ21DLGNBQU0sUUFEMkI7QUFFakMwQixtQkFBVyxRQUZzQjtBQUdqQ0MsZ0JBQVF4QixRQUFReUIsTUFIaUI7QUFJakNDLGVBQU8sS0FBS3pELE9BQUwsQ0FBYWdCO0FBSmEsT0FBWCxDQUF4QjtBQU1EOztBQUVELFVBQU0wQyxhQUFhO0FBQ2pCQywwQkFBb0IsS0FBSzNELE9BQUwsQ0FBYVU7QUFEaEIsS0FBbkI7O0FBSUEsUUFBSSxLQUFLVixPQUFMLENBQWFTLE9BQWIsSUFBd0IsS0FBS1QsT0FBTCxDQUFhUyxPQUFiLEtBQXlCLEVBQXJELEVBQXlEO0FBQ3ZEO0FBQ0EsWUFBTW1ELGFBQWEsS0FBSzlELFdBQUwsQ0FBaUJJLFlBQWpCLENBQThCLGNBQTlCLEVBQThDMkQsS0FBOUMsQ0FBb0QsSUFBcEQsQ0FBbkI7QUFDQSxVQUFJQyxPQUFPLEVBQVg7QUFDQSxZQUFNQyxLQUFLLEVBQVg7QUFDQUgsaUJBQVdJLE9BQVgsQ0FBb0JDLElBQUQsSUFBVTtBQUMzQkgsYUFBS0ksSUFBTCxDQUFVRCxJQUFWOztBQUNBLFlBQUlBLEtBQUtFLEtBQUwsQ0FBVyxtQkFBWCxDQUFKLEVBQXFDO0FBQ25DSixhQUFHRyxJQUFILENBQVFKLEtBQUtNLElBQUwsQ0FBVSxJQUFWLENBQVI7QUFDQU4saUJBQU8sRUFBUDtBQUNEO0FBQ0YsT0FORDtBQU9BSixpQkFBV0ssRUFBWCxHQUFnQkEsRUFBaEI7QUFDRDs7QUFFRCxRQUFJLEtBQUsvRCxPQUFMLENBQWFRLFVBQWIsS0FBNEIsS0FBaEMsRUFBdUM7QUFDckN3Qyx3QkFBa0JDLEdBQWxCLEdBQXlCLFdBQVdELGtCQUFrQkMsR0FBSyxFQUEzRDtBQUNBRCx3QkFBa0JVLFVBQWxCLEdBQStCQSxVQUEvQjtBQUNELEtBSEQsTUFHTztBQUNMVix3QkFBa0JDLEdBQWxCLEdBQXlCLFVBQVVELGtCQUFrQkMsR0FBSyxFQUExRDtBQUNEOztBQUVEdEQsYUFBUyxZQUFULEVBQXVCcUQsa0JBQWtCQyxHQUF6QztBQUNBdkQsY0FBVyxvQkFBcUJGLEtBQUs2RSxPQUFMLENBQWFyQixpQkFBYixDQUFnQyxFQUFoRTtBQUVBLFNBQUtzQixNQUFMLEdBQWNoRixPQUFPaUYsWUFBUCxDQUFvQnZCLGlCQUFwQixDQUFkO0FBRUEsU0FBS3dCLFFBQUwsR0FBZ0JoQyxPQUFPQyxTQUFQLENBQWlCLEtBQUs2QixNQUFMLENBQVlHLElBQTdCLEVBQW1DLEtBQUtILE1BQXhDLENBQWhCO0FBRUEsU0FBS0EsTUFBTCxDQUFZSSxFQUFaLENBQWUsT0FBZixFQUF5QkMsS0FBRCxJQUFXO0FBQ2pDOUUsZ0JBQVUsWUFBVixFQUF3QjhFLEtBQXhCOztBQUNBLFVBQUk1QixZQUFZLEtBQWhCLEVBQXVCO0FBQ3JCQSxrQkFBVSxJQUFWO0FBQ0FELGlCQUFTNkIsS0FBVCxFQUFnQixJQUFoQjtBQUNEO0FBQ0YsS0FORDtBQVFBLFNBQUtMLE1BQUwsQ0FBWUksRUFBWixDQUFlLE1BQWYsRUFBdUIsTUFBTTtBQUMzQi9FLGVBQVMsTUFBVDtBQUNBLFdBQUtpRixVQUFMO0FBQ0QsS0FIRDtBQUtBLFNBQUtOLE1BQUwsQ0FBWUksRUFBWixDQUFlLE9BQWYsRUFBd0IsTUFBTTtBQUM1Qi9FLGVBQVMsUUFBVDtBQUNELEtBRkQ7O0FBSUEsUUFBSSxLQUFLSyxPQUFMLENBQWFRLFVBQWIsS0FBNEIsS0FBaEMsRUFBdUM7QUFDckM7QUFDQTtBQUNBO0FBQ0FrRCxpQkFBV3pELElBQVgsR0FBa0IsS0FBS0QsT0FBTCxDQUFhQyxJQUEvQjtBQUVBTixlQUFTLGNBQVQ7QUFDQUQsZ0JBQVUsWUFBVixFQUF3QmdFLFVBQXhCO0FBRUEsV0FBS1ksTUFBTCxDQUFZTyxRQUFaLENBQXFCbkIsVUFBckIsRUFBaUMsSUFBakMsRUFBdUMsQ0FBQ2lCLEtBQUQsRUFBUUcsUUFBUixLQUFxQjtBQUMxRCxZQUFJSCxLQUFKLEVBQVc7QUFDVDlFLG9CQUFVLGdCQUFWLEVBQTRCOEUsS0FBNUI7O0FBQ0EsY0FBSTVCLFlBQVksS0FBaEIsRUFBdUI7QUFDckJBLHNCQUFVLElBQVY7QUFDQUQscUJBQVM2QixLQUFULEVBQWdCLElBQWhCO0FBQ0Q7O0FBQ0Q7QUFDRDs7QUFFRGhGLGlCQUFTLGVBQVQ7QUFDQSxhQUFLSSxTQUFMLEdBQWlCLElBQWpCOztBQUNBLFlBQUlnRCxZQUFZLEtBQWhCLEVBQXVCO0FBQ3JCQSxvQkFBVSxJQUFWO0FBQ0FELG1CQUFTLElBQVQsRUFBZWdDLFFBQWY7QUFDRDtBQUNGLE9BaEJEO0FBaUJELEtBMUJELE1BMEJPO0FBQ0wsV0FBS1IsTUFBTCxDQUFZSSxFQUFaLENBQWUsU0FBZixFQUEyQkksUUFBRCxJQUFjO0FBQ3RDbkYsaUJBQVMsZ0JBQVQ7QUFDQSxhQUFLSSxTQUFMLEdBQWlCLElBQWpCOztBQUNBLFlBQUlnRCxZQUFZLEtBQWhCLEVBQXVCO0FBQ3JCQSxvQkFBVSxJQUFWO0FBQ0FELG1CQUFTLElBQVQsRUFBZWdDLFFBQWY7QUFDRDtBQUNGLE9BUEQ7QUFRRDs7QUFFREMsZUFBVyxNQUFNO0FBQ2YsVUFBSWhDLFlBQVksS0FBaEIsRUFBdUI7QUFDckJsRCxrQkFBVSxxQkFBVixFQUFpQ21ELGtCQUFrQkUsY0FBbkQ7QUFDQUgsa0JBQVUsSUFBVjtBQUNBRCxpQkFBUyxJQUFJa0MsS0FBSixDQUFVLFNBQVYsQ0FBVDtBQUNEO0FBQ0YsS0FORCxFQU1HaEMsa0JBQWtCRSxjQU5yQjtBQU9EOztBQUVEK0IsZ0JBQWNDLFFBQWQsRUFBd0I7QUFDdEIsVUFBTUMsU0FBUyxFQUFmOztBQUVBLFFBQUksS0FBS25GLE9BQUwsQ0FBYWlCLGtCQUFiLEtBQW9DLEVBQXhDLEVBQTRDO0FBQzFDLFVBQUksS0FBS2pCLE9BQUwsQ0FBYWlCLGtCQUFiLENBQWdDLENBQWhDLE1BQXVDLEdBQTNDLEVBQWdEO0FBQzlDa0UsZUFBT2pCLElBQVAsQ0FBYSxHQUFHLEtBQUtsRSxPQUFMLENBQWFpQixrQkFBb0IsRUFBakQ7QUFDRCxPQUZELE1BRU87QUFDTGtFLGVBQU9qQixJQUFQLENBQWEsSUFBSSxLQUFLbEUsT0FBTCxDQUFhaUIsa0JBQW9CLEdBQWxEO0FBQ0Q7QUFDRjs7QUFFRCxVQUFNbUUsaUJBQWlCLEtBQUtwRixPQUFMLENBQWFtQixpQkFBYixDQUErQjBDLEtBQS9CLENBQXFDLEdBQXJDLEVBQTBDd0IsR0FBMUMsQ0FBK0NDLElBQUQsSUFBVyxJQUFJQSxJQUFNLElBQUlKLFFBQVUsR0FBakYsQ0FBdkI7O0FBRUEsUUFBSUUsZUFBZUcsTUFBZixLQUEwQixDQUE5QixFQUFpQztBQUMvQjFGLGdCQUFVLHlDQUFWO0FBQ0QsS0FGRCxNQUVPLElBQUl1RixlQUFlRyxNQUFmLEtBQTBCLENBQTlCLEVBQWlDO0FBQ3RDSixhQUFPakIsSUFBUCxDQUFhLEdBQUdrQixlQUFlLENBQWYsQ0FBbUIsRUFBbkM7QUFDRCxLQUZNLE1BRUE7QUFDTEQsYUFBT2pCLElBQVAsQ0FBYSxLQUFLa0IsZUFBZWhCLElBQWYsQ0FBb0IsRUFBcEIsQ0FBeUIsR0FBM0M7QUFDRDs7QUFFRCxXQUFRLEtBQUtlLE9BQU9mLElBQVAsQ0FBWSxFQUFaLENBQWlCLEdBQTlCO0FBQ0Q7O0FBRURvQixvQkFBa0I7QUFDaEIsUUFBSSxLQUFLQyxZQUFMLEtBQXNCLElBQTFCLEVBQWdDO0FBQzlCO0FBQ0Q7O0FBRUQsUUFBSSxLQUFLekYsT0FBTCxDQUFhVyxjQUFiLEtBQWdDLElBQXBDLEVBQTBDO0FBQ3hDO0FBQ0Q7O0FBRURoQixhQUFTLGdCQUFULEVBQTJCLEtBQUtLLE9BQUwsQ0FBYVkscUJBQXhDO0FBQ0EsU0FBSzRELFFBQUwsQ0FBYyxLQUFLeEUsT0FBTCxDQUFhWSxxQkFBM0IsRUFBa0QsS0FBS1osT0FBTCxDQUFhYSx1QkFBL0Q7QUFDQSxTQUFLNEUsWUFBTCxHQUFvQixJQUFwQjtBQUNEOztBQUVEQyxrQkFBZ0JSLFFBQWhCLEVBQTBCUyxJQUExQixFQUFnQztBQUM5QixTQUFLSCxlQUFMO0FBRUEsVUFBTUksZ0JBQWdCO0FBQ3BCVCxjQUFRLEtBQUtGLGFBQUwsQ0FBbUJDLFFBQW5CLENBRFk7QUFFcEJXLGFBQU8sS0FBSzdGLE9BQUwsQ0FBYWtCLGlCQUFiLElBQWtDLEtBRnJCO0FBR3BCNEUsaUJBQVcsS0FBSzlGLE9BQUwsQ0FBYXFCO0FBSEosS0FBdEI7O0FBTUEsUUFBSSxLQUFLckIsT0FBTCxDQUFhb0IsZ0JBQWIsR0FBZ0MsQ0FBcEMsRUFBdUM7QUFDckN3RSxvQkFBY0csS0FBZCxHQUFzQjtBQUNwQkMsa0JBQVUsS0FBS2hHLE9BQUwsQ0FBYW9CLGdCQURIO0FBRXBCNkUsbUJBQVcsQ0FBQyxDQUFDTjtBQUZPLE9BQXRCO0FBSUQ7O0FBRURoRyxhQUFTLGdCQUFULEVBQTJCdUYsUUFBM0I7QUFDQXhGLGNBQVUsZUFBVixFQUEyQmtHLGFBQTNCO0FBQ0FsRyxjQUFVLFFBQVYsRUFBb0IsS0FBS00sT0FBTCxDQUFhZSxNQUFqQzs7QUFFQSxRQUFJNEUsSUFBSixFQUFVO0FBQ1IsYUFBTyxLQUFLTyxjQUFMLENBQW9CLEtBQUtsRyxPQUFMLENBQWFlLE1BQWpDLEVBQXlDNkUsYUFBekMsRUFBd0RELElBQXhELENBQVA7QUFDRDs7QUFFRCxXQUFPLEtBQUtoRCxhQUFMLENBQW1CLEtBQUszQyxPQUFMLENBQWFlLE1BQWhDLEVBQXdDNkUsYUFBeEMsQ0FBUDtBQUNEOztBQUVETyxrQkFBZ0JDLEVBQWhCLEVBQW9CQyxTQUFwQixFQUErQjtBQUM3QixTQUFLYixlQUFMO0FBRUEsVUFBTWMsMEJBQTBCLEtBQUt4RyxXQUFMLENBQWlCSSxZQUFqQixDQUE4Qiw4QkFBOUIsRUFBOEQyRCxLQUE5RCxDQUFvRSxHQUFwRSxDQUFoQztBQUVBLFFBQUlzQixNQUFKOztBQUVBLFFBQUlrQixTQUFKLEVBQWU7QUFDYmxCLGVBQVMsSUFBSSxLQUFLN0YsTUFBTCxDQUFZaUgsT0FBWixDQUFvQkMsY0FBeEIsQ0FBdUM7QUFDOUNILGlCQUQ4QztBQUU5Q3ZFLGVBQU8sSUFBSTJFLE1BQUosQ0FBV0wsRUFBWCxFQUFlLEtBQWY7QUFGdUMsT0FBdkMsQ0FBVDtBQUlELEtBTEQsTUFLTztBQUNMLFlBQU1HLFVBQVUsRUFBaEI7QUFDQUQsOEJBQXdCdEMsT0FBeEIsQ0FBaUNzQixJQUFELElBQVU7QUFDeENpQixnQkFBUXJDLElBQVIsQ0FBYSxJQUFJLEtBQUs1RSxNQUFMLENBQVlpSCxPQUFaLENBQW9CQyxjQUF4QixDQUF1QztBQUNsREgscUJBQVdmLElBRHVDO0FBRWxEeEQsaUJBQU8sSUFBSTJFLE1BQUosQ0FBV0wsRUFBWCxFQUFlLEtBQWY7QUFGMkMsU0FBdkMsQ0FBYjtBQUlELE9BTEQ7QUFPQWpCLGVBQVMsSUFBSSxLQUFLN0YsTUFBTCxDQUFZaUgsT0FBWixDQUFvQkcsUUFBeEIsQ0FBaUM7QUFBQ0g7QUFBRCxPQUFqQyxDQUFUO0FBQ0Q7O0FBRUQsVUFBTVgsZ0JBQWdCO0FBQ3BCVCxZQURvQjtBQUVwQlUsYUFBTztBQUZhLEtBQXRCO0FBS0FsRyxhQUFTLGlCQUFULEVBQTRCeUcsRUFBNUI7QUFDQTFHLGNBQVUsZUFBVixFQUEyQmtHLGNBQWNULE1BQWQsQ0FBcUJ3QixRQUFyQixFQUEzQjtBQUNBakgsY0FBVSxRQUFWLEVBQW9CLEtBQUtNLE9BQUwsQ0FBYWUsTUFBakM7QUFFQSxVQUFNNkYsU0FBUyxLQUFLakUsYUFBTCxDQUFtQixLQUFLM0MsT0FBTCxDQUFhZSxNQUFoQyxFQUF3QzZFLGFBQXhDLENBQWY7O0FBRUEsUUFBSSxDQUFDaUIsTUFBTUMsT0FBTixDQUFjRixNQUFkLENBQUQsSUFBMEJBLE9BQU9yQixNQUFQLEtBQWtCLENBQWhELEVBQW1EO0FBQ2pEO0FBQ0Q7O0FBRUQsUUFBSXFCLE9BQU9yQixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCMUYsZ0JBQVUsY0FBVixFQUEwQnVHLEVBQTFCLEVBQThCLFVBQTlCLEVBQTBDUSxPQUFPckIsTUFBakQsRUFBeUQsU0FBekQ7QUFDRDs7QUFFRCxXQUFPcUIsT0FBTyxDQUFQLENBQVA7QUFDRDs7QUFFREcsd0JBQXNCN0IsUUFBdEIsRUFBZ0M7QUFDOUIsU0FBS00sZUFBTDtBQUVBLFVBQU1JLGdCQUFnQjtBQUNwQlQsY0FBUSxLQUFLRixhQUFMLENBQW1CQyxRQUFuQixDQURZO0FBRXBCVyxhQUFPLEtBQUs3RixPQUFMLENBQWFrQixpQkFBYixJQUFrQztBQUZyQixLQUF0QjtBQUtBdkIsYUFBUyxnQkFBVCxFQUEyQnVGLFFBQTNCO0FBQ0F4RixjQUFVLGVBQVYsRUFBMkJrRyxhQUEzQjtBQUNBbEcsY0FBVSxRQUFWLEVBQW9CLEtBQUtNLE9BQUwsQ0FBYWUsTUFBakM7QUFFQSxVQUFNNkYsU0FBUyxLQUFLakUsYUFBTCxDQUFtQixLQUFLM0MsT0FBTCxDQUFhZSxNQUFoQyxFQUF3QzZFLGFBQXhDLENBQWY7O0FBRUEsUUFBSSxDQUFDaUIsTUFBTUMsT0FBTixDQUFjRixNQUFkLENBQUQsSUFBMEJBLE9BQU9yQixNQUFQLEtBQWtCLENBQWhELEVBQW1EO0FBQ2pEO0FBQ0Q7O0FBRUQsUUFBSXFCLE9BQU9yQixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCMUYsZ0JBQVUsb0JBQVYsRUFBZ0NxRixRQUFoQyxFQUEwQyxVQUExQyxFQUFzRDBCLE9BQU9yQixNQUE3RCxFQUFxRSxTQUFyRTtBQUNEOztBQUVELFdBQU9xQixPQUFPLENBQVAsQ0FBUDtBQUNEOztBQUVESSxnQkFBYzlCLFFBQWQsRUFBd0IrQixRQUF4QixFQUFpQztBQUMvQixRQUFJLENBQUMsS0FBS2pILE9BQUwsQ0FBYXNCLG9CQUFsQixFQUF3QztBQUN0QyxhQUFPLElBQVA7QUFDRDs7QUFFRCxVQUFNNkQsU0FBUyxDQUFDLElBQUQsQ0FBZjs7QUFFQSxRQUFJLEtBQUtuRixPQUFMLENBQWF1Qix5QkFBYixLQUEyQyxFQUEvQyxFQUFtRDtBQUNqRDRELGFBQU9qQixJQUFQLENBQWEsZ0JBQWdCLEtBQUtsRSxPQUFMLENBQWF1Qix5QkFBMkIsR0FBckU7QUFDRDs7QUFFRCxRQUFJLEtBQUt2QixPQUFMLENBQWF5QixtQ0FBYixLQUFxRCxFQUF6RCxFQUE2RDtBQUMzRCxZQUFNeUYsZUFBZUQsU0FBUyxLQUFLakgsT0FBTCxDQUFhMEIsZ0NBQXRCLENBQXJCOztBQUNBLFVBQUl3RixZQUFKLEVBQW1CO0FBQ2pCL0IsZUFBT2pCLElBQVAsQ0FBYSxJQUFJLEtBQUtsRSxPQUFMLENBQWF5QixtQ0FBcUMsSUFBSXlGLFlBQWMsR0FBckY7QUFDRDtBQUNGOztBQUVEL0IsV0FBT2pCLElBQVAsQ0FBWSxHQUFaO0FBRUEsVUFBTTBCLGdCQUFnQjtBQUNwQlQsY0FBUUEsT0FBT2YsSUFBUCxDQUFZLEVBQVosRUFBZ0IrQyxPQUFoQixDQUF3QixjQUF4QixFQUF3Q2pDLFFBQXhDLENBRFk7QUFFcEJXLGFBQU87QUFGYSxLQUF0QjtBQUtBbkcsY0FBVSx5QkFBVixFQUFxQ2tHLGNBQWNULE1BQW5EO0FBRUEsVUFBTXlCLFNBQVMsS0FBS2pFLGFBQUwsQ0FBbUIsS0FBSzNDLE9BQUwsQ0FBYWUsTUFBaEMsRUFBd0M2RSxhQUF4QyxDQUFmOztBQUVBLFFBQUksQ0FBQ2lCLE1BQU1DLE9BQU4sQ0FBY0YsTUFBZCxDQUFELElBQTBCQSxPQUFPckIsTUFBUCxLQUFrQixDQUFoRCxFQUFtRDtBQUNqRCxhQUFPLEVBQVA7QUFDRDs7QUFFRCxVQUFNNkIsaUJBQWlCLEtBQUtwSCxPQUFMLENBQWF3QiwrQkFBYixJQUFnRCxJQUF2RTtBQUNBLFVBQU02RixTQUFTLEVBQWY7QUFDQVQsV0FBT3ZCLEdBQVAsQ0FBWUMsSUFBRCxJQUFVO0FBQ25CK0IsYUFBT25ELElBQVAsQ0FBYW9CLEtBQU04QixjQUFOLENBQWI7QUFDRCxLQUZEO0FBR0ExSCxjQUFXLFdBQVkySCxPQUFPakQsSUFBUCxDQUFZLElBQVosQ0FBa0IsRUFBekM7QUFDQSxXQUFPaUQsTUFBUDtBQUVEOztBQUVEQyxnQkFBY3BDLFFBQWQsRUFBd0IrQixRQUF4QixFQUFrQztBQUNoQyxRQUFJLENBQUMsS0FBS2pILE9BQUwsQ0FBYXNCLG9CQUFsQixFQUF3QztBQUN0QyxhQUFPLElBQVA7QUFDRDs7QUFFRCxVQUFNaUcsT0FBTyxLQUFLUCxhQUFMLENBQW1COUIsUUFBbkIsRUFBNkIrQixRQUE3QixDQUFiO0FBRUEsVUFBTTlCLFNBQVMsQ0FBQyxJQUFELENBQWY7O0FBRUEsUUFBSSxLQUFLbkYsT0FBTCxDQUFhdUIseUJBQWIsS0FBMkMsRUFBL0MsRUFBbUQ7QUFDakQ0RCxhQUFPakIsSUFBUCxDQUFhLGdCQUFnQixLQUFLbEUsT0FBTCxDQUFhdUIseUJBQTJCLEdBQXJFO0FBQ0Q7O0FBRUQsUUFBSSxLQUFLdkIsT0FBTCxDQUFheUIsbUNBQWIsS0FBcUQsRUFBekQsRUFBNkQ7QUFDM0QsWUFBTXlGLGVBQWVELFNBQVMsS0FBS2pILE9BQUwsQ0FBYTBCLGdDQUF0QixDQUFyQjs7QUFDQSxVQUFJd0YsWUFBSixFQUFtQjtBQUNqQi9CLGVBQU9qQixJQUFQLENBQWEsSUFBSSxLQUFLbEUsT0FBTCxDQUFheUIsbUNBQXFDLElBQUl5RixZQUFjLEdBQXJGO0FBQ0Q7QUFDRjs7QUFFRCxRQUFJLEtBQUtsSCxPQUFMLENBQWF3QiwrQkFBYixLQUFpRCxFQUFyRCxFQUF5RDtBQUN2RDJELGFBQU9qQixJQUFQLENBQWEsSUFBSSxLQUFLbEUsT0FBTCxDQUFhd0IsK0JBQWlDLElBQUksS0FBS3hCLE9BQUwsQ0FBYTJCLHVCQUF5QixHQUF6RztBQUNEOztBQUNEd0QsV0FBT2pCLElBQVAsQ0FBWSxHQUFaO0FBRUEsVUFBTTBCLGdCQUFnQjtBQUNwQlQsY0FBUUEsT0FBT2YsSUFBUCxDQUFZLEVBQVosRUFBZ0IrQyxPQUFoQixDQUF3QixjQUF4QixFQUF3Q2pDLFFBQXhDLENBRFk7QUFFcEJXLGFBQU87QUFGYSxLQUF0QjtBQUtBbkcsY0FBVSxvQkFBVixFQUFnQ2tHLGNBQWNULE1BQTlDO0FBRUEsVUFBTXlCLFNBQVMsS0FBS2pFLGFBQUwsQ0FBbUIsS0FBSzNDLE9BQUwsQ0FBYWUsTUFBaEMsRUFBd0M2RSxhQUF4QyxDQUFmOztBQUVBLFFBQUksQ0FBQ2lCLE1BQU1DLE9BQU4sQ0FBY0YsTUFBZCxDQUFELElBQTBCQSxPQUFPckIsTUFBUCxLQUFrQixDQUFoRCxFQUFtRDtBQUNqRCxhQUFPLEtBQVA7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFFRGlDLHVCQUFxQkMsS0FBckIsRUFBNEI7QUFDMUIsVUFBTUMsU0FBUztBQUNiQyxZQUFNRixNQUFNRztBQURDLEtBQWY7QUFJQUMsV0FBT0MsSUFBUCxDQUFZSixPQUFPQyxJQUFuQixFQUF5QjNELE9BQXpCLENBQWtDK0QsR0FBRCxJQUFTO0FBQ3hDLFlBQU1qRyxRQUFRNEYsT0FBT0MsSUFBUCxDQUFZSSxHQUFaLENBQWQ7O0FBRUEsVUFBSSxDQUFDLENBQUMsZ0JBQUQsRUFBbUIsV0FBbkIsRUFBZ0NDLFFBQWhDLENBQXlDRCxHQUF6QyxDQUFMLEVBQW9EO0FBQ2xELFlBQUlqRyxpQkFBaUIyRSxNQUFyQixFQUE2QjtBQUMzQmlCLGlCQUFPSyxHQUFQLElBQWNqRyxNQUFNNkUsUUFBTixFQUFkO0FBQ0QsU0FGRCxNQUVPO0FBQ0xlLGlCQUFPSyxHQUFQLElBQWNqRyxLQUFkO0FBQ0Q7QUFDRjtBQUNGLEtBVkQ7QUFZQSxXQUFPNEYsTUFBUDtBQUNEOztBQUVEeEIsaUJBQWVuRixNQUFmLEVBQXVCZixPQUF2QixFQUFnQzJGLElBQWhDLEVBQXNDO0FBQ3BDLFNBQUtILGVBQUw7O0FBRUEsVUFBTXlDLGNBQWMsQ0FBQztBQUFDQyxhQUFEO0FBQVVDLFdBQVY7QUFBaUJDLFNBQWpCO0FBQXNCQztBQUF0QixLQUFELEtBQWlDO0FBQ25EMUksZUFBU3dJLEtBQVQsRUFEbUQsQ0FFbkQ7O0FBQ0EsV0FBSzdELE1BQUwsQ0FBWWdFLFdBQVosQ0FBd0IsSUFBeEI7O0FBQ0EzQyxXQUFLLElBQUwsRUFBV3VDLE9BQVgsRUFBb0I7QUFBQ0UsV0FBRDtBQUFNQyxjQUFNLE1BQU07QUFDcEM7QUFDQSxlQUFLL0QsTUFBTCxDQUFZZ0UsV0FBWjs7QUFDQUQsa0JBQVFBLE1BQVI7QUFDRDtBQUptQixPQUFwQjtBQUtELEtBVEQ7O0FBV0EsU0FBSy9ELE1BQUwsQ0FBWWlFLE1BQVosQ0FBbUJ4SCxNQUFuQixFQUEyQmYsT0FBM0IsRUFBb0MsQ0FBQzJFLEtBQUQsRUFBUTZELEdBQVIsS0FBZ0I7QUFDbEQsVUFBSTdELEtBQUosRUFBVztBQUNUOUUsa0JBQVU4RSxLQUFWO0FBQ0FnQixhQUFLaEIsS0FBTDtBQUNBO0FBQ0Q7O0FBRUQ2RCxVQUFJOUQsRUFBSixDQUFPLE9BQVAsRUFBaUJDLEtBQUQsSUFBVztBQUN6QjlFLGtCQUFVOEUsS0FBVjtBQUNBZ0IsYUFBS2hCLEtBQUw7QUFDQTtBQUNELE9BSkQ7QUFNQSxVQUFJdUQsVUFBVSxFQUFkO0FBRUEsWUFBTU8sbUJBQW1CekksUUFBUStGLEtBQVIsSUFBaUIvRixRQUFRK0YsS0FBUixDQUFjQyxRQUFkLEdBQXlCLENBQTFDLEdBQThDaEcsUUFBUStGLEtBQVIsQ0FBY0MsUUFBZCxHQUF5QixDQUF2RSxHQUEyRSxHQUFwRztBQUVBd0MsVUFBSTlELEVBQUosQ0FBTyxhQUFQLEVBQXVCK0MsS0FBRCxJQUFXO0FBQy9CUyxnQkFBUWhFLElBQVIsQ0FBYSxLQUFLc0Qsb0JBQUwsQ0FBMEJDLEtBQTFCLENBQWI7O0FBRUEsWUFBSVMsUUFBUTNDLE1BQVIsSUFBa0JrRCxnQkFBdEIsRUFBd0M7QUFDdENSLHNCQUFZO0FBQ1ZDLG1CQURVO0FBRVZDLG1CQUFPLGVBRkc7QUFHVkMsaUJBQUs7QUFISyxXQUFaO0FBS0FGLG9CQUFVLEVBQVY7QUFDRDtBQUNGLE9BWEQ7QUFhQU0sVUFBSTlELEVBQUosQ0FBTyxNQUFQLEVBQWUsQ0FBQ2tDLE1BQUQsRUFBU3lCLElBQVQsS0FBa0I7QUFDL0IsWUFBSSxDQUFDQSxJQUFMLEVBQVc7QUFDVCxlQUFLL0QsTUFBTCxDQUFZZ0UsV0FBWixDQUF3QixJQUF4Qjs7QUFDQUwsc0JBQVk7QUFDVkMsbUJBRFU7QUFFVkMsbUJBQU8sWUFGRztBQUdWQyxpQkFBSztBQUhLLFdBQVo7QUFLRCxTQVBELE1BT08sSUFBSUYsUUFBUTNDLE1BQVosRUFBb0I7QUFDekI1RixtQkFBUyxNQUFUO0FBQ0FzSSxzQkFBWTtBQUNWQyxtQkFEVTtBQUVWQyxtQkFBTyxNQUZHO0FBR1ZDLGlCQUFLLEtBSEs7QUFJVkM7QUFKVSxXQUFaO0FBTUFILG9CQUFVLEVBQVY7QUFDRDtBQUNGLE9BbEJEO0FBb0JBTSxVQUFJOUQsRUFBSixDQUFPLEtBQVAsRUFBYyxNQUFNO0FBQ2xCLFlBQUl3RCxRQUFRM0MsTUFBWixFQUFvQjtBQUNsQjBDLHNCQUFZO0FBQ1ZDLG1CQURVO0FBRVZDLG1CQUFPLFlBRkc7QUFHVkMsaUJBQUs7QUFISyxXQUFaO0FBS0FGLG9CQUFVLEVBQVY7QUFDRDtBQUNGLE9BVEQ7QUFVRCxLQTVERDtBQTZERDs7QUFFRHJGLGlCQUFlOUIsTUFBZixFQUF1QmYsT0FBdkIsRUFBZ0M4QyxRQUFoQyxFQUEwQztBQUN4QyxTQUFLMEMsZUFBTDtBQUVBLFNBQUtsQixNQUFMLENBQVlpRSxNQUFaLENBQW1CeEgsTUFBbkIsRUFBMkJmLE9BQTNCLEVBQW9DLENBQUMyRSxLQUFELEVBQVE2RCxHQUFSLEtBQWdCO0FBQ2xELFVBQUk3RCxLQUFKLEVBQVc7QUFDVDlFLGtCQUFVOEUsS0FBVjtBQUNBN0IsaUJBQVM2QixLQUFUO0FBQ0E7QUFDRDs7QUFFRDZELFVBQUk5RCxFQUFKLENBQU8sT0FBUCxFQUFpQkMsS0FBRCxJQUFXO0FBQ3pCOUUsa0JBQVU4RSxLQUFWO0FBQ0E3QixpQkFBUzZCLEtBQVQ7QUFDQTtBQUNELE9BSkQ7QUFNQSxZQUFNdUQsVUFBVSxFQUFoQjtBQUVBTSxVQUFJOUQsRUFBSixDQUFPLGFBQVAsRUFBdUIrQyxLQUFELElBQVc7QUFDL0JTLGdCQUFRaEUsSUFBUixDQUFhLEtBQUtzRCxvQkFBTCxDQUEwQkMsS0FBMUIsQ0FBYjtBQUNELE9BRkQ7QUFJQWUsVUFBSTlELEVBQUosQ0FBTyxLQUFQLEVBQWMsTUFBTTtBQUNsQi9FLGlCQUFTLHFCQUFULEVBQWdDdUksUUFBUTNDLE1BQXhDO0FBQ0F6QyxpQkFBUyxJQUFULEVBQWVvRixPQUFmO0FBQ0QsT0FIRDtBQUlELEtBdkJEO0FBd0JEOztBQUVEUSxXQUFTQyxFQUFULEVBQWFDLFFBQWIsRUFBdUI7QUFDckJqSixhQUFTLGdCQUFULEVBQTJCZ0osRUFBM0I7O0FBRUEsUUFBSTtBQUNGLFVBQUlDLGFBQWEsRUFBakIsRUFBcUI7QUFDbkIsY0FBTSxJQUFJNUQsS0FBSixDQUFVLDBCQUFWLENBQU47QUFDRDs7QUFDRCxXQUFLUixRQUFMLENBQWNtRSxFQUFkLEVBQWtCQyxRQUFsQjtBQUNBakosZUFBUyxlQUFULEVBQTBCZ0osRUFBMUI7QUFDQSxhQUFPLElBQVA7QUFDRCxLQVBELENBT0UsT0FBT2hFLEtBQVAsRUFBYztBQUNkaEYsZUFBUyxtQkFBVCxFQUE4QmdKLEVBQTlCO0FBQ0FqSixnQkFBVSxPQUFWLEVBQW1CaUYsS0FBbkI7QUFDQSxhQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVEQyxlQUFhO0FBQ1gsU0FBSzdFLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxTQUFLMEYsWUFBTCxHQUFvQixLQUFwQjtBQUNBOUYsYUFBUyxjQUFUO0FBQ0EsU0FBSzJFLE1BQUwsQ0FBWXVFLE1BQVo7QUFDRDs7QUFwaUJ1QixDOzs7Ozs7Ozs7OztBQ0wxQjdKLE9BQU9HLE1BQVAsQ0FBYztBQUFDa0UsU0FBSSxNQUFJQSxHQUFUO0FBQWEzRCxlQUFVLE1BQUlBLFNBQTNCO0FBQXFDQyxjQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxjQUFTLE1BQUlBLFFBQXhFO0FBQWlGQyxlQUFVLE1BQUlBO0FBQS9GLENBQWQ7QUFBQSxNQUFNaUosZUFBZ0IvRyxRQUFRQyxHQUFSLENBQVkrRyxnQkFBWixLQUFpQyxNQUF2RDs7QUFHQSxTQUFTMUYsR0FBVCxDQUFjSSxLQUFkLEVBQXFCdUYsT0FBckIsRUFBOEJDLElBQTlCLEVBQW9DO0FBQ2hDLFFBQUlILFlBQUosRUFBa0I7QUFDZEksZ0JBQVE3RixHQUFSLENBQWEsSUFBR0ksS0FBTSxLQUFJdUYsT0FBUSxJQUFJQyxPQUFPL0csS0FBS2lILFNBQUwsQ0FBZUYsSUFBZixFQUFxQixJQUFyQixFQUEyQixDQUEzQixDQUFQLEdBQXVDLEVBQUksRUFBakY7QUFDSDtBQUNKOztBQUVELFNBQVN2SixTQUFULENBQW9CLEdBQUdtQyxJQUF2QixFQUE2QjtBQUFFd0IsUUFBSSxPQUFKLEVBQWEsR0FBR3hCLElBQWhCO0FBQXdCOztBQUN2RCxTQUFTbEMsUUFBVCxDQUFtQixHQUFHa0MsSUFBdEIsRUFBNEI7QUFBRXdCLFFBQUksTUFBSixFQUFZLEdBQUd4QixJQUFmO0FBQXVCOztBQUNyRCxTQUFTakMsUUFBVCxDQUFtQixHQUFHaUMsSUFBdEIsRUFBNEI7QUFBRXdCLFFBQUksTUFBSixFQUFZLEdBQUd4QixJQUFmO0FBQXVCOztBQUNyRCxTQUFTaEMsU0FBVCxDQUFvQixHQUFHZ0MsSUFBdkIsRUFBNkI7QUFBRXdCLFFBQUksT0FBSixFQUFhLEdBQUd4QixJQUFoQjtBQUF3QixDOzs7Ozs7Ozs7OztBQ1p2RCxJQUFJdUgsSUFBSixFQUFTQyxlQUFULEVBQXlCQyxZQUF6QixFQUFzQ0MsbUJBQXRDLEVBQTBEQyxZQUExRCxFQUF1RUMsV0FBdkU7QUFBbUZ6SyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNrSyxPQUFLN0osQ0FBTCxFQUFPO0FBQUM2SixXQUFLN0osQ0FBTDtBQUFPLEdBQWhCOztBQUFpQjhKLGtCQUFnQjlKLENBQWhCLEVBQWtCO0FBQUM4SixzQkFBZ0I5SixDQUFoQjtBQUFrQixHQUF0RDs7QUFBdUQrSixlQUFhL0osQ0FBYixFQUFlO0FBQUMrSixtQkFBYS9KLENBQWI7QUFBZSxHQUF0Rjs7QUFBdUZnSyxzQkFBb0JoSyxDQUFwQixFQUFzQjtBQUFDZ0ssMEJBQW9CaEssQ0FBcEI7QUFBc0IsR0FBcEk7O0FBQXFJaUssZUFBYWpLLENBQWIsRUFBZTtBQUFDaUssbUJBQWFqSyxDQUFiO0FBQWUsR0FBcEs7O0FBQXFLa0ssY0FBWWxLLENBQVosRUFBYztBQUFDa0ssa0JBQVlsSyxDQUFaO0FBQWM7O0FBQWxNLENBQS9CLEVBQW1PLENBQW5PO0FBQXNPLElBQUlGLElBQUo7QUFBU0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDRSxVQUFRRyxDQUFSLEVBQVU7QUFBQ0YsV0FBS0UsQ0FBTDtBQUFPOztBQUFuQixDQUEvQixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJRyxTQUFKLEVBQWNDLFFBQWQsRUFBdUJDLFFBQXZCLEVBQWdDQyxTQUFoQztBQUEwQ2IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDUSxZQUFVSCxDQUFWLEVBQVk7QUFBQ0csZ0JBQVVILENBQVY7QUFBWSxHQUExQjs7QUFBMkJJLFdBQVNKLENBQVQsRUFBVztBQUFDSSxlQUFTSixDQUFUO0FBQVcsR0FBbEQ7O0FBQW1ESyxXQUFTTCxDQUFULEVBQVc7QUFBQ0ssZUFBU0wsQ0FBVDtBQUFXLEdBQTFFOztBQUEyRU0sWUFBVU4sQ0FBVixFQUFZO0FBQUNNLGdCQUFVTixDQUFWO0FBQVk7O0FBQXBHLENBQWpDLEVBQXVJLENBQXZJOztBQUluYSxTQUFTbUssNEJBQVQsQ0FBc0NqRixJQUF0QyxFQUE0Q1MsUUFBNUMsRUFBc0QwRCxRQUF0RCxFQUFnRTtBQUM5RCxNQUFJLE9BQU8xRCxRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQ2hDLFFBQUlBLFNBQVN5RSxPQUFULENBQWlCLEdBQWpCLE1BQTBCLENBQUMsQ0FBL0IsRUFBa0M7QUFDaEN6RSxpQkFBVztBQUFDQTtBQUFELE9BQVg7QUFDRCxLQUZELE1BRU87QUFDTEEsaUJBQVc7QUFBQzBFLGVBQU8xRTtBQUFSLE9BQVg7QUFDRDtBQUNGOztBQUVEdkYsV0FBUyxzQ0FBVCxFQUFpRHVGLFFBQWpEO0FBRUEsUUFBTTJFLGVBQWU7QUFDbkJDLFVBQU01RSxRQURhO0FBRW5CMEQsY0FBVTtBQUNSbUIsY0FBUUMsT0FBT3BCLFFBQVAsQ0FEQTtBQUVScUIsaUJBQVc7QUFGSDtBQUZTLEdBQXJCO0FBT0F2SyxZQUFVLG9CQUFWLEVBQWdDbUssWUFBaEM7QUFFQSxTQUFPSyxTQUFTQyxpQkFBVCxDQUEyQjFGLElBQTNCLEVBQWlDb0YsWUFBakMsQ0FBUDtBQUNEOztBQUVESyxTQUFTRSxvQkFBVCxDQUE4QixNQUE5QixFQUFzQyxVQUFTUCxZQUFULEVBQXVCO0FBQzNELE1BQUksQ0FBQ0EsYUFBYVEsSUFBZCxJQUFzQixDQUFDUixhQUFhUyxXQUF4QyxFQUFxRDtBQUNuRCxXQUFPckksU0FBUDtBQUNEOztBQUVEdEMsV0FBUyxpQkFBVCxFQUE0QmtLLGFBQWEzRSxRQUF6Qzs7QUFFQSxNQUFJN0YsS0FBS2EsWUFBTCxDQUFrQixhQUFsQixNQUFxQyxJQUF6QyxFQUErQztBQUM3QyxXQUFPd0osNkJBQTZCLElBQTdCLEVBQW1DRyxhQUFhM0UsUUFBaEQsRUFBMEQyRSxhQUFhVSxRQUF2RSxDQUFQO0FBQ0Q7O0FBRUQsUUFBTUMsT0FBTyxJQUFiO0FBQ0EsUUFBTUgsT0FBTyxJQUFJaEwsSUFBSixFQUFiO0FBQ0EsTUFBSTRILFFBQUo7O0FBRUEsTUFBSTtBQUNGb0QsU0FBSy9ILFdBQUw7QUFDQSxVQUFNbUksUUFBUUosS0FBSzNFLGVBQUwsQ0FBcUJtRSxhQUFhM0UsUUFBbEMsQ0FBZDs7QUFFQSxRQUFJdUYsTUFBTWxGLE1BQU4sS0FBaUIsQ0FBckIsRUFBd0I7QUFDdEI1RixlQUFTLGlCQUFULEVBQTRCOEssTUFBTWxGLE1BQWxDLEVBQTBDLGVBQTFDLEVBQTJEc0UsYUFBYTNFLFFBQXhFO0FBQ0EsWUFBTSxJQUFJRixLQUFKLENBQVUsZ0JBQVYsQ0FBTjtBQUNEOztBQUVELFFBQUlxRixLQUFLM0IsUUFBTCxDQUFjK0IsTUFBTSxDQUFOLEVBQVM5QixFQUF2QixFQUEyQmtCLGFBQWFVLFFBQXhDLE1BQXNELElBQTFELEVBQWdFO0FBQzlELFVBQUlGLEtBQUsvQyxhQUFMLENBQW1CdUMsYUFBYTNFLFFBQWhDLEVBQTBDdUYsTUFBTSxDQUFOLENBQTFDLENBQUosRUFBeUQ7QUFDdkR4RCxtQkFBV3dELE1BQU0sQ0FBTixDQUFYO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTSxJQUFJekYsS0FBSixDQUFVLDJCQUFWLENBQU47QUFDRDtBQUNGLEtBTkQsTUFNTztBQUNMckYsZUFBUyxvQkFBVCxFQUErQmtLLGFBQWEzRSxRQUE1QztBQUNEO0FBQ0YsR0FsQkQsQ0FrQkUsT0FBT1AsS0FBUCxFQUFjO0FBQ2Q5RSxjQUFVOEUsS0FBVjtBQUNEOztBQUVELE1BQUlzQyxhQUFhaEYsU0FBakIsRUFBNEI7QUFDMUIsUUFBSTVDLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLElBQWpELEVBQXVEO0FBQ3JELGFBQU93Siw2QkFBNkJjLElBQTdCLEVBQW1DWCxhQUFhM0UsUUFBaEQsRUFBMEQyRSxhQUFhVSxRQUF2RSxDQUFQO0FBQ0Q7O0FBRUQsVUFBTSxJQUFJL0gsT0FBT3dDLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXNDLHNEQUFzRDZFLGFBQWEzRSxRQUFVLEdBQW5ILENBQU47QUFDRCxHQTNDMEQsQ0E2QzNEOzs7QUFFQSxNQUFJd0YsU0FBSjtBQUVBLFFBQU1wRSwwQkFBMEJpRCxvQkFBb0J0QyxRQUFwQixDQUFoQztBQUNBLE1BQUk2QyxJQUFKLENBbEQyRCxDQW9EM0Q7O0FBRUEsTUFBSXhELHVCQUFKLEVBQTZCO0FBQzNCb0UsZ0JBQVk7QUFDViwwQkFBb0JwRSx3QkFBd0J4RTtBQURsQyxLQUFaO0FBSUFuQyxhQUFTLGVBQVQ7QUFDQUQsY0FBVSxXQUFWLEVBQXVCZ0wsU0FBdkI7QUFFQVosV0FBT3RILE9BQU9pSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUJELFNBQXJCLENBQVA7QUFDRCxHQS9EMEQsQ0FpRTNEOzs7QUFFQSxNQUFJeEYsUUFBSjtBQUNBLE1BQUkwRSxLQUFKOztBQUVBLE1BQUl2SyxLQUFLYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUNuRGdGLGVBQVdrRSxLQUFLQyxnQkFBZ0JwQyxRQUFoQixDQUFMLENBQVg7QUFDRCxHQUZELE1BRU87QUFDTC9CLGVBQVdrRSxLQUFLUyxhQUFhM0UsUUFBbEIsQ0FBWDtBQUNEOztBQUVELE1BQUc3RixLQUFLYSxZQUFMLENBQWtCLGtCQUFsQixNQUEwQyxFQUE3QyxFQUFpRDtBQUMvQzBKLFlBQVFOLGFBQWFyQyxRQUFiLENBQVI7QUFDRDs7QUFFRCxNQUFJLENBQUM2QyxJQUFMLEVBQVc7QUFDVCxRQUFHRixTQUFTdkssS0FBS2EsWUFBTCxDQUFrQiwwQkFBbEIsTUFBa0QsSUFBOUQsRUFBb0U7QUFDbEUsVUFBR2IsS0FBS2EsWUFBTCxDQUFrQiwyQkFBbEIsTUFBbUQsSUFBdEQsRUFBNEQ7QUFDMUR3SyxvQkFBWTtBQUNWLGlCQUFReEYsUUFERTtBQUVWLDhCQUFxQjBFLEtBRlg7QUFHViwrQkFBc0I7QUFIWixTQUFaO0FBS0QsT0FORCxNQU1PO0FBQ0xjLG9CQUFZO0FBQ1YsaUJBQVF4RixRQURFO0FBRVYsOEJBQXFCMEU7QUFGWCxTQUFaO0FBSUQ7QUFDRixLQWJELE1BYU87QUFDTGMsa0JBQVk7QUFDVnhGO0FBRFUsT0FBWjtBQUdEOztBQUVEeEYsY0FBVSxXQUFWLEVBQXVCZ0wsU0FBdkI7QUFFQVosV0FBT3RILE9BQU9pSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUJELFNBQXJCLENBQVA7QUFDRCxHQXZHMEQsQ0F5RzNEOzs7QUFFQSxNQUFJLENBQUNaLElBQUQsSUFBU0YsS0FBVCxJQUFrQnZLLEtBQUthLFlBQUwsQ0FBa0IseUJBQWxCLE1BQWlELElBQXZFLEVBQTZFO0FBRTNFUCxhQUFTLDhCQUFULEVBQXlDdUYsUUFBekMsRUFBbUQsZ0RBQW5EOztBQUVBLFFBQUc3RixLQUFLYSxZQUFMLENBQWtCLDJCQUFsQixNQUFtRCxJQUF0RCxFQUE0RDtBQUMxRHdLLGtCQUFZO0FBQ1YsNEJBQW9CZCxLQURWO0FBRVYsNkJBQXNCO0FBRlosT0FBWjtBQUlELEtBTEQsTUFLTztBQUNMYyxrQkFBWTtBQUNWLDRCQUFxQmQ7QUFEWCxPQUFaO0FBR0Q7O0FBRURsSyxjQUFVLFdBQVYsRUFBdUJnTCxTQUF2QjtBQUVBWixXQUFPdEgsT0FBT2lJLEtBQVAsQ0FBYUUsT0FBYixDQUFxQkQsU0FBckIsQ0FBUDtBQUVELEdBOUgwRCxDQWdJM0Q7OztBQUNBLE1BQUlaLElBQUosRUFBVTtBQUNSLFFBQUlBLEtBQUtjLG9CQUFMLEtBQThCLE1BQTlCLElBQXdDdkwsS0FBS2EsWUFBTCxDQUFrQiwyQkFBbEIsTUFBbUQsSUFBL0YsRUFBcUc7QUFDbkdQLGVBQVMsbURBQVQ7QUFDQSxZQUFNLElBQUk2QyxPQUFPd0MsS0FBWCxDQUFpQixrQkFBakIsRUFBc0MsdUZBQXRDLENBQU47QUFDRDs7QUFFRHJGLGFBQVMsY0FBVDs7QUFFQSxVQUFNa0wsZUFBZVgsU0FBU1ksMEJBQVQsRUFBckI7O0FBQ0EsVUFBTUMsY0FBYztBQUNsQkMsYUFBTztBQUNMLHVDQUErQmQsU0FBU2UsaUJBQVQsQ0FBMkJKLFlBQTNCO0FBRDFCO0FBRFcsS0FBcEI7O0FBTUEsUUFBSXhMLEtBQUthLFlBQUwsQ0FBa0IsdUJBQWxCLE1BQStDLElBQW5ELEVBQTBEO0FBQ3hEUixnQkFBVSx1QkFBVjtBQUNBLFlBQU0ySCxTQUFTZ0QsS0FBS3JELGFBQUwsQ0FBbUI5QixRQUFuQixFQUE2QitCLFFBQTdCLENBQWY7O0FBRUEsVUFBSUksT0FBTzlCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBd0I7QUFDdEIyRixjQUFNQyxZQUFOLENBQW1CckIsS0FBS3NCLEdBQXhCLEVBQTZCL0QsTUFBN0I7QUFDQTFILGlCQUFVLG9CQUFxQjBILE9BQU9qRCxJQUFQLENBQVksR0FBWixDQUFpQixFQUFoRDtBQUNEO0FBQ0Y7O0FBRUQ1QixXQUFPaUksS0FBUCxDQUFhWSxNQUFiLENBQW9CdkIsS0FBS3NCLEdBQXpCLEVBQThCTCxXQUE5QjtBQUVBdkIsaUJBQWFNLElBQWIsRUFBbUI3QyxRQUFuQjs7QUFFQSxRQUFJNUgsS0FBS2EsWUFBTCxDQUFrQixxQkFBbEIsTUFBNkMsSUFBakQsRUFBdUQ7QUFDckRnSyxlQUFTb0IsV0FBVCxDQUFxQnhCLEtBQUtzQixHQUExQixFQUErQnZCLGFBQWFVLFFBQTVDLEVBQXNEO0FBQUNnQixnQkFBUTtBQUFULE9BQXREO0FBQ0Q7O0FBRUQsV0FBTztBQUNMQyxjQUFRMUIsS0FBS3NCLEdBRFI7QUFFTEssYUFBT1osYUFBYVk7QUFGZixLQUFQO0FBSUQsR0F0SzBELENBd0szRDs7O0FBRUE5TCxXQUFTLCtCQUFULEVBQTBDdUYsUUFBMUM7O0FBRUEsTUFBSTdGLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLEVBQWpELEVBQXFEO0FBQ25EZ0YsZUFBV2pELFNBQVg7QUFDRDs7QUFFRCxNQUFJNUMsS0FBS2EsWUFBTCxDQUFrQixxQkFBbEIsTUFBNkMsSUFBakQsRUFBdUQ7QUFDckQySixpQkFBYVUsUUFBYixHQUF3QnRJLFNBQXhCO0FBQ0Q7O0FBRUQsUUFBTTJFLFNBQVM2QyxZQUFZeEMsUUFBWixFQUFzQi9CLFFBQXRCLEVBQWdDMkUsYUFBYVUsUUFBN0MsQ0FBZjs7QUFFQSxNQUFJbEwsS0FBS2EsWUFBTCxDQUFrQix1QkFBbEIsTUFBK0MsSUFBbkQsRUFBMEQ7QUFDeEQsVUFBTW1ILFNBQVNnRCxLQUFLckQsYUFBTCxDQUFtQjlCLFFBQW5CLEVBQTZCK0IsUUFBN0IsQ0FBZjs7QUFDQSxRQUFJSSxPQUFPOUIsTUFBUCxHQUFnQixDQUFwQixFQUF3QjtBQUN0QjJGLFlBQU1DLFlBQU4sQ0FBbUJ2RSxPQUFPNEUsTUFBMUIsRUFBa0NuRSxNQUFsQztBQUNBMUgsZUFBVSxnQkFBaUIwSCxPQUFPakQsSUFBUCxDQUFZLEdBQVosQ0FBaUIsRUFBNUM7QUFDRDtBQUNGOztBQUdELE1BQUl3QyxrQkFBa0I1QixLQUF0QixFQUE2QjtBQUMzQixVQUFNNEIsTUFBTjtBQUNEOztBQUVELFNBQU9BLE1BQVA7QUFDRCxDQXBNRCxFOzs7Ozs7Ozs7OztBQzNCQTVILE9BQU9HLE1BQVAsQ0FBYztBQUFDaUssUUFBSyxNQUFJQSxJQUFWO0FBQWVzQyxvQkFBaUIsTUFBSUEsZ0JBQXBDO0FBQXFEckMsbUJBQWdCLE1BQUlBLGVBQXpFO0FBQXlGQyxnQkFBYSxNQUFJQSxZQUExRztBQUF1SHFDLG1CQUFnQixNQUFJQSxlQUEzSTtBQUEySnBDLHVCQUFvQixNQUFJQSxtQkFBbkw7QUFBdU1xQyx5QkFBc0IsTUFBSUEscUJBQWpPO0FBQXVQcEMsZ0JBQWEsTUFBSUEsWUFBeFE7QUFBcVJDLGVBQVksTUFBSUEsV0FBclM7QUFBaVRvQyxrQkFBZSxNQUFJQTtBQUFwVSxDQUFkOztBQUFtVyxJQUFJQyxDQUFKOztBQUFNOU0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDRSxVQUFRRyxDQUFSLEVBQVU7QUFBQ3VNLFFBQUV2TSxDQUFGO0FBQUk7O0FBQWhCLENBQW5DLEVBQXFELENBQXJEO0FBQXdELElBQUlGLElBQUo7QUFBU0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDRSxVQUFRRyxDQUFSLEVBQVU7QUFBQ0YsV0FBS0UsQ0FBTDtBQUFPOztBQUFuQixDQUEvQixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJRyxTQUFKLEVBQWNDLFFBQWQsRUFBdUJDLFFBQXZCLEVBQWdDQyxTQUFoQztBQUEwQ2IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDUSxZQUFVSCxDQUFWLEVBQVk7QUFBQ0csZ0JBQVVILENBQVY7QUFBWSxHQUExQjs7QUFBMkJJLFdBQVNKLENBQVQsRUFBVztBQUFDSSxlQUFTSixDQUFUO0FBQVcsR0FBbEQ7O0FBQW1ESyxXQUFTTCxDQUFULEVBQVc7QUFBQ0ssZUFBU0wsQ0FBVDtBQUFXLEdBQTFFOztBQUEyRU0sWUFBVU4sQ0FBVixFQUFZO0FBQUNNLGdCQUFVTixDQUFWO0FBQVk7O0FBQXBHLENBQWpDLEVBQXVJLENBQXZJO0FBSTNnQnNJLE9BQU9rRSxjQUFQLENBQXNCbEUsT0FBT21FLFNBQTdCLEVBQXdDLGNBQXhDLEVBQXdEO0FBQ3REbEssU0FBTyxVQUFVbUssSUFBVixFQUFnQjtBQUNuQixVQUFNekIsT0FBTyxJQUFiOztBQUNBLFNBQUssSUFBSXpDLEdBQVQsSUFBZ0J5QyxJQUFoQixFQUFzQjtBQUNsQixVQUFJekMsSUFBSW1FLFdBQUosTUFBcUJELEtBQUtDLFdBQUwsRUFBekIsRUFBNkM7QUFDekMsZUFBTzFCLEtBQUt6QyxHQUFMLENBQVA7QUFDSDtBQUNKO0FBQ0osR0FScUQ7QUFVdERvRSxjQUFZO0FBVjBDLENBQXhEOztBQWFPLFNBQVMvQyxJQUFULENBQWNnRCxJQUFkLEVBQW9CO0FBQ3pCLE1BQUkvTSxLQUFLYSxZQUFMLENBQWtCLHlCQUFsQixNQUFpRCxJQUFyRCxFQUEyRDtBQUN6RCxXQUFPa00sSUFBUDtBQUNEOztBQUNEQSxTQUFPQyxRQUFRRCxJQUFSLEVBQWMsR0FBZCxDQUFQO0FBQ0EsU0FBT0EsS0FBS2pGLE9BQUwsQ0FBYSxlQUFiLEVBQThCLEVBQTlCLENBQVA7QUFDRDs7QUFFRCxTQUFTbUYsa0JBQVQsQ0FBNkJDLFFBQTdCLEVBQXVDQyxNQUF2QyxFQUErQztBQUU3QyxRQUFNQyxnQkFBZ0IsZ0JBQXRCO0FBQ0EsTUFBSXRJLFFBQVFzSSxjQUFjQyxJQUFkLENBQW1CSCxRQUFuQixDQUFaO0FBQ0EsTUFBSUksY0FBY0osUUFBbEI7O0FBRUEsTUFBSXBJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixRQUFJLENBQUNxSSxPQUFPSSxjQUFQLENBQXNCTCxRQUF0QixDQUFMLEVBQXNDO0FBQ3BDO0FBQ0Q7O0FBQ0QsV0FBT0MsT0FBT0QsUUFBUCxDQUFQO0FBQ0QsR0FMRCxNQUtPO0FBQ0wsV0FBT3BJLFNBQVMsSUFBaEIsRUFBc0I7QUFDcEIsWUFBTTBJLFVBQVUxSSxNQUFNLENBQU4sQ0FBaEI7QUFDQSxZQUFNMkksZUFBZTNJLE1BQU0sQ0FBTixDQUFyQjs7QUFFQSxVQUFJLENBQUNxSSxPQUFPSSxjQUFQLENBQXNCRSxZQUF0QixDQUFMLEVBQTBDO0FBQ3hDO0FBQ0Q7O0FBRUQsWUFBTUMsVUFBVVAsT0FBT00sWUFBUCxDQUFoQjtBQUNBSCxvQkFBY0EsWUFBWXhGLE9BQVosQ0FBb0IwRixPQUFwQixFQUE2QkUsT0FBN0IsQ0FBZDtBQUNBNUksY0FBUXNJLGNBQWNDLElBQWQsQ0FBbUJILFFBQW5CLENBQVI7QUFDRDs7QUFDRCxXQUFPSSxXQUFQO0FBQ0Q7QUFDRjs7QUFFTSxTQUFTakIsZ0JBQVQsQ0FBMEJzQixHQUExQixFQUErQmpGLEdBQS9CLEVBQW9DO0FBQ3pDLE1BQUk7QUFDRixXQUFPK0QsRUFBRW1CLE1BQUYsQ0FBU2xGLElBQUlsRSxLQUFKLENBQVUsR0FBVixDQUFULEVBQXlCLENBQUNxSixHQUFELEVBQU1DLEVBQU4sS0FBYUQsSUFBSUMsRUFBSixDQUF0QyxFQUErQ0gsR0FBL0MsQ0FBUDtBQUNELEdBRkQsQ0FFRSxPQUFPSSxHQUFQLEVBQVk7QUFDWixXQUFPbkwsU0FBUDtBQUNEO0FBQ0Y7O0FBRU0sU0FBU29ILGVBQVQsQ0FBeUJwQyxRQUF6QixFQUFtQztBQUN4QyxRQUFNb0csZ0JBQWdCaE8sS0FBS2EsWUFBTCxDQUFrQixxQkFBbEIsQ0FBdEI7O0FBRUEsTUFBSW1OLGNBQWMxRCxPQUFkLENBQXNCLElBQXRCLElBQThCLENBQUMsQ0FBbkMsRUFBc0M7QUFDcEMsV0FBTzBELGNBQWNsRyxPQUFkLENBQXNCLFdBQXRCLEVBQW1DLFVBQVNoRCxLQUFULEVBQWdCbUosS0FBaEIsRUFBdUI7QUFDL0QsYUFBT3JHLFNBQVNzRyxZQUFULENBQXNCRCxLQUF0QixDQUFQO0FBQ0QsS0FGTSxDQUFQO0FBR0Q7O0FBRUQsU0FBT3JHLFNBQVNzRyxZQUFULENBQXNCRixhQUF0QixDQUFQO0FBQ0Q7O0FBRU0sU0FBUy9ELFlBQVQsQ0FBc0JyQyxRQUF0QixFQUFnQztBQUNyQyxRQUFNdUcsYUFBYW5PLEtBQUthLFlBQUwsQ0FBa0Isa0JBQWxCLENBQW5COztBQUVBLE1BQUlzTixXQUFXN0QsT0FBWCxDQUFtQixJQUFuQixJQUEyQixDQUFDLENBQWhDLEVBQW1DO0FBQ2pDLFdBQU82RCxXQUFXckcsT0FBWCxDQUFtQixXQUFuQixFQUFnQyxVQUFTaEQsS0FBVCxFQUFnQm1KLEtBQWhCLEVBQXVCO0FBQzVELGFBQU9yRyxTQUFTc0csWUFBVCxDQUFzQkQsS0FBdEIsQ0FBUDtBQUNELEtBRk0sQ0FBUDtBQUdEOztBQUVELFNBQU9yRyxTQUFTc0csWUFBVCxDQUFzQkMsVUFBdEIsQ0FBUDtBQUNEOztBQUVNLFNBQVM3QixlQUFULENBQXlCMUUsUUFBekIsRUFBbUM7QUFDeEMsUUFBTXdHLGdCQUFnQnBPLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLENBQXRCOztBQUNBLE1BQUl1TixjQUFjOUQsT0FBZCxDQUFzQixJQUF0QixJQUE4QixDQUFDLENBQW5DLEVBQXNDO0FBQ3BDLFdBQU84RCxjQUFjdEcsT0FBZCxDQUFzQixXQUF0QixFQUFtQyxVQUFTaEQsS0FBVCxFQUFnQm1KLEtBQWhCLEVBQXVCO0FBQy9ELGFBQU9yRyxTQUFTc0csWUFBVCxDQUFzQkQsS0FBdEIsQ0FBUDtBQUNELEtBRk0sQ0FBUDtBQUdEOztBQUNELFNBQU9yRyxTQUFTc0csWUFBVCxDQUFzQkUsYUFBdEIsQ0FBUDtBQUNEOztBQUVNLFNBQVNsRSxtQkFBVCxDQUE2QnRDLFFBQTdCLEVBQXVDO0FBQzVDLE1BQUlYLDBCQUEwQmpILEtBQUthLFlBQUwsQ0FBa0IsOEJBQWxCLENBQTlCOztBQUVBLE1BQUlvRyw0QkFBNEIsRUFBaEMsRUFBb0M7QUFDbENBLDhCQUEwQkEsd0JBQXdCYSxPQUF4QixDQUFnQyxLQUFoQyxFQUF1QyxFQUF2QyxFQUEyQ3RELEtBQTNDLENBQWlELEdBQWpELENBQTFCO0FBQ0QsR0FGRCxNQUVPO0FBQ0x5Qyw4QkFBMEIsRUFBMUI7QUFDRDs7QUFFRCxNQUFJbkYsb0JBQW9COUIsS0FBS2EsWUFBTCxDQUFrQix3QkFBbEIsQ0FBeEI7O0FBRUEsTUFBSWlCLHNCQUFzQixFQUExQixFQUE4QjtBQUM1QkEsd0JBQW9CQSxrQkFBa0JnRyxPQUFsQixDQUEwQixLQUExQixFQUFpQyxFQUFqQyxFQUFxQ3RELEtBQXJDLENBQTJDLEdBQTNDLENBQXBCO0FBQ0QsR0FGRCxNQUVPO0FBQ0wxQyx3QkFBb0IsRUFBcEI7QUFDRDs7QUFFRG1GLDRCQUEwQkEsd0JBQXdCb0gsTUFBeEIsQ0FBK0J2TSxpQkFBL0IsQ0FBMUI7O0FBRUEsTUFBSW1GLHdCQUF3QmYsTUFBeEIsR0FBaUMsQ0FBckMsRUFBd0M7QUFDdENlLDhCQUEwQkEsd0JBQXdCcUgsSUFBeEIsQ0FBOEJMLEtBQUQsSUFBVztBQUNoRSxhQUFPLENBQUN4QixFQUFFOEIsT0FBRixDQUFVM0csU0FBU1UsSUFBVCxDQUFjNEYsWUFBZCxDQUEyQkQsS0FBM0IsQ0FBVixDQUFSO0FBQ0QsS0FGeUIsQ0FBMUI7O0FBR0EsUUFBSWhILHVCQUFKLEVBQTZCO0FBQzNCNUcsZ0JBQVcsMEJBQTJCNEcsdUJBQXdCLEVBQTlEO0FBQ0FBLGdDQUEwQjtBQUN4QkQsbUJBQVdDLHVCQURhO0FBRXhCeEUsZUFBT21GLFNBQVNVLElBQVQsQ0FBYzRGLFlBQWQsQ0FBMkJqSCx1QkFBM0IsRUFBb0RLLFFBQXBELENBQTZELEtBQTdEO0FBRmlCLE9BQTFCO0FBSUQ7O0FBQ0QsV0FBT0wsdUJBQVA7QUFDRDtBQUNGOztBQUVNLFNBQVNzRixxQkFBVCxDQUErQjNFLFFBQS9CLEVBQXlDNkMsSUFBekMsRUFBK0M7QUFDcEQsUUFBTU4sZUFBZW5LLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLENBQXJCO0FBQ0EsUUFBTTJOLHVCQUF1QnhPLEtBQUthLFlBQUwsQ0FBa0IsOEJBQWxCLEVBQWtENE4sSUFBbEQsRUFBN0I7QUFFQSxRQUFNQyxXQUFXLEVBQWpCOztBQUVBLE1BQUl2RSxnQkFBZ0JxRSxvQkFBcEIsRUFBMEM7QUFDeEMsVUFBTUcsd0JBQXdCLENBQUMsT0FBRCxFQUFVLE1BQVYsRUFBa0IsY0FBbEIsQ0FBOUI7QUFDQSxVQUFNQyxXQUFXL0wsS0FBS0MsS0FBTCxDQUFXMEwsb0JBQVgsQ0FBakI7QUFDQSxVQUFNSyxZQUFZLEVBQWxCOztBQUNBcEMsTUFBRXpHLEdBQUYsQ0FBTTRJLFFBQU4sRUFBZ0IsVUFBU0UsU0FBVCxFQUFvQkMsU0FBcEIsRUFBK0I7QUFDN0MxTyxnQkFBVyxpQkFBZ0IwTyxTQUFVLE9BQU1ELFNBQVUsRUFBckQ7O0FBQ0EsY0FBUUEsU0FBUjtBQUNBLGFBQUssT0FBTDtBQUNFLGNBQUksQ0FBQ2xILFNBQVMyRixjQUFULENBQXdCd0IsU0FBeEIsQ0FBTCxFQUF5QztBQUN2QzFPLHNCQUFXLGlDQUFpQzBPLFNBQVcsRUFBdkQ7QUFDQTtBQUNEOztBQUVELGNBQUl0QyxFQUFFdUMsUUFBRixDQUFXcEgsU0FBU21ILFNBQVQsQ0FBWCxDQUFKLEVBQXFDO0FBQ25DdEMsY0FBRXpHLEdBQUYsQ0FBTTRCLFNBQVNtSCxTQUFULENBQU4sRUFBMkIsVUFBUzlJLElBQVQsRUFBZTtBQUN4QzRJLHdCQUFVaEssSUFBVixDQUFlO0FBQUVvSyx5QkFBU2hKLElBQVg7QUFBaUJpSiwwQkFBVTtBQUEzQixlQUFmO0FBQ0QsYUFGRDtBQUdELFdBSkQsTUFJTztBQUNMTCxzQkFBVWhLLElBQVYsQ0FBZTtBQUFFb0ssdUJBQVNySCxTQUFTbUgsU0FBVCxDQUFYO0FBQWdDRyx3QkFBVTtBQUExQyxhQUFmO0FBQ0Q7O0FBQ0Q7O0FBRUY7QUFDRSxnQkFBTSxDQUFDQyxRQUFELEVBQVdDLFNBQVgsSUFBd0JOLFVBQVV0SyxLQUFWLENBQWdCLFFBQWhCLENBQTlCOztBQUVBLGNBQUksQ0FBQ2lJLEVBQUU2QixJQUFGLENBQU9LLHFCQUFQLEVBQStCYixFQUFELElBQVFBLE9BQU9xQixRQUE3QyxDQUFMLEVBQTZEO0FBQzNEOU8sc0JBQVcsbUNBQW1DeU8sU0FBVyxFQUF6RDtBQUNBO0FBQ0Q7O0FBRUQsY0FBSUssYUFBYSxjQUFqQixFQUFpQztBQUMvQixnQkFBSUUsZ0JBQUo7O0FBRUEsZ0JBQUk7QUFDRkEsaUNBQW1CeE0sS0FBS0MsS0FBTCxDQUFXOUMsS0FBS2EsWUFBTCxDQUFrQix1QkFBbEIsQ0FBWCxDQUFuQjtBQUNELGFBRkQsQ0FFRSxPQUFPeU8sQ0FBUCxFQUFVO0FBQ1ZqUCx3QkFBVSxnQ0FBVjtBQUNBO0FBQ0Q7O0FBRUQsZ0JBQUksQ0FBQ2dNLGlCQUFpQmdELGdCQUFqQixFQUFtQ0QsU0FBbkMsQ0FBTCxFQUFvRDtBQUNsRC9PLHdCQUFXLGtDQUFrQ3lPLFNBQVcsRUFBeEQ7QUFDQTtBQUNEO0FBQ0Y7O0FBRUQsZ0JBQU1TLGVBQWVsRCxpQkFBaUI1QixJQUFqQixFQUF1QnFFLFNBQXZCLENBQXJCO0FBQ0EsZ0JBQU1VLGVBQWV2QyxtQkFBbUI4QixTQUFuQixFQUE4Qm5ILFFBQTlCLENBQXJCOztBQUVBLGNBQUk0SCxnQkFBZ0JELGlCQUFpQkMsWUFBckMsRUFBbUQ7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFNQyxRQUFRWCxVQUFVdEssS0FBVixDQUFnQixHQUFoQixDQUFkOztBQUNBLGtCQUFNa0wsVUFBVWpELEVBQUVrRCxJQUFGLENBQU9GLEtBQVAsQ0FBaEI7O0FBQ0FoRCxjQUFFbUIsTUFBRixDQUFTNkIsS0FBVCxFQUFnQixDQUFDOUIsR0FBRCxFQUFNaUMsT0FBTixLQUNiQSxZQUFZRixPQUFiLEdBQ0kvQixJQUFJaUMsT0FBSixJQUFlSixZQURuQixHQUVJN0IsSUFBSWlDLE9BQUosSUFBZWpDLElBQUlpQyxPQUFKLEtBQWdCLEVBSHJDLEVBSUlsQixRQUpKOztBQUtBck8sc0JBQVcsUUFBUXlPLFNBQVcsZ0JBQWdCVSxZQUFjLEVBQTVEO0FBQ0Q7O0FBekRIO0FBMkRELEtBN0REOztBQStEQSxRQUFJWCxVQUFVM0ksTUFBVixHQUFtQixDQUF2QixFQUEwQjtBQUN4QixVQUFJckQsS0FBS2lILFNBQUwsQ0FBZVcsS0FBS29GLE1BQXBCLE1BQWdDaE4sS0FBS2lILFNBQUwsQ0FBZStFLFNBQWYsQ0FBcEMsRUFBK0Q7QUFDN0RILGlCQUFTbUIsTUFBVCxHQUFrQmhCLFNBQWxCO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFFBQU1pQixXQUFXNUYsb0JBQW9CdEMsUUFBcEIsQ0FBakI7O0FBRUEsTUFBSWtJLGFBQWEsQ0FBQ3JGLEtBQUtzRixRQUFOLElBQWtCLENBQUN0RixLQUFLc0YsUUFBTCxDQUFjL0UsSUFBakMsSUFBeUNQLEtBQUtzRixRQUFMLENBQWMvRSxJQUFkLENBQW1CakUsRUFBbkIsS0FBMEIrSSxTQUFTck4sS0FBNUUsSUFBcUZnSSxLQUFLc0YsUUFBTCxDQUFjL0UsSUFBZCxDQUFtQmdGLFdBQW5CLEtBQW1DRixTQUFTOUksU0FBOUksQ0FBSixFQUE4SjtBQUM1SjBILGFBQVMsa0JBQVQsSUFBK0JvQixTQUFTck4sS0FBeEM7QUFDQWlNLGFBQVMsMkJBQVQsSUFBd0NvQixTQUFTOUksU0FBakQ7QUFDRDs7QUFFRCxNQUFJeUQsS0FBS2Msb0JBQUwsS0FBOEIsTUFBbEMsRUFBMEM7QUFDeENtRCxhQUFTMUQsSUFBVCxHQUFnQixJQUFoQjtBQUNEOztBQUVELE1BQUl5QixFQUFFd0QsSUFBRixDQUFPdkIsUUFBUCxDQUFKLEVBQXNCO0FBQ3BCLFdBQU9BLFFBQVA7QUFDRDtBQUNGOztBQUdNLFNBQVN2RSxZQUFULENBQXNCTSxJQUF0QixFQUE0QjdDLFFBQTVCLEVBQXNDO0FBQzNDdEgsV0FBUyxtQkFBVDtBQUNBRCxZQUFVLE1BQVYsRUFBa0I7QUFBQyxhQUFTb0ssS0FBS0YsS0FBZjtBQUFzQixXQUFPRSxLQUFLc0I7QUFBbEMsR0FBbEIsRUFGMkMsQ0FHM0M7O0FBRUEsTUFBSS9MLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLEVBQWpELEVBQXFEO0FBQ25ELFVBQU1nRixXQUFXa0UsS0FBS0MsZ0JBQWdCcEMsUUFBaEIsQ0FBTCxDQUFqQjs7QUFDQSxRQUFJNkMsUUFBUUEsS0FBS3NCLEdBQWIsSUFBb0JsRyxhQUFhNEUsS0FBSzVFLFFBQTFDLEVBQW9EO0FBQ2xEdkYsZUFBUyx1QkFBVCxFQUFrQ21LLEtBQUs1RSxRQUF2QyxFQUFpRCxJQUFqRCxFQUF1REEsUUFBdkQ7QUFDQTFDLGFBQU9pSSxLQUFQLENBQWFFLE9BQWIsQ0FBcUI7QUFBRVMsYUFBS3RCLEtBQUtzQjtBQUFaLE9BQXJCLEVBQXdDO0FBQUVtRSxjQUFNO0FBQUVySztBQUFGO0FBQVIsT0FBeEM7QUFDRDtBQUNGOztBQUVELE1BQUk3RixLQUFLYSxZQUFMLENBQWtCLHFCQUFsQixNQUE2QyxFQUFqRCxFQUFxRDtBQUNuRCxVQUFNc1AsV0FBVTdELGdCQUFnQjFFLFFBQWhCLENBQWhCO0FBQ0F2SCxjQUFVLFdBQVYsRUFBc0I4UCxRQUF0Qjs7QUFDQSxRQUFJMUYsUUFBUUEsS0FBS3NCLEdBQWIsSUFBb0JvRSxhQUFhLEVBQXJDLEVBQXlDO0FBQ3ZDN1AsZUFBUyx3QkFBVCxFQUFtQzZQLFFBQW5DO0FBQ0FoTixhQUFPaUksS0FBUCxDQUFhWSxNQUFiLENBQW9CO0FBQUVELGFBQU10QixLQUFLc0I7QUFBYixPQUFwQixFQUF3QztBQUFFbUUsY0FBTTtBQUFFLDhCQUFxQkM7QUFBdkI7QUFBUixPQUF4QztBQUNEO0FBQ0Y7QUFFRjs7QUFFTSxTQUFTL0YsV0FBVCxDQUFxQnhDLFFBQXJCLEVBQStCL0IsUUFBL0IsRUFBeUMwRCxRQUF6QyxFQUFtRDtBQUN4RCxRQUFNdUcsV0FBVzVGLG9CQUFvQnRDLFFBQXBCLENBQWpCO0FBRUEsUUFBTXdJLGFBQWEsRUFBbkI7O0FBR0EsTUFBSXZLLFFBQUosRUFBYztBQUNadUssZUFBV3ZLLFFBQVgsR0FBc0JBLFFBQXRCO0FBQ0Q7O0FBRUQsUUFBTTZJLFdBQVduQyxzQkFBc0IzRSxRQUF0QixFQUFnQyxFQUFoQyxDQUFqQjs7QUFFQSxNQUFJOEcsWUFBWUEsU0FBU21CLE1BQXJCLElBQStCbkIsU0FBU21CLE1BQVQsQ0FBZ0IsQ0FBaEIsQ0FBL0IsSUFBcURuQixTQUFTbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBNUUsRUFBcUY7QUFDbkYsUUFBSXpILE1BQU1DLE9BQU4sQ0FBY2lILFNBQVNtQixNQUFULENBQWdCLENBQWhCLEVBQW1CWixPQUFqQyxDQUFKLEVBQStDO0FBQzdDbUIsaUJBQVc3RixLQUFYLEdBQW1CbUUsU0FBU21CLE1BQVQsQ0FBZ0IsQ0FBaEIsRUFBbUJaLE9BQW5CLENBQTJCLENBQTNCLENBQW5CO0FBQ0QsS0FGRCxNQUVPO0FBQ0xtQixpQkFBVzdGLEtBQVgsR0FBbUJtRSxTQUFTbUIsTUFBVCxDQUFnQixDQUFoQixFQUFtQlosT0FBdEM7QUFDRDtBQUNGLEdBTkQsTUFNTyxJQUFJckgsU0FBU3lJLElBQVQsSUFBaUJ6SSxTQUFTeUksSUFBVCxDQUFjL0YsT0FBZCxDQUFzQixHQUF0QixJQUE2QixDQUFDLENBQW5ELEVBQXNEO0FBQzNEOEYsZUFBVzdGLEtBQVgsR0FBbUIzQyxTQUFTeUksSUFBNUI7QUFDRCxHQUZNLE1BRUEsSUFBSXJRLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLEVBQWpELEVBQXFEO0FBQzFEdVAsZUFBVzdGLEtBQVgsR0FBb0IsR0FBRzFFLFlBQVlpSyxTQUFTck4sS0FBTyxJQUFJekMsS0FBS2EsWUFBTCxDQUFrQixxQkFBbEIsQ0FBMEMsRUFBakc7QUFDRCxHQUZNLE1BRUE7QUFDTCxVQUFNeUUsUUFBUSxJQUFJbkMsT0FBT3dDLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXFDLG9JQUFyQyxDQUFkO0FBQ0FuRixjQUFVOEUsS0FBVjtBQUNBLFVBQU1BLEtBQU47QUFDRDs7QUFFRGpGLFlBQVUsZUFBVixFQUEyQitQLFVBQTNCOztBQUVBLE1BQUk3RyxRQUFKLEVBQWM7QUFDWjZHLGVBQVc3RyxRQUFYLEdBQXNCQSxRQUF0QjtBQUNEOztBQUVELE1BQUk7QUFDRjtBQUNBNkcsZUFBV3BGLElBQVgsR0FBa0IsSUFBbEI7QUFDQW9GLGVBQVdyRSxHQUFYLEdBQWlCbEIsU0FBU3lGLFVBQVQsQ0FBb0JGLFVBQXBCLENBQWpCLENBSEUsQ0FLRjs7QUFDQWpOLFdBQU9pSSxLQUFQLENBQWFZLE1BQWIsQ0FBb0I7QUFBRUQsV0FBTXFFLFdBQVdyRTtBQUFuQixLQUFwQixFQUE4QztBQUM1Q21FLFlBQU07QUFDRix5QkFBaUI7QUFBRW5KLGNBQUkrSSxTQUFTck47QUFBZixTQURmO0FBRUYsNkJBQXFCLElBRm5CO0FBR0YsZ0NBQXdCO0FBSHRCO0FBRHNDLEtBQTlDO0FBTUQsR0FaRCxDQVlFLE9BQU82QyxLQUFQLEVBQWM7QUFDZDlFLGNBQVUscUJBQVYsRUFBaUM4RSxLQUFqQztBQUNBLFdBQU9BLEtBQVA7QUFDRDs7QUFFRDZFLGVBQWFpRyxVQUFiLEVBQXlCeEksUUFBekI7QUFFQSxTQUFPO0FBQ0x1RSxZQUFRaUUsV0FBV3JFO0FBRGQsR0FBUDtBQUdEOztBQUVNLFNBQVNTLGNBQVQsQ0FBd0J4QixJQUF4QixFQUE4QjtBQUNuQyxNQUFJaEwsS0FBS2EsWUFBTCxDQUFrQixhQUFsQixNQUFxQyxJQUF6QyxFQUErQztBQUM3Q0wsY0FBVSwwQ0FBVjtBQUNBO0FBQ0Q7O0FBRUQsTUFBSSxDQUFDd0ssSUFBTCxFQUFXO0FBQ1RBLFdBQU8sSUFBSWhMLElBQUosRUFBUDtBQUNBZ0wsU0FBSy9ILFdBQUw7QUFDRDs7QUFFRCxNQUFJc04sUUFBUSxDQUFaO0FBQ0F2RixPQUFLM0UsZUFBTCxDQUFxQixHQUFyQixFQUEwQmxELE9BQU9xTixlQUFQLENBQXVCLENBQUNsTCxLQUFELEVBQVFtTCxTQUFSLEVBQW1CO0FBQUN6SCxRQUFEO0FBQU9EO0FBQVAsTUFBYyxFQUFqQyxLQUF3QztBQUN2RixRQUFJekQsS0FBSixFQUFXO0FBQ1QsWUFBTUEsS0FBTjtBQUNEOztBQUVEbUwsY0FBVTlMLE9BQVYsQ0FBbUJpRCxRQUFELElBQWM7QUFDOUIySTtBQUVBLFlBQU1ULFdBQVc1RixvQkFBb0J0QyxRQUFwQixDQUFqQixDQUg4QixDQUk5Qjs7QUFDQSxZQUFNeUQsWUFBWTtBQUNoQiw0QkFBb0J5RSxTQUFTck47QUFEYixPQUFsQjtBQUlBcEMsZ0JBQVUsV0FBVixFQUF1QmdMLFNBQXZCO0FBRUEsVUFBSXhGLFFBQUo7O0FBQ0EsVUFBSTdGLEtBQUthLFlBQUwsQ0FBa0IscUJBQWxCLE1BQTZDLEVBQWpELEVBQXFEO0FBQ25EZ0YsbUJBQVdrRSxLQUFLQyxnQkFBZ0JwQyxRQUFoQixDQUFMLENBQVg7QUFDRCxPQWQ2QixDQWdCOUI7OztBQUNBLFVBQUk2QyxPQUFPdEgsT0FBT2lJLEtBQVAsQ0FBYUUsT0FBYixDQUFxQkQsU0FBckIsQ0FBWDs7QUFFQSxVQUFJLENBQUNaLElBQUQsSUFBUzVFLFFBQVQsSUFBcUI3RixLQUFLYSxZQUFMLENBQWtCLDJCQUFsQixNQUFtRCxJQUE1RSxFQUFrRjtBQUNoRixjQUFNd0ssWUFBWTtBQUNoQnhGO0FBRGdCLFNBQWxCO0FBSUF4RixrQkFBVSxpQkFBVixFQUE2QmdMLFNBQTdCO0FBRUFaLGVBQU90SCxPQUFPaUksS0FBUCxDQUFhRSxPQUFiLENBQXFCRCxTQUFyQixDQUFQOztBQUNBLFlBQUlaLElBQUosRUFBVTtBQUNSTix1QkFBYU0sSUFBYixFQUFtQjdDLFFBQW5CO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJLENBQUM2QyxJQUFMLEVBQVc7QUFDVEwsb0JBQVl4QyxRQUFaLEVBQXNCL0IsUUFBdEI7QUFDRDs7QUFFRCxVQUFJMEssUUFBUSxHQUFSLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCalEsaUJBQVMsMkNBQVQsRUFBc0RpUSxLQUF0RDtBQUNEO0FBQ0YsS0F2Q0Q7O0FBeUNBLFFBQUl4SCxHQUFKLEVBQVM7QUFDUHpJLGVBQVMsa0NBQVQsRUFBNkNpUSxLQUE3QztBQUNEOztBQUVEdkgsU0FBS3VILEtBQUw7QUFDRCxHQW5EeUIsQ0FBMUI7QUFvREQ7O0FBRUQsU0FBU0csSUFBVCxHQUFnQjtBQUNkLE1BQUkxUSxLQUFLYSxZQUFMLENBQWtCLGFBQWxCLE1BQXFDLElBQXpDLEVBQStDO0FBQzdDO0FBQ0Q7O0FBRUQsUUFBTW1LLE9BQU8sSUFBSWhMLElBQUosRUFBYjs7QUFFQSxNQUFJO0FBQ0ZnTCxTQUFLL0gsV0FBTDtBQUVBLFFBQUltSSxLQUFKOztBQUNBLFFBQUlwTCxLQUFLYSxZQUFMLENBQWtCLGtEQUFsQixNQUEwRSxJQUE5RSxFQUFvRjtBQUNsRnVLLGNBQVFqSSxPQUFPaUksS0FBUCxDQUFha0QsSUFBYixDQUFrQjtBQUFFLHlCQUFpQjtBQUFFcUMsbUJBQVM7QUFBWDtBQUFuQixPQUFsQixDQUFSO0FBQ0Q7O0FBRUQsUUFBSTNRLEtBQUthLFlBQUwsQ0FBa0IsdUNBQWxCLE1BQStELElBQW5FLEVBQXlFO0FBQ3ZFMkwscUJBQWV4QixJQUFmO0FBQ0Q7O0FBRUQsUUFBSWhMLEtBQUthLFlBQUwsQ0FBa0Isa0RBQWxCLE1BQTBFLElBQTlFLEVBQW9GO0FBQ2xGdUssWUFBTXpHLE9BQU4sQ0FBYyxVQUFTOEYsSUFBVCxFQUFlO0FBQzNCLFlBQUk3QyxRQUFKOztBQUVBLFlBQUk2QyxLQUFLc0YsUUFBTCxJQUFpQnRGLEtBQUtzRixRQUFMLENBQWMvRSxJQUEvQixJQUF1Q1AsS0FBS3NGLFFBQUwsQ0FBYy9FLElBQWQsQ0FBbUJqRSxFQUE5RCxFQUFrRTtBQUNoRWEscUJBQVdvRCxLQUFLbEUsZUFBTCxDQUFxQjJELEtBQUtzRixRQUFMLENBQWMvRSxJQUFkLENBQW1CakUsRUFBeEMsRUFBNEMwRCxLQUFLc0YsUUFBTCxDQUFjL0UsSUFBZCxDQUFtQmdGLFdBQS9ELENBQVg7QUFDRCxTQUZELE1BRU87QUFDTHBJLHFCQUFXb0QsS0FBS3RELHFCQUFMLENBQTJCK0MsS0FBSzVFLFFBQWhDLENBQVg7QUFDRDs7QUFFRCxZQUFJK0IsUUFBSixFQUFjO0FBQ1p1Qyx1QkFBYU0sSUFBYixFQUFtQjdDLFFBQW5CO0FBQ0QsU0FGRCxNQUVPO0FBQ0x0SCxtQkFBUyxrQkFBVCxFQUE2Qm1LLEtBQUs1RSxRQUFsQztBQUNEO0FBQ0YsT0FkRDtBQWVEO0FBQ0YsR0E3QkQsQ0E2QkUsT0FBT1AsS0FBUCxFQUFjO0FBQ2Q5RSxjQUFVOEUsS0FBVjtBQUNBLFdBQU9BLEtBQVA7QUFDRDs7QUFDRCxTQUFPLElBQVA7QUFDRDs7QUFFRCxNQUFNc0wsVUFBVSxXQUFoQjs7QUFFQSxNQUFNQyxhQUFhcEUsRUFBRXFFLFFBQUYsQ0FBVzNOLE9BQU9xTixlQUFQLENBQXVCLFNBQVNPLG1CQUFULEdBQStCO0FBQ2xGLE1BQUkvUSxLQUFLYSxZQUFMLENBQWtCLHNCQUFsQixNQUE4QyxJQUFsRCxFQUF3RDtBQUN0RFAsYUFBUyxnQ0FBVDs7QUFDQSxRQUFJMFEsV0FBV0MsbUJBQVgsQ0FBK0JMLE9BQS9CLENBQUosRUFBNkM7QUFDM0NJLGlCQUFXRSxNQUFYLENBQWtCTixPQUFsQjtBQUNEOztBQUNEO0FBQ0Q7O0FBRUQsTUFBSTVRLEtBQUthLFlBQUwsQ0FBa0IsK0JBQWxCLENBQUosRUFBd0Q7QUFDdERQLGFBQVMsK0JBQVQ7QUFDQTBRLGVBQVdHLEdBQVgsQ0FBZTtBQUNiNU8sWUFBTXFPLE9BRE87QUFFYlEsZ0JBQVdDLE1BQUQsSUFBWUEsT0FBT3RFLElBQVAsQ0FBWS9NLEtBQUthLFlBQUwsQ0FBa0IsK0JBQWxCLENBQVosQ0FGVDs7QUFHYnlRLFlBQU07QUFDSlo7QUFDRDs7QUFMWSxLQUFmO0FBT0FNLGVBQVdPLEtBQVg7QUFDRDtBQUNGLENBcEI2QixDQUFYLEVBb0JmLEdBcEJlLENBQW5COztBQXNCQXBPLE9BQU9xTyxPQUFQLENBQWUsTUFBTTtBQUNuQnJPLFNBQU9zTyxLQUFQLENBQWEsTUFBTTtBQUNqQnpSLFNBQUthLFlBQUwsQ0FBa0Isc0JBQWxCLEVBQTBDZ1EsVUFBMUM7QUFDQTdRLFNBQUthLFlBQUwsQ0FBa0IsK0JBQWxCLEVBQW1EZ1EsVUFBbkQ7QUFDRCxHQUhEO0FBSUQsQ0FMRCxFIiwiZmlsZSI6Ii9wYWNrYWdlcy93ZWthbl93ZWthbi1sZGFwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL2xvZ2luSGFuZGxlcic7XG4iLCJpbXBvcnQgbGRhcGpzIGZyb20gJ2xkYXBqcyc7XG5pbXBvcnQgdXRpbCBmcm9tICd1dGlsJztcbmltcG9ydCBCdW55YW4gZnJvbSAnYnVueWFuJztcbmltcG9ydCB7IGxvZ19kZWJ1ZywgbG9nX2luZm8sIGxvZ193YXJuLCBsb2dfZXJyb3IgfSBmcm9tICcuL2xvZ2dlcic7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExEQVAge1xuICBjb25zdHJ1Y3Rvcigpe1xuICAgIHRoaXMubGRhcGpzID0gbGRhcGpzO1xuXG4gICAgdGhpcy5jb25uZWN0ZWQgPSBmYWxzZTtcblxuICAgIHRoaXMub3B0aW9ucyA9IHtcbiAgICAgIGhvc3Q6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0hPU1QnKSxcbiAgICAgIHBvcnQ6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1BPUlQnKSxcbiAgICAgIFJlY29ubmVjdDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfUkVDT05ORUNUJyksXG4gICAgICB0aW1lb3V0OiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9USU1FT1VUJyksXG4gICAgICBjb25uZWN0X3RpbWVvdXQ6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0NPTk5FQ1RfVElNRU9VVCcpLFxuICAgICAgaWRsZV90aW1lb3V0OiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9JRExFX1RJTUVPVVQnKSxcbiAgICAgIGVuY3J5cHRpb246IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0VOQ1JZUFRJT04nKSxcbiAgICAgIGNhX2NlcnQ6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0NBX0NFUlQnKSxcbiAgICAgIHJlamVjdF91bmF1dGhvcml6ZWQ6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1JFSkVDVF9VTkFVVEhPUklaRUQnKSB8fCBmYWxzZSxcbiAgICAgIEF1dGhlbnRpY2F0aW9uOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9BVVRIRU5USUZJQ0FUSU9OJyksXG4gICAgICBBdXRoZW50aWNhdGlvbl9Vc2VyRE46IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0FVVEhFTlRJRklDQVRJT05fVVNFUkROJyksXG4gICAgICBBdXRoZW50aWNhdGlvbl9QYXNzd29yZDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfQVVUSEVOVElGSUNBVElPTl9QQVNTV09SRCcpLFxuICAgICAgQXV0aGVudGljYXRpb25fRmFsbGJhY2s6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0xPR0lOX0ZBTExCQUNLJyksXG4gICAgICBCYXNlRE46IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0JBU0VETicpLFxuICAgICAgSW50ZXJuYWxfTG9nX0xldmVsOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnSU5URVJOQUxfTE9HX0xFVkVMJyksXG4gICAgICBVc2VyX1NlYXJjaF9GaWx0ZXI6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1VTRVJfU0VBUkNIX0ZJTFRFUicpLFxuICAgICAgVXNlcl9TZWFyY2hfU2NvcGU6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1VTRVJfU0VBUkNIX1NDT1BFJyksXG4gICAgICBVc2VyX1NlYXJjaF9GaWVsZDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUl9TRUFSQ0hfRklFTEQnKSxcbiAgICAgIFNlYXJjaF9QYWdlX1NpemU6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX1NFQVJDSF9QQUdFX1NJWkUnKSxcbiAgICAgIFNlYXJjaF9TaXplX0xpbWl0OiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9TRUFSQ0hfU0laRV9MSU1JVCcpLFxuICAgICAgZ3JvdXBfZmlsdGVyX2VuYWJsZWQ6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0dST1VQX0ZJTFRFUl9FTkFCTEUnKSxcbiAgICAgIGdyb3VwX2ZpbHRlcl9vYmplY3RfY2xhc3M6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0dST1VQX0ZJTFRFUl9PQkpFQ1RDTEFTUycpLFxuICAgICAgZ3JvdXBfZmlsdGVyX2dyb3VwX2lkX2F0dHJpYnV0ZTogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfR1JPVVBfRklMVEVSX0dST1VQX0lEX0FUVFJJQlVURScpLFxuICAgICAgZ3JvdXBfZmlsdGVyX2dyb3VwX21lbWJlcl9hdHRyaWJ1dGU6IHRoaXMuY29uc3RydWN0b3Iuc2V0dGluZ3NfZ2V0KCdMREFQX0dST1VQX0ZJTFRFUl9HUk9VUF9NRU1CRVJfQVRUUklCVVRFJyksXG4gICAgICBncm91cF9maWx0ZXJfZ3JvdXBfbWVtYmVyX2Zvcm1hdDogdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfR1JPVVBfRklMVEVSX0dST1VQX01FTUJFUl9GT1JNQVQnKSxcbiAgICAgIGdyb3VwX2ZpbHRlcl9ncm91cF9uYW1lOiB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9HUk9VUF9GSUxURVJfR1JPVVBfTkFNRScpLFxuICAgIH07XG4gIH1cblxuICBzdGF0aWMgc2V0dGluZ3NfZ2V0KG5hbWUsIC4uLmFyZ3MpIHtcbiAgICBsZXQgdmFsdWUgPSBwcm9jZXNzLmVudltuYW1lXTtcbiAgICBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHZhbHVlID09PSAndHJ1ZScgfHwgdmFsdWUgPT09ICdmYWxzZScpIHtcbiAgICAgICAgdmFsdWUgPSBKU09OLnBhcnNlKHZhbHVlKTtcbiAgICAgIH0gZWxzZSBpZiAodmFsdWUgIT09ICcnICYmICFpc05hTih2YWx1ZSkpIHtcbiAgICAgICAgdmFsdWUgPSBOdW1iZXIodmFsdWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dfd2FybihgTG9va3VwIGZvciB1bnNldCB2YXJpYWJsZTogJHtuYW1lfWApO1xuICAgIH1cbiAgfVxuICBjb25uZWN0U3luYyguLi5hcmdzKSB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0U3luYykge1xuICAgICAgdGhpcy5fY29ubmVjdFN5bmMgPSBNZXRlb3Iud3JhcEFzeW5jKHRoaXMuY29ubmVjdEFzeW5jLCB0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm5lY3RTeW5jKC4uLmFyZ3MpO1xuICB9XG5cbiAgc2VhcmNoQWxsU3luYyguLi5hcmdzKSB7XG4gICAgaWYgKCF0aGlzLl9zZWFyY2hBbGxTeW5jKSB7XG4gICAgICB0aGlzLl9zZWFyY2hBbGxTeW5jID0gTWV0ZW9yLndyYXBBc3luYyh0aGlzLnNlYXJjaEFsbEFzeW5jLCB0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3NlYXJjaEFsbFN5bmMoLi4uYXJncyk7XG4gIH1cblxuICBjb25uZWN0QXN5bmMoY2FsbGJhY2spIHtcbiAgICBsb2dfaW5mbygnSW5pdCBzZXR1cCcpO1xuXG4gICAgbGV0IHJlcGxpZWQgPSBmYWxzZTtcblxuICAgIGNvbnN0IGNvbm5lY3Rpb25PcHRpb25zID0ge1xuICAgICAgdXJsOiBgJHsgdGhpcy5vcHRpb25zLmhvc3QgfTokeyB0aGlzLm9wdGlvbnMucG9ydCB9YCxcbiAgICAgIHRpbWVvdXQ6IHRoaXMub3B0aW9ucy50aW1lb3V0LFxuICAgICAgY29ubmVjdFRpbWVvdXQ6IHRoaXMub3B0aW9ucy5jb25uZWN0X3RpbWVvdXQsXG4gICAgICBpZGxlVGltZW91dDogdGhpcy5vcHRpb25zLmlkbGVfdGltZW91dCxcbiAgICAgIHJlY29ubmVjdDogdGhpcy5vcHRpb25zLlJlY29ubmVjdCxcbiAgICB9O1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5JbnRlcm5hbF9Mb2dfTGV2ZWwgIT09ICdkaXNhYmxlZCcpIHtcbiAgICAgIGNvbm5lY3Rpb25PcHRpb25zLmxvZyA9IG5ldyBCdW55YW4oe1xuICAgICAgICBuYW1lOiAnbGRhcGpzJyxcbiAgICAgICAgY29tcG9uZW50OiAnY2xpZW50JyxcbiAgICAgICAgc3RyZWFtOiBwcm9jZXNzLnN0ZGVycixcbiAgICAgICAgbGV2ZWw6IHRoaXMub3B0aW9ucy5JbnRlcm5hbF9Mb2dfTGV2ZWwsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB0bHNPcHRpb25zID0ge1xuICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiB0aGlzLm9wdGlvbnMucmVqZWN0X3VuYXV0aG9yaXplZCxcbiAgICB9O1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jYV9jZXJ0ICYmIHRoaXMub3B0aW9ucy5jYV9jZXJ0ICE9PSAnJykge1xuICAgICAgLy8gU3BsaXQgQ0EgY2VydCBpbnRvIGFycmF5IG9mIHN0cmluZ3NcbiAgICAgIGNvbnN0IGNoYWluTGluZXMgPSB0aGlzLmNvbnN0cnVjdG9yLnNldHRpbmdzX2dldCgnTERBUF9DQV9DRVJUJykuc3BsaXQoJ1xcbicpO1xuICAgICAgbGV0IGNlcnQgPSBbXTtcbiAgICAgIGNvbnN0IGNhID0gW107XG4gICAgICBjaGFpbkxpbmVzLmZvckVhY2goKGxpbmUpID0+IHtcbiAgICAgICAgY2VydC5wdXNoKGxpbmUpO1xuICAgICAgICBpZiAobGluZS5tYXRjaCgvLUVORCBDRVJUSUZJQ0FURS0vKSkge1xuICAgICAgICAgIGNhLnB1c2goY2VydC5qb2luKCdcXG4nKSk7XG4gICAgICAgICAgY2VydCA9IFtdO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHRsc09wdGlvbnMuY2EgPSBjYTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmVuY3J5cHRpb24gPT09ICdzc2wnKSB7XG4gICAgICBjb25uZWN0aW9uT3B0aW9ucy51cmwgPSBgbGRhcHM6Ly8keyBjb25uZWN0aW9uT3B0aW9ucy51cmwgfWA7XG4gICAgICBjb25uZWN0aW9uT3B0aW9ucy50bHNPcHRpb25zID0gdGxzT3B0aW9ucztcbiAgICB9IGVsc2Uge1xuICAgICAgY29ubmVjdGlvbk9wdGlvbnMudXJsID0gYGxkYXA6Ly8keyBjb25uZWN0aW9uT3B0aW9ucy51cmwgfWA7XG4gICAgfVxuXG4gICAgbG9nX2luZm8oJ0Nvbm5lY3RpbmcnLCBjb25uZWN0aW9uT3B0aW9ucy51cmwpO1xuICAgIGxvZ19kZWJ1ZyhgY29ubmVjdGlvbk9wdGlvbnMkeyAgdXRpbC5pbnNwZWN0KGNvbm5lY3Rpb25PcHRpb25zKX1gKTtcblxuICAgIHRoaXMuY2xpZW50ID0gbGRhcGpzLmNyZWF0ZUNsaWVudChjb25uZWN0aW9uT3B0aW9ucyk7XG5cbiAgICB0aGlzLmJpbmRTeW5jID0gTWV0ZW9yLndyYXBBc3luYyh0aGlzLmNsaWVudC5iaW5kLCB0aGlzLmNsaWVudCk7XG5cbiAgICB0aGlzLmNsaWVudC5vbignZXJyb3InLCAoZXJyb3IpID0+IHtcbiAgICAgIGxvZ19lcnJvcignY29ubmVjdGlvbicsIGVycm9yKTtcbiAgICAgIGlmIChyZXBsaWVkID09PSBmYWxzZSkge1xuICAgICAgICByZXBsaWVkID0gdHJ1ZTtcbiAgICAgICAgY2FsbGJhY2soZXJyb3IsIG51bGwpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5jbGllbnQub24oJ2lkbGUnLCAoKSA9PiB7XG4gICAgICBsb2dfaW5mbygnSWRsZScpO1xuICAgICAgdGhpcy5kaXNjb25uZWN0KCk7XG4gICAgfSk7XG5cbiAgICB0aGlzLmNsaWVudC5vbignY2xvc2UnLCAoKSA9PiB7XG4gICAgICBsb2dfaW5mbygnQ2xvc2VkJyk7XG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmVuY3J5cHRpb24gPT09ICd0bHMnKSB7XG4gICAgICAvLyBTZXQgaG9zdCBwYXJhbWV0ZXIgZm9yIHRscy5jb25uZWN0IHdoaWNoIGlzIHVzZWQgYnkgbGRhcGpzIHN0YXJ0dGxzLiBUaGlzIHNob3VsZG4ndCBiZSBuZWVkZWQgaW4gbmV3ZXIgbm9kZWpzIHZlcnNpb25zIChlLmcgdjUuNi4wKS5cbiAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Sb2NrZXRDaGF0L1JvY2tldC5DaGF0L2lzc3Vlcy8yMDM1XG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vbWNhdmFnZS9ub2RlLWxkYXBqcy9pc3N1ZXMvMzQ5XG4gICAgICB0bHNPcHRpb25zLmhvc3QgPSB0aGlzLm9wdGlvbnMuaG9zdDtcblxuICAgICAgbG9nX2luZm8oJ1N0YXJ0aW5nIFRMUycpO1xuICAgICAgbG9nX2RlYnVnKCd0bHNPcHRpb25zJywgdGxzT3B0aW9ucyk7XG5cbiAgICAgIHRoaXMuY2xpZW50LnN0YXJ0dGxzKHRsc09wdGlvbnMsIG51bGwsIChlcnJvciwgcmVzcG9uc2UpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgbG9nX2Vycm9yKCdUTFMgY29ubmVjdGlvbicsIGVycm9yKTtcbiAgICAgICAgICBpZiAocmVwbGllZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHJlcGxpZWQgPSB0cnVlO1xuICAgICAgICAgICAgY2FsbGJhY2soZXJyb3IsIG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBsb2dfaW5mbygnVExTIGNvbm5lY3RlZCcpO1xuICAgICAgICB0aGlzLmNvbm5lY3RlZCA9IHRydWU7XG4gICAgICAgIGlmIChyZXBsaWVkID09PSBmYWxzZSkge1xuICAgICAgICAgIHJlcGxpZWQgPSB0cnVlO1xuICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlc3BvbnNlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY2xpZW50Lm9uKCdjb25uZWN0JywgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGxvZ19pbmZvKCdMREFQIGNvbm5lY3RlZCcpO1xuICAgICAgICB0aGlzLmNvbm5lY3RlZCA9IHRydWU7XG4gICAgICAgIGlmIChyZXBsaWVkID09PSBmYWxzZSkge1xuICAgICAgICAgIHJlcGxpZWQgPSB0cnVlO1xuICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlc3BvbnNlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAocmVwbGllZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgbG9nX2Vycm9yKCdjb25uZWN0aW9uIHRpbWUgb3V0JywgY29ubmVjdGlvbk9wdGlvbnMuY29ubmVjdFRpbWVvdXQpO1xuICAgICAgICByZXBsaWVkID0gdHJ1ZTtcbiAgICAgICAgY2FsbGJhY2sobmV3IEVycm9yKCdUaW1lb3V0JykpO1xuICAgICAgfVxuICAgIH0sIGNvbm5lY3Rpb25PcHRpb25zLmNvbm5lY3RUaW1lb3V0KTtcbiAgfVxuXG4gIGdldFVzZXJGaWx0ZXIodXNlcm5hbWUpIHtcbiAgICBjb25zdCBmaWx0ZXIgPSBbXTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMuVXNlcl9TZWFyY2hfRmlsdGVyICE9PSAnJykge1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5Vc2VyX1NlYXJjaF9GaWx0ZXJbMF0gPT09ICcoJykge1xuICAgICAgICBmaWx0ZXIucHVzaChgJHsgdGhpcy5vcHRpb25zLlVzZXJfU2VhcmNoX0ZpbHRlciB9YCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmaWx0ZXIucHVzaChgKCR7IHRoaXMub3B0aW9ucy5Vc2VyX1NlYXJjaF9GaWx0ZXIgfSlgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB1c2VybmFtZUZpbHRlciA9IHRoaXMub3B0aW9ucy5Vc2VyX1NlYXJjaF9GaWVsZC5zcGxpdCgnLCcpLm1hcCgoaXRlbSkgPT4gYCgkeyBpdGVtIH09JHsgdXNlcm5hbWUgfSlgKTtcblxuICAgIGlmICh1c2VybmFtZUZpbHRlci5sZW5ndGggPT09IDApIHtcbiAgICAgIGxvZ19lcnJvcignTERBUF9MREFQX1VzZXJfU2VhcmNoX0ZpZWxkIG5vdCBkZWZpbmVkJyk7XG4gICAgfSBlbHNlIGlmICh1c2VybmFtZUZpbHRlci5sZW5ndGggPT09IDEpIHtcbiAgICAgIGZpbHRlci5wdXNoKGAkeyB1c2VybmFtZUZpbHRlclswXSB9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbHRlci5wdXNoKGAofCR7IHVzZXJuYW1lRmlsdGVyLmpvaW4oJycpIH0pYCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGAoJiR7IGZpbHRlci5qb2luKCcnKSB9KWA7XG4gIH1cblxuICBiaW5kSWZOZWNlc3NhcnkoKSB7XG4gICAgaWYgKHRoaXMuZG9tYWluQmluZGVkID09PSB0cnVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5BdXRoZW50aWNhdGlvbiAhPT0gdHJ1ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGxvZ19pbmZvKCdCaW5kaW5nIFVzZXJETicsIHRoaXMub3B0aW9ucy5BdXRoZW50aWNhdGlvbl9Vc2VyRE4pO1xuICAgIHRoaXMuYmluZFN5bmModGhpcy5vcHRpb25zLkF1dGhlbnRpY2F0aW9uX1VzZXJETiwgdGhpcy5vcHRpb25zLkF1dGhlbnRpY2F0aW9uX1Bhc3N3b3JkKTtcbiAgICB0aGlzLmRvbWFpbkJpbmRlZCA9IHRydWU7XG4gIH1cblxuICBzZWFyY2hVc2Vyc1N5bmModXNlcm5hbWUsIHBhZ2UpIHtcbiAgICB0aGlzLmJpbmRJZk5lY2Vzc2FyeSgpO1xuXG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlcjogdGhpcy5nZXRVc2VyRmlsdGVyKHVzZXJuYW1lKSxcbiAgICAgIHNjb3BlOiB0aGlzLm9wdGlvbnMuVXNlcl9TZWFyY2hfU2NvcGUgfHwgJ3N1YicsXG4gICAgICBzaXplTGltaXQ6IHRoaXMub3B0aW9ucy5TZWFyY2hfU2l6ZV9MaW1pdCxcbiAgICB9O1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5TZWFyY2hfUGFnZV9TaXplID4gMCkge1xuICAgICAgc2VhcmNoT3B0aW9ucy5wYWdlZCA9IHtcbiAgICAgICAgcGFnZVNpemU6IHRoaXMub3B0aW9ucy5TZWFyY2hfUGFnZV9TaXplLFxuICAgICAgICBwYWdlUGF1c2U6ICEhcGFnZSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgbG9nX2luZm8oJ1NlYXJjaGluZyB1c2VyJywgdXNlcm5hbWUpO1xuICAgIGxvZ19kZWJ1Zygnc2VhcmNoT3B0aW9ucycsIHNlYXJjaE9wdGlvbnMpO1xuICAgIGxvZ19kZWJ1ZygnQmFzZUROJywgdGhpcy5vcHRpb25zLkJhc2VETik7XG5cbiAgICBpZiAocGFnZSkge1xuICAgICAgcmV0dXJuIHRoaXMuc2VhcmNoQWxsUGFnZWQodGhpcy5vcHRpb25zLkJhc2VETiwgc2VhcmNoT3B0aW9ucywgcGFnZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuc2VhcmNoQWxsU3luYyh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zKTtcbiAgfVxuXG4gIGdldFVzZXJCeUlkU3luYyhpZCwgYXR0cmlidXRlKSB7XG4gICAgdGhpcy5iaW5kSWZOZWNlc3NhcnkoKTtcblxuICAgIGNvbnN0IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gdGhpcy5jb25zdHJ1Y3Rvci5zZXR0aW5nc19nZXQoJ0xEQVBfVU5JUVVFX0lERU5USUZJRVJfRklFTEQnKS5zcGxpdCgnLCcpO1xuXG4gICAgbGV0IGZpbHRlcjtcblxuICAgIGlmIChhdHRyaWJ1dGUpIHtcbiAgICAgIGZpbHRlciA9IG5ldyB0aGlzLmxkYXBqcy5maWx0ZXJzLkVxdWFsaXR5RmlsdGVyKHtcbiAgICAgICAgYXR0cmlidXRlLFxuICAgICAgICB2YWx1ZTogbmV3IEJ1ZmZlcihpZCwgJ2hleCcpLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGZpbHRlcnMgPSBbXTtcbiAgICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgZmlsdGVycy5wdXNoKG5ldyB0aGlzLmxkYXBqcy5maWx0ZXJzLkVxdWFsaXR5RmlsdGVyKHtcbiAgICAgICAgICBhdHRyaWJ1dGU6IGl0ZW0sXG4gICAgICAgICAgdmFsdWU6IG5ldyBCdWZmZXIoaWQsICdoZXgnKSxcbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGZpbHRlciA9IG5ldyB0aGlzLmxkYXBqcy5maWx0ZXJzLk9yRmlsdGVyKHtmaWx0ZXJzfSk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlcixcbiAgICAgIHNjb3BlOiAnc3ViJyxcbiAgICB9O1xuXG4gICAgbG9nX2luZm8oJ1NlYXJjaGluZyBieSBpZCcsIGlkKTtcbiAgICBsb2dfZGVidWcoJ3NlYXJjaCBmaWx0ZXInLCBzZWFyY2hPcHRpb25zLmZpbHRlci50b1N0cmluZygpKTtcbiAgICBsb2dfZGVidWcoJ0Jhc2VETicsIHRoaXMub3B0aW9ucy5CYXNlRE4pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5zZWFyY2hBbGxTeW5jKHRoaXMub3B0aW9ucy5CYXNlRE4sIHNlYXJjaE9wdGlvbnMpO1xuXG4gICAgaWYgKCFBcnJheS5pc0FycmF5KHJlc3VsdCkgfHwgcmVzdWx0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMSkge1xuICAgICAgbG9nX2Vycm9yKCdTZWFyY2ggYnkgaWQnLCBpZCwgJ3JldHVybmVkJywgcmVzdWx0Lmxlbmd0aCwgJ3JlY29yZHMnKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzdWx0WzBdO1xuICB9XG5cbiAgZ2V0VXNlckJ5VXNlcm5hbWVTeW5jKHVzZXJuYW1lKSB7XG4gICAgdGhpcy5iaW5kSWZOZWNlc3NhcnkoKTtcblxuICAgIGNvbnN0IHNlYXJjaE9wdGlvbnMgPSB7XG4gICAgICBmaWx0ZXI6IHRoaXMuZ2V0VXNlckZpbHRlcih1c2VybmFtZSksXG4gICAgICBzY29wZTogdGhpcy5vcHRpb25zLlVzZXJfU2VhcmNoX1Njb3BlIHx8ICdzdWInLFxuICAgIH07XG5cbiAgICBsb2dfaW5mbygnU2VhcmNoaW5nIHVzZXInLCB1c2VybmFtZSk7XG4gICAgbG9nX2RlYnVnKCdzZWFyY2hPcHRpb25zJywgc2VhcmNoT3B0aW9ucyk7XG4gICAgbG9nX2RlYnVnKCdCYXNlRE4nLCB0aGlzLm9wdGlvbnMuQmFzZUROKTtcblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuc2VhcmNoQWxsU3luYyh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zKTtcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShyZXN1bHQpIHx8IHJlc3VsdC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAocmVzdWx0Lmxlbmd0aCA+IDEpIHtcbiAgICAgIGxvZ19lcnJvcignU2VhcmNoIGJ5IHVzZXJuYW1lJywgdXNlcm5hbWUsICdyZXR1cm5lZCcsIHJlc3VsdC5sZW5ndGgsICdyZWNvcmRzJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdFswXTtcbiAgfVxuXG4gIGdldFVzZXJHcm91cHModXNlcm5hbWUsIGxkYXBVc2VyKXtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgY29uc3QgZmlsdGVyID0gWycoJiddO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfb2JqZWN0X2NsYXNzICE9PSAnJykge1xuICAgICAgZmlsdGVyLnB1c2goYChvYmplY3RjbGFzcz0keyB0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX29iamVjdF9jbGFzcyB9KWApO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX21lbWJlcl9hdHRyaWJ1dGUgIT09ICcnKSB7XG4gICAgICBjb25zdCBmb3JtYXRfdmFsdWUgPSBsZGFwVXNlclt0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX21lbWJlcl9mb3JtYXRdO1xuICAgICAgaWYoIGZvcm1hdF92YWx1ZSApIHtcbiAgICAgICAgZmlsdGVyLnB1c2goYCgkeyB0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX21lbWJlcl9hdHRyaWJ1dGUgfT0keyBmb3JtYXRfdmFsdWUgfSlgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBmaWx0ZXIucHVzaCgnKScpO1xuXG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlcjogZmlsdGVyLmpvaW4oJycpLnJlcGxhY2UoLyN7dXNlcm5hbWV9L2csIHVzZXJuYW1lKSxcbiAgICAgIHNjb3BlOiAnc3ViJyxcbiAgICB9O1xuXG4gICAgbG9nX2RlYnVnKCdHcm91cCBsaXN0IGZpbHRlciBMREFQOicsIHNlYXJjaE9wdGlvbnMuZmlsdGVyKTtcblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuc2VhcmNoQWxsU3luYyh0aGlzLm9wdGlvbnMuQmFzZUROLCBzZWFyY2hPcHRpb25zKTtcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShyZXN1bHQpIHx8IHJlc3VsdC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBjb25zdCBncnBfaWRlbnRpZmllciA9IHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfaWRfYXR0cmlidXRlIHx8ICdjbic7XG4gICAgY29uc3QgZ3JvdXBzID0gW107XG4gICAgcmVzdWx0Lm1hcCgoaXRlbSkgPT4ge1xuICAgICAgZ3JvdXBzLnB1c2goIGl0ZW1bIGdycF9pZGVudGlmaWVyIF0gKTtcbiAgICB9KTtcbiAgICBsb2dfZGVidWcoYEdyb3VwczogJHsgIGdyb3Vwcy5qb2luKCcsICcpfWApO1xuICAgIHJldHVybiBncm91cHM7XG5cbiAgfVxuXG4gIGlzVXNlckluR3JvdXAodXNlcm5hbWUsIGxkYXBVc2VyKSB7XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2VuYWJsZWQpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIGNvbnN0IGdycHMgPSB0aGlzLmdldFVzZXJHcm91cHModXNlcm5hbWUsIGxkYXBVc2VyKTtcblxuICAgIGNvbnN0IGZpbHRlciA9IFsnKCYnXTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX29iamVjdF9jbGFzcyAhPT0gJycpIHtcbiAgICAgIGZpbHRlci5wdXNoKGAob2JqZWN0Y2xhc3M9JHsgdGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9vYmplY3RfY2xhc3MgfSlgKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfYXR0cmlidXRlICE9PSAnJykge1xuICAgICAgY29uc3QgZm9ybWF0X3ZhbHVlID0gbGRhcFVzZXJbdGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfZm9ybWF0XTtcbiAgICAgIGlmKCBmb3JtYXRfdmFsdWUgKSB7XG4gICAgICAgIGZpbHRlci5wdXNoKGAoJHsgdGhpcy5vcHRpb25zLmdyb3VwX2ZpbHRlcl9ncm91cF9tZW1iZXJfYXR0cmlidXRlIH09JHsgZm9ybWF0X3ZhbHVlIH0pYCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfaWRfYXR0cmlidXRlICE9PSAnJykge1xuICAgICAgZmlsdGVyLnB1c2goYCgkeyB0aGlzLm9wdGlvbnMuZ3JvdXBfZmlsdGVyX2dyb3VwX2lkX2F0dHJpYnV0ZSB9PSR7IHRoaXMub3B0aW9ucy5ncm91cF9maWx0ZXJfZ3JvdXBfbmFtZSB9KWApO1xuICAgIH1cbiAgICBmaWx0ZXIucHVzaCgnKScpO1xuXG4gICAgY29uc3Qgc2VhcmNoT3B0aW9ucyA9IHtcbiAgICAgIGZpbHRlcjogZmlsdGVyLmpvaW4oJycpLnJlcGxhY2UoLyN7dXNlcm5hbWV9L2csIHVzZXJuYW1lKSxcbiAgICAgIHNjb3BlOiAnc3ViJyxcbiAgICB9O1xuXG4gICAgbG9nX2RlYnVnKCdHcm91cCBmaWx0ZXIgTERBUDonLCBzZWFyY2hPcHRpb25zLmZpbHRlcik7XG5cbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLnNlYXJjaEFsbFN5bmModGhpcy5vcHRpb25zLkJhc2VETiwgc2VhcmNoT3B0aW9ucyk7XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocmVzdWx0KSB8fCByZXN1bHQubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgZXh0cmFjdExkYXBFbnRyeURhdGEoZW50cnkpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSB7XG4gICAgICBfcmF3OiBlbnRyeS5yYXcsXG4gICAgfTtcblxuICAgIE9iamVjdC5rZXlzKHZhbHVlcy5fcmF3KS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGNvbnN0IHZhbHVlID0gdmFsdWVzLl9yYXdba2V5XTtcblxuICAgICAgaWYgKCFbJ3RodW1ibmFpbFBob3RvJywgJ2pwZWdQaG90byddLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICAgICAgdmFsdWVzW2tleV0gPSB2YWx1ZS50b1N0cmluZygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhbHVlc1trZXldID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiB2YWx1ZXM7XG4gIH1cblxuICBzZWFyY2hBbGxQYWdlZChCYXNlRE4sIG9wdGlvbnMsIHBhZ2UpIHtcbiAgICB0aGlzLmJpbmRJZk5lY2Vzc2FyeSgpO1xuXG4gICAgY29uc3QgcHJvY2Vzc1BhZ2UgPSAoe2VudHJpZXMsIHRpdGxlLCBlbmQsIG5leHR9KSA9PiB7XG4gICAgICBsb2dfaW5mbyh0aXRsZSk7XG4gICAgICAvLyBGb3JjZSBMREFQIGlkbGUgdG8gd2FpdCB0aGUgcmVjb3JkIHByb2Nlc3NpbmdcbiAgICAgIHRoaXMuY2xpZW50Ll91cGRhdGVJZGxlKHRydWUpO1xuICAgICAgcGFnZShudWxsLCBlbnRyaWVzLCB7ZW5kLCBuZXh0OiAoKSA9PiB7XG4gICAgICAgIC8vIFJlc2V0IGlkbGUgdGltZXJcbiAgICAgICAgdGhpcy5jbGllbnQuX3VwZGF0ZUlkbGUoKTtcbiAgICAgICAgbmV4dCAmJiBuZXh0KCk7XG4gICAgICB9fSk7XG4gICAgfTtcblxuICAgIHRoaXMuY2xpZW50LnNlYXJjaChCYXNlRE4sIG9wdGlvbnMsIChlcnJvciwgcmVzKSA9PiB7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgbG9nX2Vycm9yKGVycm9yKTtcbiAgICAgICAgcGFnZShlcnJvcik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgcmVzLm9uKCdlcnJvcicsIChlcnJvcikgPT4ge1xuICAgICAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgICAgICBwYWdlKGVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSk7XG5cbiAgICAgIGxldCBlbnRyaWVzID0gW107XG5cbiAgICAgIGNvbnN0IGludGVybmFsUGFnZVNpemUgPSBvcHRpb25zLnBhZ2VkICYmIG9wdGlvbnMucGFnZWQucGFnZVNpemUgPiAwID8gb3B0aW9ucy5wYWdlZC5wYWdlU2l6ZSAqIDIgOiA1MDA7XG5cbiAgICAgIHJlcy5vbignc2VhcmNoRW50cnknLCAoZW50cnkpID0+IHtcbiAgICAgICAgZW50cmllcy5wdXNoKHRoaXMuZXh0cmFjdExkYXBFbnRyeURhdGEoZW50cnkpKTtcblxuICAgICAgICBpZiAoZW50cmllcy5sZW5ndGggPj0gaW50ZXJuYWxQYWdlU2l6ZSkge1xuICAgICAgICAgIHByb2Nlc3NQYWdlKHtcbiAgICAgICAgICAgIGVudHJpZXMsXG4gICAgICAgICAgICB0aXRsZTogJ0ludGVybmFsIFBhZ2UnLFxuICAgICAgICAgICAgZW5kOiBmYWxzZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBlbnRyaWVzID0gW107XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICByZXMub24oJ3BhZ2UnLCAocmVzdWx0LCBuZXh0KSA9PiB7XG4gICAgICAgIGlmICghbmV4dCkge1xuICAgICAgICAgIHRoaXMuY2xpZW50Ll91cGRhdGVJZGxlKHRydWUpO1xuICAgICAgICAgIHByb2Nlc3NQYWdlKHtcbiAgICAgICAgICAgIGVudHJpZXMsXG4gICAgICAgICAgICB0aXRsZTogJ0ZpbmFsIFBhZ2UnLFxuICAgICAgICAgICAgZW5kOiB0cnVlLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGVudHJpZXMubGVuZ3RoKSB7XG4gICAgICAgICAgbG9nX2luZm8oJ1BhZ2UnKTtcbiAgICAgICAgICBwcm9jZXNzUGFnZSh7XG4gICAgICAgICAgICBlbnRyaWVzLFxuICAgICAgICAgICAgdGl0bGU6ICdQYWdlJyxcbiAgICAgICAgICAgIGVuZDogZmFsc2UsXG4gICAgICAgICAgICBuZXh0LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGVudHJpZXMgPSBbXTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHJlcy5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICBpZiAoZW50cmllcy5sZW5ndGgpIHtcbiAgICAgICAgICBwcm9jZXNzUGFnZSh7XG4gICAgICAgICAgICBlbnRyaWVzLFxuICAgICAgICAgICAgdGl0bGU6ICdGaW5hbCBQYWdlJyxcbiAgICAgICAgICAgIGVuZDogdHJ1ZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBlbnRyaWVzID0gW107XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgc2VhcmNoQWxsQXN5bmMoQmFzZUROLCBvcHRpb25zLCBjYWxsYmFjaykge1xuICAgIHRoaXMuYmluZElmTmVjZXNzYXJ5KCk7XG5cbiAgICB0aGlzLmNsaWVudC5zZWFyY2goQmFzZUROLCBvcHRpb25zLCAoZXJyb3IsIHJlcykgPT4ge1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGxvZ19lcnJvcihlcnJvcik7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICByZXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiB7XG4gICAgICAgIGxvZ19lcnJvcihlcnJvcik7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGVudHJpZXMgPSBbXTtcblxuICAgICAgcmVzLm9uKCdzZWFyY2hFbnRyeScsIChlbnRyeSkgPT4ge1xuICAgICAgICBlbnRyaWVzLnB1c2godGhpcy5leHRyYWN0TGRhcEVudHJ5RGF0YShlbnRyeSkpO1xuICAgICAgfSk7XG5cbiAgICAgIHJlcy5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICBsb2dfaW5mbygnU2VhcmNoIHJlc3VsdCBjb3VudCcsIGVudHJpZXMubGVuZ3RoKTtcbiAgICAgICAgY2FsbGJhY2sobnVsbCwgZW50cmllcyk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIGF1dGhTeW5jKGRuLCBwYXNzd29yZCkge1xuICAgIGxvZ19pbmZvKCdBdXRoZW50aWNhdGluZycsIGRuKTtcblxuICAgIHRyeSB7XG4gICAgICBpZiAocGFzc3dvcmQgPT09ICcnKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUGFzc3dvcmQgaXMgbm90IHByb3ZpZGVkJyk7XG4gICAgICB9XG4gICAgICB0aGlzLmJpbmRTeW5jKGRuLCBwYXNzd29yZCk7XG4gICAgICBsb2dfaW5mbygnQXV0aGVudGljYXRlZCcsIGRuKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2dfaW5mbygnTm90IGF1dGhlbnRpY2F0ZWQnLCBkbik7XG4gICAgICBsb2dfZGVidWcoJ2Vycm9yJywgZXJyb3IpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIGRpc2Nvbm5lY3QoKSB7XG4gICAgdGhpcy5jb25uZWN0ZWQgPSBmYWxzZTtcbiAgICB0aGlzLmRvbWFpbkJpbmRlZCA9IGZhbHNlO1xuICAgIGxvZ19pbmZvKCdEaXNjb25lY3RpbmcnKTtcbiAgICB0aGlzLmNsaWVudC51bmJpbmQoKTtcbiAgfVxufVxuIiwiY29uc3QgaXNMb2dFbmFibGVkID0gKHByb2Nlc3MuZW52LkxEQVBfTE9HX0VOQUJMRUQgPT09ICd0cnVlJyk7XG5cblxuZnVuY3Rpb24gbG9nIChsZXZlbCwgbWVzc2FnZSwgZGF0YSkgeyBcbiAgICBpZiAoaXNMb2dFbmFibGVkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbJHtsZXZlbH1dICR7bWVzc2FnZX0gJHsgZGF0YSA/IEpTT04uc3RyaW5naWZ5KGRhdGEsIG51bGwsIDIpIDogJycgfWApO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gbG9nX2RlYnVnICguLi5hcmdzKSB7IGxvZygnREVCVUcnLCAuLi5hcmdzKTsgfVxuZnVuY3Rpb24gbG9nX2luZm8gKC4uLmFyZ3MpIHsgbG9nKCdJTkZPJywgLi4uYXJncyk7IH1cbmZ1bmN0aW9uIGxvZ193YXJuICguLi5hcmdzKSB7IGxvZygnV0FSTicsIC4uLmFyZ3MpOyB9XG5mdW5jdGlvbiBsb2dfZXJyb3IgKC4uLmFyZ3MpIHsgbG9nKCdFUlJPUicsIC4uLmFyZ3MpOyB9XG5cbmV4cG9ydCB7IGxvZywgbG9nX2RlYnVnLCBsb2dfaW5mbywgbG9nX3dhcm4sIGxvZ19lcnJvciB9O1xuIiwiaW1wb3J0IHtzbHVnLCBnZXRMZGFwVXNlcm5hbWUsIGdldExkYXBFbWFpbCwgZ2V0TGRhcFVzZXJVbmlxdWVJRCwgc3luY1VzZXJEYXRhLCBhZGRMZGFwVXNlcn0gZnJvbSAnLi9zeW5jJztcbmltcG9ydCBMREFQIGZyb20gJy4vbGRhcCc7XG5pbXBvcnQgeyBsb2dfZGVidWcsIGxvZ19pbmZvLCBsb2dfd2FybiwgbG9nX2Vycm9yIH0gZnJvbSAnLi9sb2dnZXInO1xuXG5mdW5jdGlvbiBmYWxsYmFja0RlZmF1bHRBY2NvdW50U3lzdGVtKGJpbmQsIHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICBpZiAodHlwZW9mIHVzZXJuYW1lID09PSAnc3RyaW5nJykge1xuICAgIGlmICh1c2VybmFtZS5pbmRleE9mKCdAJykgPT09IC0xKSB7XG4gICAgICB1c2VybmFtZSA9IHt1c2VybmFtZX07XG4gICAgfSBlbHNlIHtcbiAgICAgIHVzZXJuYW1lID0ge2VtYWlsOiB1c2VybmFtZX07XG4gICAgfVxuICB9XG5cbiAgbG9nX2luZm8oJ0ZhbGxiYWNrIHRvIGRlZmF1bHQgYWNjb3VudCBzeXN0ZW06ICcsIHVzZXJuYW1lICk7XG5cbiAgY29uc3QgbG9naW5SZXF1ZXN0ID0ge1xuICAgIHVzZXI6IHVzZXJuYW1lLFxuICAgIHBhc3N3b3JkOiB7XG4gICAgICBkaWdlc3Q6IFNIQTI1NihwYXNzd29yZCksXG4gICAgICBhbGdvcml0aG06ICdzaGEtMjU2JyxcbiAgICB9LFxuICB9O1xuICBsb2dfZGVidWcoJ0ZhbGxiYWNrIG9wdGlvbnM6ICcsIGxvZ2luUmVxdWVzdCk7XG5cbiAgcmV0dXJuIEFjY291bnRzLl9ydW5Mb2dpbkhhbmRsZXJzKGJpbmQsIGxvZ2luUmVxdWVzdCk7XG59XG5cbkFjY291bnRzLnJlZ2lzdGVyTG9naW5IYW5kbGVyKCdsZGFwJywgZnVuY3Rpb24obG9naW5SZXF1ZXN0KSB7XG4gIGlmICghbG9naW5SZXF1ZXN0LmxkYXAgfHwgIWxvZ2luUmVxdWVzdC5sZGFwT3B0aW9ucykge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cblxuICBsb2dfaW5mbygnSW5pdCBMREFQIGxvZ2luJywgbG9naW5SZXF1ZXN0LnVzZXJuYW1lKTtcblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU5BQkxFJykgIT09IHRydWUpIHtcbiAgICByZXR1cm4gZmFsbGJhY2tEZWZhdWx0QWNjb3VudFN5c3RlbSh0aGlzLCBsb2dpblJlcXVlc3QudXNlcm5hbWUsIGxvZ2luUmVxdWVzdC5sZGFwUGFzcyk7XG4gIH1cblxuICBjb25zdCBzZWxmID0gdGhpcztcbiAgY29uc3QgbGRhcCA9IG5ldyBMREFQKCk7XG4gIGxldCBsZGFwVXNlcjtcblxuICB0cnkge1xuICAgIGxkYXAuY29ubmVjdFN5bmMoKTtcbiAgICBjb25zdCB1c2VycyA9IGxkYXAuc2VhcmNoVXNlcnNTeW5jKGxvZ2luUmVxdWVzdC51c2VybmFtZSk7XG5cbiAgICBpZiAodXNlcnMubGVuZ3RoICE9PSAxKSB7XG4gICAgICBsb2dfaW5mbygnU2VhcmNoIHJldHVybmVkJywgdXNlcnMubGVuZ3RoLCAncmVjb3JkKHMpIGZvcicsIGxvZ2luUmVxdWVzdC51c2VybmFtZSk7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgbm90IEZvdW5kJyk7XG4gICAgfVxuXG4gICAgaWYgKGxkYXAuYXV0aFN5bmModXNlcnNbMF0uZG4sIGxvZ2luUmVxdWVzdC5sZGFwUGFzcykgPT09IHRydWUpIHtcbiAgICAgIGlmIChsZGFwLmlzVXNlckluR3JvdXAobG9naW5SZXF1ZXN0LnVzZXJuYW1lLCB1c2Vyc1swXSkpIHtcbiAgICAgICAgbGRhcFVzZXIgPSB1c2Vyc1swXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignVXNlciBub3QgaW4gYSB2YWxpZCBncm91cCcpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBsb2dfaW5mbygnV3JvbmcgcGFzc3dvcmQgZm9yJywgbG9naW5SZXF1ZXN0LnVzZXJuYW1lKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nX2Vycm9yKGVycm9yKTtcbiAgfVxuXG4gIGlmIChsZGFwVXNlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0xPR0lOX0ZBTExCQUNLJykgPT09IHRydWUpIHtcbiAgICAgIHJldHVybiBmYWxsYmFja0RlZmF1bHRBY2NvdW50U3lzdGVtKHNlbGYsIGxvZ2luUmVxdWVzdC51c2VybmFtZSwgbG9naW5SZXF1ZXN0LmxkYXBQYXNzKTtcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdMREFQLWxvZ2luLWVycm9yJywgYExEQVAgQXV0aGVudGljYXRpb24gZmFpbGVkIHdpdGggcHJvdmlkZWQgdXNlcm5hbWUgWyR7IGxvZ2luUmVxdWVzdC51c2VybmFtZSB9XWApO1xuICB9XG5cbiAgLy8gTG9vayB0byBzZWUgaWYgdXNlciBhbHJlYWR5IGV4aXN0c1xuXG4gIGxldCB1c2VyUXVlcnk7XG5cbiAgY29uc3QgVW5pcXVlX0lkZW50aWZpZXJfRmllbGQgPSBnZXRMZGFwVXNlclVuaXF1ZUlEKGxkYXBVc2VyKTtcbiAgbGV0IHVzZXI7XG5cbiAgLy8gQXR0ZW1wdCB0byBmaW5kIHVzZXIgYnkgdW5pcXVlIGlkZW50aWZpZXJcblxuICBpZiAoVW5pcXVlX0lkZW50aWZpZXJfRmllbGQpIHtcbiAgICB1c2VyUXVlcnkgPSB7XG4gICAgICAnc2VydmljZXMubGRhcC5pZCc6IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLnZhbHVlLFxuICAgIH07XG5cbiAgICBsb2dfaW5mbygnUXVlcnlpbmcgdXNlcicpO1xuICAgIGxvZ19kZWJ1ZygndXNlclF1ZXJ5JywgdXNlclF1ZXJ5KTtcblxuICAgIHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh1c2VyUXVlcnkpO1xuICB9XG5cbiAgLy8gQXR0ZW1wdCB0byBmaW5kIHVzZXIgYnkgdXNlcm5hbWVcblxuICBsZXQgdXNlcm5hbWU7XG4gIGxldCBlbWFpbDtcblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUk5BTUVfRklFTEQnKSAhPT0gJycpIHtcbiAgICB1c2VybmFtZSA9IHNsdWcoZ2V0TGRhcFVzZXJuYW1lKGxkYXBVc2VyKSk7XG4gIH0gZWxzZSB7XG4gICAgdXNlcm5hbWUgPSBzbHVnKGxvZ2luUmVxdWVzdC51c2VybmFtZSk7XG4gIH1cblxuICBpZihMREFQLnNldHRpbmdzX2dldCgnTERBUF9FTUFJTF9GSUVMRCcpICE9PSAnJykge1xuICAgIGVtYWlsID0gZ2V0TGRhcEVtYWlsKGxkYXBVc2VyKTtcbiAgfVxuXG4gIGlmICghdXNlcikge1xuICAgIGlmKGVtYWlsICYmIExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0VNQUlMX01BVENIX1JFUVVJUkUnKSA9PT0gdHJ1ZSkge1xuICAgICAgaWYoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU1BSUxfTUFUQ0hfVkVSSUZJRUQnKSA9PT0gdHJ1ZSkge1xuICAgICAgICB1c2VyUXVlcnkgPSB7XG4gICAgICAgICAgJ19pZCcgOiB1c2VybmFtZSxcbiAgICAgICAgICAnZW1haWxzLjAuYWRkcmVzcycgOiBlbWFpbCxcbiAgICAgICAgICAnZW1haWxzLjAudmVyaWZpZWQnIDogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdXNlclF1ZXJ5ID0ge1xuICAgICAgICAgICdfaWQnIDogdXNlcm5hbWUsXG4gICAgICAgICAgJ2VtYWlscy4wLmFkZHJlc3MnIDogZW1haWxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdXNlclF1ZXJ5ID0ge1xuICAgICAgICB1c2VybmFtZVxuICAgICAgfTtcbiAgICB9XG5cbiAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeScsIHVzZXJRdWVyeSk7XG5cbiAgICB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodXNlclF1ZXJ5KTtcbiAgfVxuXG4gIC8vIEF0dGVtcHQgdG8gZmluZCB1c2VyIGJ5IGUtbWFpbCBhZGRyZXNzIG9ubHlcblxuICBpZiAoIXVzZXIgJiYgZW1haWwgJiYgTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU1BSUxfTUFUQ0hfRU5BQkxFJykgPT09IHRydWUpIHtcblxuICAgIGxvZ19pbmZvKCdObyB1c2VyIGV4aXN0cyB3aXRoIHVzZXJuYW1lJywgdXNlcm5hbWUsICctIGF0dGVtcHRpbmcgdG8gZmluZCBieSBlLW1haWwgYWRkcmVzcyBpbnN0ZWFkJyk7XG5cbiAgICBpZihMREFQLnNldHRpbmdzX2dldCgnTERBUF9FTUFJTF9NQVRDSF9WRVJJRklFRCcpID09PSB0cnVlKSB7XG4gICAgICB1c2VyUXVlcnkgPSB7XG4gICAgICAgICdlbWFpbHMuMC5hZGRyZXNzJzogZW1haWwsXG4gICAgICAgICdlbWFpbHMuMC52ZXJpZmllZCcgOiB0cnVlXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICB1c2VyUXVlcnkgPSB7XG4gICAgICAgICdlbWFpbHMuMC5hZGRyZXNzJyA6IGVtYWlsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGxvZ19kZWJ1ZygndXNlclF1ZXJ5JywgdXNlclF1ZXJ5KTtcblxuICAgIHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh1c2VyUXVlcnkpO1xuXG4gIH1cblxuICAvLyBMb2dpbiB1c2VyIGlmIHRoZXkgZXhpc3RcbiAgaWYgKHVzZXIpIHtcbiAgICBpZiAodXNlci5hdXRoZW50aWNhdGlvbk1ldGhvZCAhPT0gJ2xkYXAnICYmIExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX01FUkdFX0VYSVNUSU5HX1VTRVJTJykgIT09IHRydWUpIHtcbiAgICAgIGxvZ19pbmZvKCdVc2VyIGV4aXN0cyB3aXRob3V0IFwiYXV0aGVudGljYXRpb25NZXRob2QgOiBsZGFwXCInKTtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ0xEQVAtbG9naW4tZXJyb3InLCBgTERBUCBBdXRoZW50aWNhdGlvbiBzdWNjZWRlZCwgYnV0IHRoZXJlJ3MgYWxyZWFkeSBhIG1hdGNoaW5nIFdla2FuIGFjY291bnQgaW4gTW9uZ29EQmApO1xuICAgIH1cblxuICAgIGxvZ19pbmZvKCdMb2dnaW5nIHVzZXInKTtcblxuICAgIGNvbnN0IHN0YW1wZWRUb2tlbiA9IEFjY291bnRzLl9nZW5lcmF0ZVN0YW1wZWRMb2dpblRva2VuKCk7XG4gICAgY29uc3QgdXBkYXRlX2RhdGEgPSB7XG4gICAgICAkcHVzaDoge1xuICAgICAgICAnc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zJzogQWNjb3VudHMuX2hhc2hTdGFtcGVkVG9rZW4oc3RhbXBlZFRva2VuKSxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIGlmKCBMREFQLnNldHRpbmdzX2dldCgnTERBUF9TWU5DX0dST1VQX1JPTEVTJykgPT09IHRydWUgKSB7XG4gICAgICBsb2dfZGVidWcoJ1VwZGF0aW5nIEdyb3Vwcy9Sb2xlcycpO1xuICAgICAgY29uc3QgZ3JvdXBzID0gbGRhcC5nZXRVc2VyR3JvdXBzKHVzZXJuYW1lLCBsZGFwVXNlcik7XG5cbiAgICAgIGlmKCBncm91cHMubGVuZ3RoID4gMCApIHtcbiAgICAgICAgUm9sZXMuc2V0VXNlclJvbGVzKHVzZXIuX2lkLCBncm91cHMgKTtcbiAgICAgICAgbG9nX2luZm8oYFVwZGF0ZWQgcm9sZXMgdG86JHsgIGdyb3Vwcy5qb2luKCcsJyl9YCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VyLl9pZCwgdXBkYXRlX2RhdGEgKTtcblxuICAgIHN5bmNVc2VyRGF0YSh1c2VyLCBsZGFwVXNlcik7XG5cbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfTE9HSU5fRkFMTEJBQ0snKSA9PT0gdHJ1ZSkge1xuICAgICAgQWNjb3VudHMuc2V0UGFzc3dvcmQodXNlci5faWQsIGxvZ2luUmVxdWVzdC5sZGFwUGFzcywge2xvZ291dDogZmFsc2V9KTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgdXNlcklkOiB1c2VyLl9pZCxcbiAgICAgIHRva2VuOiBzdGFtcGVkVG9rZW4udG9rZW4sXG4gICAgfTtcbiAgfVxuXG4gIC8vIENyZWF0ZSBuZXcgdXNlclxuXG4gIGxvZ19pbmZvKCdVc2VyIGRvZXMgbm90IGV4aXN0LCBjcmVhdGluZycsIHVzZXJuYW1lKTtcblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfVVNFUk5BTUVfRklFTEQnKSA9PT0gJycpIHtcbiAgICB1c2VybmFtZSA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9MT0dJTl9GQUxMQkFDSycpICE9PSB0cnVlKSB7XG4gICAgbG9naW5SZXF1ZXN0LmxkYXBQYXNzID0gdW5kZWZpbmVkO1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gYWRkTGRhcFVzZXIobGRhcFVzZXIsIHVzZXJuYW1lLCBsb2dpblJlcXVlc3QubGRhcFBhc3MpO1xuXG4gIGlmKCBMREFQLnNldHRpbmdzX2dldCgnTERBUF9TWU5DX0dST1VQX1JPTEVTJykgPT09IHRydWUgKSB7XG4gICAgY29uc3QgZ3JvdXBzID0gbGRhcC5nZXRVc2VyR3JvdXBzKHVzZXJuYW1lLCBsZGFwVXNlcik7XG4gICAgaWYoIGdyb3Vwcy5sZW5ndGggPiAwICkge1xuICAgICAgUm9sZXMuc2V0VXNlclJvbGVzKHJlc3VsdC51c2VySWQsIGdyb3VwcyApO1xuICAgICAgbG9nX2luZm8oYFNldCByb2xlcyB0bzokeyAgZ3JvdXBzLmpvaW4oJywnKX1gKTtcbiAgICB9XG4gIH1cblxuXG4gIGlmIChyZXN1bHQgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHRocm93IHJlc3VsdDtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59KTtcbiIsImltcG9ydCBfIGZyb20gJ3VuZGVyc2NvcmUnO1xuaW1wb3J0IExEQVAgZnJvbSAnLi9sZGFwJztcbmltcG9ydCB7IGxvZ19kZWJ1ZywgbG9nX2luZm8sIGxvZ193YXJuLCBsb2dfZXJyb3IgfSBmcm9tICcuL2xvZ2dlcic7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShPYmplY3QucHJvdG90eXBlLCBcImdldExEQVBWYWx1ZVwiLCB7XG4gIHZhbHVlOiBmdW5jdGlvbiAocHJvcCkge1xuICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgICBmb3IgKGxldCBrZXkgaW4gc2VsZikge1xuICAgICAgICAgIGlmIChrZXkudG9Mb3dlckNhc2UoKSA9PSBwcm9wLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHNlbGZba2V5XTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gIH0sXG5cbiAgZW51bWVyYWJsZTogZmFsc2Vcbn0pO1xuXG5leHBvcnQgZnVuY3Rpb24gc2x1Zyh0ZXh0KSB7XG4gIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9VVEY4X05BTUVTX1NMVUdJRlknKSAhPT0gdHJ1ZSkge1xuICAgIHJldHVybiB0ZXh0O1xuICB9XG4gIHRleHQgPSBzbHVnaWZ5KHRleHQsICcuJyk7XG4gIHJldHVybiB0ZXh0LnJlcGxhY2UoL1teMC05YS16LV8uXS9nLCAnJyk7XG59XG5cbmZ1bmN0aW9uIHRlbXBsYXRlVmFySGFuZGxlciAodmFyaWFibGUsIG9iamVjdCkge1xuXG4gIGNvbnN0IHRlbXBsYXRlUmVnZXggPSAvI3soW1xcd1xcLV0rKX0vZ2k7XG4gIGxldCBtYXRjaCA9IHRlbXBsYXRlUmVnZXguZXhlYyh2YXJpYWJsZSk7XG4gIGxldCB0bXBWYXJpYWJsZSA9IHZhcmlhYmxlO1xuXG4gIGlmIChtYXRjaCA9PSBudWxsKSB7XG4gICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkodmFyaWFibGUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJldHVybiBvYmplY3RbdmFyaWFibGVdO1xuICB9IGVsc2Uge1xuICAgIHdoaWxlIChtYXRjaCAhPSBudWxsKSB7XG4gICAgICBjb25zdCB0bXBsVmFyID0gbWF0Y2hbMF07XG4gICAgICBjb25zdCB0bXBsQXR0ck5hbWUgPSBtYXRjaFsxXTtcblxuICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkodG1wbEF0dHJOYW1lKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGF0dHJWYWwgPSBvYmplY3RbdG1wbEF0dHJOYW1lXTtcbiAgICAgIHRtcFZhcmlhYmxlID0gdG1wVmFyaWFibGUucmVwbGFjZSh0bXBsVmFyLCBhdHRyVmFsKTtcbiAgICAgIG1hdGNoID0gdGVtcGxhdGVSZWdleC5leGVjKHZhcmlhYmxlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRtcFZhcmlhYmxlO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcm9wZXJ0eVZhbHVlKG9iaiwga2V5KSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIF8ucmVkdWNlKGtleS5zcGxpdCgnLicpLCAoYWNjLCBlbCkgPT4gYWNjW2VsXSwgb2JqKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGRhcFVzZXJuYW1lKGxkYXBVc2VyKSB7XG4gIGNvbnN0IHVzZXJuYW1lRmllbGQgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSTkFNRV9GSUVMRCcpO1xuXG4gIGlmICh1c2VybmFtZUZpZWxkLmluZGV4T2YoJyN7JykgPiAtMSkge1xuICAgIHJldHVybiB1c2VybmFtZUZpZWxkLnJlcGxhY2UoLyN7KC4rPyl9L2csIGZ1bmN0aW9uKG1hdGNoLCBmaWVsZCkge1xuICAgICAgcmV0dXJuIGxkYXBVc2VyLmdldExEQVBWYWx1ZShmaWVsZCk7XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gbGRhcFVzZXIuZ2V0TERBUFZhbHVlKHVzZXJuYW1lRmllbGQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGRhcEVtYWlsKGxkYXBVc2VyKSB7XG4gIGNvbnN0IGVtYWlsRmllbGQgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9FTUFJTF9GSUVMRCcpO1xuXG4gIGlmIChlbWFpbEZpZWxkLmluZGV4T2YoJyN7JykgPiAtMSkge1xuICAgIHJldHVybiBlbWFpbEZpZWxkLnJlcGxhY2UoLyN7KC4rPyl9L2csIGZ1bmN0aW9uKG1hdGNoLCBmaWVsZCkge1xuICAgICAgcmV0dXJuIGxkYXBVc2VyLmdldExEQVBWYWx1ZShmaWVsZCk7XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gbGRhcFVzZXIuZ2V0TERBUFZhbHVlKGVtYWlsRmllbGQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGRhcEZ1bGxuYW1lKGxkYXBVc2VyKSB7XG4gIGNvbnN0IGZ1bGxuYW1lRmllbGQgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9GVUxMTkFNRV9GSUVMRCcpO1xuICBpZiAoZnVsbG5hbWVGaWVsZC5pbmRleE9mKCcjeycpID4gLTEpIHtcbiAgICByZXR1cm4gZnVsbG5hbWVGaWVsZC5yZXBsYWNlKC8jeyguKz8pfS9nLCBmdW5jdGlvbihtYXRjaCwgZmllbGQpIHtcbiAgICAgIHJldHVybiBsZGFwVXNlci5nZXRMREFQVmFsdWUoZmllbGQpO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBsZGFwVXNlci5nZXRMREFQVmFsdWUoZnVsbG5hbWVGaWVsZCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRMZGFwVXNlclVuaXF1ZUlEKGxkYXBVc2VyKSB7XG4gIGxldCBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZCA9IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1VOSVFVRV9JREVOVElGSUVSX0ZJRUxEJyk7XG5cbiAgaWYgKFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkICE9PSAnJykge1xuICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gVW5pcXVlX0lkZW50aWZpZXJfRmllbGQucmVwbGFjZSgvXFxzL2csICcnKS5zcGxpdCgnLCcpO1xuICB9IGVsc2Uge1xuICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0gW107XG4gIH1cblxuICBsZXQgVXNlcl9TZWFyY2hfRmllbGQgPSBMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSX1NFQVJDSF9GSUVMRCcpO1xuXG4gIGlmIChVc2VyX1NlYXJjaF9GaWVsZCAhPT0gJycpIHtcbiAgICBVc2VyX1NlYXJjaF9GaWVsZCA9IFVzZXJfU2VhcmNoX0ZpZWxkLnJlcGxhY2UoL1xccy9nLCAnJykuc3BsaXQoJywnKTtcbiAgfSBlbHNlIHtcbiAgICBVc2VyX1NlYXJjaF9GaWVsZCA9IFtdO1xuICB9XG5cbiAgVW5pcXVlX0lkZW50aWZpZXJfRmllbGQgPSBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZC5jb25jYXQoVXNlcl9TZWFyY2hfRmllbGQpO1xuXG4gIGlmIChVbmlxdWVfSWRlbnRpZmllcl9GaWVsZC5sZW5ndGggPiAwKSB7XG4gICAgVW5pcXVlX0lkZW50aWZpZXJfRmllbGQgPSBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZC5maW5kKChmaWVsZCkgPT4ge1xuICAgICAgcmV0dXJuICFfLmlzRW1wdHkobGRhcFVzZXIuX3Jhdy5nZXRMREFQVmFsdWUoZmllbGQpKTtcbiAgICB9KTtcbiAgICBpZiAoVW5pcXVlX0lkZW50aWZpZXJfRmllbGQpIHtcblx0XHQgICAgbG9nX2RlYnVnKGBJZGVudGlmeWluZyB1c2VyIHdpdGg6ICR7ICBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZH1gKTtcbiAgICAgIFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkID0ge1xuICAgICAgICBhdHRyaWJ1dGU6IFVuaXF1ZV9JZGVudGlmaWVyX0ZpZWxkLFxuICAgICAgICB2YWx1ZTogbGRhcFVzZXIuX3Jhdy5nZXRMREFQVmFsdWUoVW5pcXVlX0lkZW50aWZpZXJfRmllbGQpLnRvU3RyaW5nKCdoZXgnKSxcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBVbmlxdWVfSWRlbnRpZmllcl9GaWVsZDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGF0YVRvU3luY1VzZXJEYXRhKGxkYXBVc2VyLCB1c2VyKSB7XG4gIGNvbnN0IHN5bmNVc2VyRGF0YSA9IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX1NZTkNfVVNFUl9EQVRBJyk7XG4gIGNvbnN0IHN5bmNVc2VyRGF0YUZpZWxkTWFwID0gTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfU1lOQ19VU0VSX0RBVEFfRklFTERNQVAnKS50cmltKCk7XG5cbiAgY29uc3QgdXNlckRhdGEgPSB7fTtcblxuICBpZiAoc3luY1VzZXJEYXRhICYmIHN5bmNVc2VyRGF0YUZpZWxkTWFwKSB7XG4gICAgY29uc3Qgd2hpdGVsaXN0ZWRVc2VyRmllbGRzID0gWydlbWFpbCcsICduYW1lJywgJ2N1c3RvbUZpZWxkcyddO1xuICAgIGNvbnN0IGZpZWxkTWFwID0gSlNPTi5wYXJzZShzeW5jVXNlckRhdGFGaWVsZE1hcCk7XG4gICAgY29uc3QgZW1haWxMaXN0ID0gW107XG4gICAgXy5tYXAoZmllbGRNYXAsIGZ1bmN0aW9uKHVzZXJGaWVsZCwgbGRhcEZpZWxkKSB7XG5cdFx0ICAgIGxvZ19kZWJ1ZyhgTWFwcGluZyBmaWVsZCAke2xkYXBGaWVsZH0gLT4gJHt1c2VyRmllbGR9YCk7XG4gICAgICBzd2l0Y2ggKHVzZXJGaWVsZCkge1xuICAgICAgY2FzZSAnZW1haWwnOlxuICAgICAgICBpZiAoIWxkYXBVc2VyLmhhc093blByb3BlcnR5KGxkYXBGaWVsZCkpIHtcbiAgICAgICAgICBsb2dfZGVidWcoYHVzZXIgZG9lcyBub3QgaGF2ZSBhdHRyaWJ1dGU6ICR7IGxkYXBGaWVsZCB9YCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKF8uaXNPYmplY3QobGRhcFVzZXJbbGRhcEZpZWxkXSkpIHtcbiAgICAgICAgICBfLm1hcChsZGFwVXNlcltsZGFwRmllbGRdLCBmdW5jdGlvbihpdGVtKSB7XG4gICAgICAgICAgICBlbWFpbExpc3QucHVzaCh7IGFkZHJlc3M6IGl0ZW0sIHZlcmlmaWVkOiB0cnVlIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVtYWlsTGlzdC5wdXNoKHsgYWRkcmVzczogbGRhcFVzZXJbbGRhcEZpZWxkXSwgdmVyaWZpZWQ6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGNvbnN0IFtvdXRlcktleSwgaW5uZXJLZXlzXSA9IHVzZXJGaWVsZC5zcGxpdCgvXFwuKC4rKS8pO1xuXG4gICAgICAgIGlmICghXy5maW5kKHdoaXRlbGlzdGVkVXNlckZpZWxkcywgKGVsKSA9PiBlbCA9PT0gb3V0ZXJLZXkpKSB7XG4gICAgICAgICAgbG9nX2RlYnVnKGB1c2VyIGF0dHJpYnV0ZSBub3Qgd2hpdGVsaXN0ZWQ6ICR7IHVzZXJGaWVsZCB9YCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG91dGVyS2V5ID09PSAnY3VzdG9tRmllbGRzJykge1xuICAgICAgICAgIGxldCBjdXN0b21GaWVsZHNNZXRhO1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGN1c3RvbUZpZWxkc01ldGEgPSBKU09OLnBhcnNlKExEQVAuc2V0dGluZ3NfZ2V0KCdBY2NvdW50c19DdXN0b21GaWVsZHMnKSk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgbG9nX2RlYnVnKCdJbnZhbGlkIEpTT04gZm9yIEN1c3RvbSBGaWVsZHMnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoIWdldFByb3BlcnR5VmFsdWUoY3VzdG9tRmllbGRzTWV0YSwgaW5uZXJLZXlzKSkge1xuICAgICAgICAgICAgbG9nX2RlYnVnKGB1c2VyIGF0dHJpYnV0ZSBkb2VzIG5vdCBleGlzdDogJHsgdXNlckZpZWxkIH1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0bXBVc2VyRmllbGQgPSBnZXRQcm9wZXJ0eVZhbHVlKHVzZXIsIHVzZXJGaWVsZCk7XG4gICAgICAgIGNvbnN0IHRtcExkYXBGaWVsZCA9IHRlbXBsYXRlVmFySGFuZGxlcihsZGFwRmllbGQsIGxkYXBVc2VyKTtcblxuICAgICAgICBpZiAodG1wTGRhcEZpZWxkICYmIHRtcFVzZXJGaWVsZCAhPT0gdG1wTGRhcEZpZWxkKSB7XG4gICAgICAgICAgLy8gY3JlYXRlcyB0aGUgb2JqZWN0IHN0cnVjdHVyZSBpbnN0ZWFkIG9mIGp1c3QgYXNzaWduaW5nICd0bXBMZGFwRmllbGQnIHRvXG4gICAgICAgICAgLy8gJ3VzZXJEYXRhW3VzZXJGaWVsZF0nIGluIG9yZGVyIHRvIGF2b2lkIHRoZSBcImNhbm5vdCB1c2UgdGhlIHBhcnQgKC4uLilcbiAgICAgICAgICAvLyB0byB0cmF2ZXJzZSB0aGUgZWxlbWVudFwiIChNb25nb0RCKSBlcnJvciB0aGF0IGNhbiBoYXBwZW4uIERvIG5vdCBoYW5kbGVcbiAgICAgICAgICAvLyBhcnJheXMuXG4gICAgICAgICAgLy8gVE9ETzogRmluZCBhIGJldHRlciBzb2x1dGlvbi5cbiAgICAgICAgICBjb25zdCBkS2V5cyA9IHVzZXJGaWVsZC5zcGxpdCgnLicpO1xuICAgICAgICAgIGNvbnN0IGxhc3RLZXkgPSBfLmxhc3QoZEtleXMpO1xuICAgICAgICAgIF8ucmVkdWNlKGRLZXlzLCAob2JqLCBjdXJyS2V5KSA9PlxuICAgICAgICAgICAgKGN1cnJLZXkgPT09IGxhc3RLZXkpXG4gICAgICAgICAgICAgID8gb2JqW2N1cnJLZXldID0gdG1wTGRhcEZpZWxkXG4gICAgICAgICAgICAgIDogb2JqW2N1cnJLZXldID0gb2JqW2N1cnJLZXldIHx8IHt9XG4gICAgICAgICAgICAsIHVzZXJEYXRhKTtcbiAgICAgICAgICBsb2dfZGVidWcoYHVzZXIuJHsgdXNlckZpZWxkIH0gY2hhbmdlZCB0bzogJHsgdG1wTGRhcEZpZWxkIH1gKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYgKGVtYWlsTGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoSlNPTi5zdHJpbmdpZnkodXNlci5lbWFpbHMpICE9PSBKU09OLnN0cmluZ2lmeShlbWFpbExpc3QpKSB7XG4gICAgICAgIHVzZXJEYXRhLmVtYWlscyA9IGVtYWlsTGlzdDtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCB1bmlxdWVJZCA9IGdldExkYXBVc2VyVW5pcXVlSUQobGRhcFVzZXIpO1xuXG4gIGlmICh1bmlxdWVJZCAmJiAoIXVzZXIuc2VydmljZXMgfHwgIXVzZXIuc2VydmljZXMubGRhcCB8fCB1c2VyLnNlcnZpY2VzLmxkYXAuaWQgIT09IHVuaXF1ZUlkLnZhbHVlIHx8IHVzZXIuc2VydmljZXMubGRhcC5pZEF0dHJpYnV0ZSAhPT0gdW5pcXVlSWQuYXR0cmlidXRlKSkge1xuICAgIHVzZXJEYXRhWydzZXJ2aWNlcy5sZGFwLmlkJ10gPSB1bmlxdWVJZC52YWx1ZTtcbiAgICB1c2VyRGF0YVsnc2VydmljZXMubGRhcC5pZEF0dHJpYnV0ZSddID0gdW5pcXVlSWQuYXR0cmlidXRlO1xuICB9XG5cbiAgaWYgKHVzZXIuYXV0aGVudGljYXRpb25NZXRob2QgIT09ICdsZGFwJykge1xuICAgIHVzZXJEYXRhLmxkYXAgPSB0cnVlO1xuICB9XG5cbiAgaWYgKF8uc2l6ZSh1c2VyRGF0YSkpIHtcbiAgICByZXR1cm4gdXNlckRhdGE7XG4gIH1cbn1cblxuXG5leHBvcnQgZnVuY3Rpb24gc3luY1VzZXJEYXRhKHVzZXIsIGxkYXBVc2VyKSB7XG4gIGxvZ19pbmZvKCdTeW5jaW5nIHVzZXIgZGF0YScpO1xuICBsb2dfZGVidWcoJ3VzZXInLCB7J2VtYWlsJzogdXNlci5lbWFpbCwgJ19pZCc6IHVzZXIuX2lkfSk7XG4gIC8vIGxvZ19kZWJ1ZygnbGRhcFVzZXInLCBsZGFwVXNlci5vYmplY3QpO1xuXG4gIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSTkFNRV9GSUVMRCcpICE9PSAnJykge1xuICAgIGNvbnN0IHVzZXJuYW1lID0gc2x1ZyhnZXRMZGFwVXNlcm5hbWUobGRhcFVzZXIpKTtcbiAgICBpZiAodXNlciAmJiB1c2VyLl9pZCAmJiB1c2VybmFtZSAhPT0gdXNlci51c2VybmFtZSkge1xuICAgICAgbG9nX2luZm8oJ1N5bmNpbmcgdXNlciB1c2VybmFtZScsIHVzZXIudXNlcm5hbWUsICctPicsIHVzZXJuYW1lKTtcbiAgICAgIE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiB1c2VyLl9pZCB9LCB7ICRzZXQ6IHsgdXNlcm5hbWUgfX0pO1xuICAgIH1cbiAgfVxuXG4gIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9GVUxMTkFNRV9GSUVMRCcpICE9PSAnJykge1xuICAgIGNvbnN0IGZ1bGxuYW1lPSBnZXRMZGFwRnVsbG5hbWUobGRhcFVzZXIpO1xuICAgIGxvZ19kZWJ1ZygnZnVsbG5hbWU9JyxmdWxsbmFtZSk7XG4gICAgaWYgKHVzZXIgJiYgdXNlci5faWQgJiYgZnVsbG5hbWUgIT09ICcnKSB7XG4gICAgICBsb2dfaW5mbygnU3luY2luZyB1c2VyIGZ1bGxuYW1lOicsIGZ1bGxuYW1lKTtcbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6ICB1c2VyLl9pZCB9LCB7ICRzZXQ6IHsgJ3Byb2ZpbGUuZnVsbG5hbWUnIDogZnVsbG5hbWUsIH19KTtcbiAgICB9XG4gIH1cblxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkTGRhcFVzZXIobGRhcFVzZXIsIHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICBjb25zdCB1bmlxdWVJZCA9IGdldExkYXBVc2VyVW5pcXVlSUQobGRhcFVzZXIpO1xuXG4gIGNvbnN0IHVzZXJPYmplY3QgPSB7XG4gIH07XG5cbiAgaWYgKHVzZXJuYW1lKSB7XG4gICAgdXNlck9iamVjdC51c2VybmFtZSA9IHVzZXJuYW1lO1xuICB9XG5cbiAgY29uc3QgdXNlckRhdGEgPSBnZXREYXRhVG9TeW5jVXNlckRhdGEobGRhcFVzZXIsIHt9KTtcblxuICBpZiAodXNlckRhdGEgJiYgdXNlckRhdGEuZW1haWxzICYmIHVzZXJEYXRhLmVtYWlsc1swXSAmJiB1c2VyRGF0YS5lbWFpbHNbMF0uYWRkcmVzcykge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHVzZXJEYXRhLmVtYWlsc1swXS5hZGRyZXNzKSkge1xuICAgICAgdXNlck9iamVjdC5lbWFpbCA9IHVzZXJEYXRhLmVtYWlsc1swXS5hZGRyZXNzWzBdO1xuICAgIH0gZWxzZSB7XG4gICAgICB1c2VyT2JqZWN0LmVtYWlsID0gdXNlckRhdGEuZW1haWxzWzBdLmFkZHJlc3M7XG4gICAgfVxuICB9IGVsc2UgaWYgKGxkYXBVc2VyLm1haWwgJiYgbGRhcFVzZXIubWFpbC5pbmRleE9mKCdAJykgPiAtMSkge1xuICAgIHVzZXJPYmplY3QuZW1haWwgPSBsZGFwVXNlci5tYWlsO1xuICB9IGVsc2UgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0RFRkFVTFRfRE9NQUlOJykgIT09ICcnKSB7XG4gICAgdXNlck9iamVjdC5lbWFpbCA9IGAkeyB1c2VybmFtZSB8fCB1bmlxdWVJZC52YWx1ZSB9QCR7IExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0RFRkFVTFRfRE9NQUlOJykgfWA7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgZXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKCdMREFQLWxvZ2luLWVycm9yJywgJ0xEQVAgQXV0aGVudGljYXRpb24gc3VjY2VkZWQsIHRoZXJlIGlzIG5vIGVtYWlsIHRvIGNyZWF0ZSBhbiBhY2NvdW50LiBIYXZlIHlvdSB0cmllZCBzZXR0aW5nIHlvdXIgRGVmYXVsdCBEb21haW4gaW4gTERBUCBTZXR0aW5ncz8nKTtcbiAgICBsb2dfZXJyb3IoZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG5cbiAgbG9nX2RlYnVnKCdOZXcgdXNlciBkYXRhJywgdXNlck9iamVjdCk7XG5cbiAgaWYgKHBhc3N3b3JkKSB7XG4gICAgdXNlck9iamVjdC5wYXNzd29yZCA9IHBhc3N3b3JkO1xuICB9XG5cbiAgdHJ5IHtcbiAgICAvLyBUaGlzIGNyZWF0ZXMgdGhlIGFjY291bnQgd2l0aCBwYXNzd29yZCBzZXJ2aWNlXG4gICAgdXNlck9iamVjdC5sZGFwID0gdHJ1ZTtcbiAgICB1c2VyT2JqZWN0Ll9pZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIodXNlck9iamVjdCk7XG5cbiAgICAvLyBBZGQgdGhlIHNlcnZpY2VzLmxkYXAgaWRlbnRpZmllcnNcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiAgdXNlck9iamVjdC5faWQgfSwge1xuXHRcdCAgICAkc2V0OiB7XG5cdFx0ICAgICAgICAnc2VydmljZXMubGRhcCc6IHsgaWQ6IHVuaXF1ZUlkLnZhbHVlIH0sXG5cdFx0ICAgICAgICAnZW1haWxzLjAudmVyaWZpZWQnOiB0cnVlLFxuXHRcdCAgICAgICAgJ2F1dGhlbnRpY2F0aW9uTWV0aG9kJzogJ2xkYXAnLFxuXHRcdCAgICB9fSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nX2Vycm9yKCdFcnJvciBjcmVhdGluZyB1c2VyJywgZXJyb3IpO1xuICAgIHJldHVybiBlcnJvcjtcbiAgfVxuXG4gIHN5bmNVc2VyRGF0YSh1c2VyT2JqZWN0LCBsZGFwVXNlcik7XG5cbiAgcmV0dXJuIHtcbiAgICB1c2VySWQ6IHVzZXJPYmplY3QuX2lkLFxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0TmV3VXNlcnMobGRhcCkge1xuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU5BQkxFJykgIT09IHRydWUpIHtcbiAgICBsb2dfZXJyb3IoJ0NhblxcJ3QgcnVuIExEQVAgSW1wb3J0LCBMREFQIGlzIGRpc2FibGVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKCFsZGFwKSB7XG4gICAgbGRhcCA9IG5ldyBMREFQKCk7XG4gICAgbGRhcC5jb25uZWN0U3luYygpO1xuICB9XG5cbiAgbGV0IGNvdW50ID0gMDtcbiAgbGRhcC5zZWFyY2hVc2Vyc1N5bmMoJyonLCBNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnJvciwgbGRhcFVzZXJzLCB7bmV4dCwgZW5kfSA9IHt9KSA9PiB7XG4gICAgaWYgKGVycm9yKSB7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG5cbiAgICBsZGFwVXNlcnMuZm9yRWFjaCgobGRhcFVzZXIpID0+IHtcbiAgICAgIGNvdW50Kys7XG5cbiAgICAgIGNvbnN0IHVuaXF1ZUlkID0gZ2V0TGRhcFVzZXJVbmlxdWVJRChsZGFwVXNlcik7XG4gICAgICAvLyBMb29rIHRvIHNlZSBpZiB1c2VyIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCB1c2VyUXVlcnkgPSB7XG4gICAgICAgICdzZXJ2aWNlcy5sZGFwLmlkJzogdW5pcXVlSWQudmFsdWUsXG4gICAgICB9O1xuXG4gICAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeScsIHVzZXJRdWVyeSk7XG5cbiAgICAgIGxldCB1c2VybmFtZTtcbiAgICAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9VU0VSTkFNRV9GSUVMRCcpICE9PSAnJykge1xuICAgICAgICB1c2VybmFtZSA9IHNsdWcoZ2V0TGRhcFVzZXJuYW1lKGxkYXBVc2VyKSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFkZCB1c2VyIGlmIGl0IHdhcyBub3QgYWRkZWQgYmVmb3JlXG4gICAgICBsZXQgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJRdWVyeSk7XG5cbiAgICAgIGlmICghdXNlciAmJiB1c2VybmFtZSAmJiBMREFQLnNldHRpbmdzX2dldCgnTERBUF9NRVJHRV9FWElTVElOR19VU0VSUycpID09PSB0cnVlKSB7XG4gICAgICAgIGNvbnN0IHVzZXJRdWVyeSA9IHtcbiAgICAgICAgICB1c2VybmFtZSxcbiAgICAgICAgfTtcblxuICAgICAgICBsb2dfZGVidWcoJ3VzZXJRdWVyeSBtZXJnZScsIHVzZXJRdWVyeSk7XG5cbiAgICAgICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHVzZXJRdWVyeSk7XG4gICAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgICAgc3luY1VzZXJEYXRhKHVzZXIsIGxkYXBVc2VyKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgYWRkTGRhcFVzZXIobGRhcFVzZXIsIHVzZXJuYW1lKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNvdW50ICUgMTAwID09PSAwKSB7XG4gICAgICAgIGxvZ19pbmZvKCdJbXBvcnQgcnVubmluZy4gVXNlcnMgaW1wb3J0ZWQgdW50aWwgbm93OicsIGNvdW50KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmIChlbmQpIHtcbiAgICAgIGxvZ19pbmZvKCdJbXBvcnQgZmluaXNoZWQuIFVzZXJzIGltcG9ydGVkOicsIGNvdW50KTtcbiAgICB9XG5cbiAgICBuZXh0KGNvdW50KTtcbiAgfSkpO1xufVxuXG5mdW5jdGlvbiBzeW5jKCkge1xuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfRU5BQkxFJykgIT09IHRydWUpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBsZGFwID0gbmV3IExEQVAoKTtcblxuICB0cnkge1xuICAgIGxkYXAuY29ubmVjdFN5bmMoKTtcblxuICAgIGxldCB1c2VycztcbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0tFRVBfRVhJU1RBTlRfVVNFUlNfVVBEQVRFRCcpID09PSB0cnVlKSB7XG4gICAgICB1c2VycyA9IE1ldGVvci51c2Vycy5maW5kKHsgJ3NlcnZpY2VzLmxkYXAnOiB7ICRleGlzdHM6IHRydWUgfX0pO1xuICAgIH1cblxuICAgIGlmIChMREFQLnNldHRpbmdzX2dldCgnTERBUF9CQUNLR1JPVU5EX1NZTkNfSU1QT1JUX05FV19VU0VSUycpID09PSB0cnVlKSB7XG4gICAgICBpbXBvcnROZXdVc2VycyhsZGFwKTtcbiAgICB9XG5cbiAgICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0tFRVBfRVhJU1RBTlRfVVNFUlNfVVBEQVRFRCcpID09PSB0cnVlKSB7XG4gICAgICB1c2Vycy5mb3JFYWNoKGZ1bmN0aW9uKHVzZXIpIHtcbiAgICAgICAgbGV0IGxkYXBVc2VyO1xuXG4gICAgICAgIGlmICh1c2VyLnNlcnZpY2VzICYmIHVzZXIuc2VydmljZXMubGRhcCAmJiB1c2VyLnNlcnZpY2VzLmxkYXAuaWQpIHtcbiAgICAgICAgICBsZGFwVXNlciA9IGxkYXAuZ2V0VXNlckJ5SWRTeW5jKHVzZXIuc2VydmljZXMubGRhcC5pZCwgdXNlci5zZXJ2aWNlcy5sZGFwLmlkQXR0cmlidXRlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsZGFwVXNlciA9IGxkYXAuZ2V0VXNlckJ5VXNlcm5hbWVTeW5jKHVzZXIudXNlcm5hbWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGxkYXBVc2VyKSB7XG4gICAgICAgICAgc3luY1VzZXJEYXRhKHVzZXIsIGxkYXBVc2VyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsb2dfaW5mbygnQ2FuXFwndCBzeW5jIHVzZXInLCB1c2VyLnVzZXJuYW1lKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGxvZ19lcnJvcihlcnJvcik7XG4gICAgcmV0dXJuIGVycm9yO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG5jb25zdCBqb2JOYW1lID0gJ0xEQVBfU3luYyc7XG5cbmNvbnN0IGFkZENyb25Kb2IgPSBfLmRlYm91bmNlKE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24gYWRkQ3JvbkpvYkRlYm91bmNlZCgpIHtcbiAgaWYgKExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0JBQ0tHUk9VTkRfU1lOQycpICE9PSB0cnVlKSB7XG4gICAgbG9nX2luZm8oJ0Rpc2FibGluZyBMREFQIEJhY2tncm91bmQgU3luYycpO1xuICAgIGlmIChTeW5jZWRDcm9uLm5leHRTY2hlZHVsZWRBdERhdGUoam9iTmFtZSkpIHtcbiAgICAgIFN5bmNlZENyb24ucmVtb3ZlKGpvYk5hbWUpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0lOVEVSVkFMJykpIHtcbiAgICBsb2dfaW5mbygnRW5hYmxpbmcgTERBUCBCYWNrZ3JvdW5kIFN5bmMnKTtcbiAgICBTeW5jZWRDcm9uLmFkZCh7XG4gICAgICBuYW1lOiBqb2JOYW1lLFxuICAgICAgc2NoZWR1bGU6IChwYXJzZXIpID0+IHBhcnNlci50ZXh0KExEQVAuc2V0dGluZ3NfZ2V0KCdMREFQX0JBQ0tHUk9VTkRfU1lOQ19JTlRFUlZBTCcpKSxcbiAgICAgIGpvYigpIHtcbiAgICAgICAgc3luYygpO1xuICAgICAgfSxcbiAgICB9KTtcbiAgICBTeW5jZWRDcm9uLnN0YXJ0KCk7XG4gIH1cbn0pLCA1MDApO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIE1ldGVvci5kZWZlcigoKSA9PiB7XG4gICAgTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DJywgYWRkQ3JvbkpvYik7XG4gICAgTERBUC5zZXR0aW5nc19nZXQoJ0xEQVBfQkFDS0dST1VORF9TWU5DX0lOVEVSVkFMJywgYWRkQ3JvbkpvYik7XG4gIH0pO1xufSk7XG4iXX0=
