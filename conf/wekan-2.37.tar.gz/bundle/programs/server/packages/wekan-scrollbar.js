(function () {

/* Package-scope variables */
var dx;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['wekan-scrollbar'] = {};

})();
