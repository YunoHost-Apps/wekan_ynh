(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var ActiveRoute = Package['zimme:active-route'].ActiveRoute;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, FlowRouterHelpers;

(function(){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// packages/arillo_flow-router-helpers/client/helpers.coffee                         //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var currentRouteName,
    currentRouteOption,
    func,
    helpers,
    isSubReady,
    name,
    param,
    pathFor,
    queryParam,
    subsReady,
    urlFor,
    slice = [].slice,
    hasProp = {}.hasOwnProperty;

subsReady = function () {
  var subs;
  subs = 1 <= arguments.length ? slice.call(arguments, 0) : [];

  if (subs.length === 1) {
    return FlowRouter.subsReady();
  }

  subs = subs.slice(0, subs.length - 1);
  return _.reduce(subs, function (memo, sub) {
    return memo && FlowRouter.subsReady(sub);
  }, true);
};

pathFor = function (path, view) {
  var hashBang, query, ref;

  if (view == null) {
    view = {
      hash: {}
    };
  }

  if (!path) {
    throw new Error('no path defined');
  }

  if (!view.hash) {
    view = {
      hash: view
    };
  }

  if (((ref = path.hash) != null ? ref.route : void 0) != null) {
    view = path;
    path = view.hash.route;
    delete view.hash.route;
  }

  query = view.hash.query ? FlowRouter._qs.parse(view.hash.query) : {};
  hashBang = view.hash.hash ? view.hash.hash : '';
  return FlowRouter.path(path, view.hash, query) + (hashBang ? "#" + hashBang : '');
};

urlFor = function (path, view) {
  var relativePath;
  relativePath = pathFor(path, view);
  return Meteor.absoluteUrl(relativePath.substr(1));
};

param = function (name) {
  return FlowRouter.getParam(name);
};

queryParam = function (key) {
  return FlowRouter.getQueryParam(key);
};

currentRouteName = function () {
  return FlowRouter.getRouteName();
};

currentRouteOption = function (optionName) {
  return FlowRouter.current().route.options[optionName];
};

isSubReady = function (sub) {
  if (sub) {
    return FlowRouter.subsReady(sub);
  }

  return FlowRouter.subsReady();
};

helpers = {
  subsReady: subsReady,
  pathFor: pathFor,
  urlFor: urlFor,
  param: param,
  queryParam: queryParam,
  currentRouteName: currentRouteName,
  isSubReady: isSubReady,
  currentRouteOption: currentRouteOption
};

if (Meteor.isClient) {
  for (name in meteorBabelHelpers.sanitizeForInObject(helpers)) {
    if (!hasProp.call(helpers, name)) continue;
    func = helpers[name];
    Template.registerHelper(name, func);
  }
}

if (Meteor.isServer) {
  FlowRouterHelpers = {
    pathFor: pathFor,
    urlFor: urlFor
  };
}
///////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['arillo:flow-router-helpers'] = {}, {
  FlowRouterHelpers: FlowRouterHelpers
});

})();

//# sourceURL=meteor://💻app/packages/arillo_flow-router-helpers.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYXJpbGxvX2Zsb3ctcm91dGVyLWhlbHBlcnMvY2xpZW50L2hlbHBlcnMuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9jbGllbnQvaGVscGVycy5jb2ZmZWUiXSwibmFtZXMiOlsiY3VycmVudFJvdXRlTmFtZSIsImN1cnJlbnRSb3V0ZU9wdGlvbiIsImZ1bmMiLCJoZWxwZXJzIiwiaXNTdWJSZWFkeSIsIm5hbWUiLCJwYXJhbSIsInBhdGhGb3IiLCJxdWVyeVBhcmFtIiwic3Vic1JlYWR5IiwidXJsRm9yIiwic2xpY2UiLCJoYXNQcm9wIiwiaGFzT3duUHJvcGVydHkiLCJzdWJzIiwiYXJndW1lbnRzIiwibGVuZ3RoIiwiY2FsbCIsIkZsb3dSb3V0ZXIiLCJfIiwicmVkdWNlIiwibWVtbyIsInN1YiIsInBhdGgiLCJ2aWV3IiwiaGFzaEJhbmciLCJxdWVyeSIsInJlZiIsImhhc2giLCJFcnJvciIsInJvdXRlIiwiX3FzIiwicGFyc2UiLCJyZWxhdGl2ZVBhdGgiLCJNZXRlb3IiLCJhYnNvbHV0ZVVybCIsInN1YnN0ciIsImdldFBhcmFtIiwia2V5IiwiZ2V0UXVlcnlQYXJhbSIsImdldFJvdXRlTmFtZSIsIm9wdGlvbk5hbWUiLCJjdXJyZW50Iiwib3B0aW9ucyIsImlzQ2xpZW50IiwiVGVtcGxhdGUiLCJyZWdpc3RlckhlbHBlciIsImlzU2VydmVyIiwiRmxvd1JvdXRlckhlbHBlcnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFBQSxnQkFBQTtBQUFBLElBQUFDLGtCQUFBO0FBQUEsSUFBQUMsSUFBQTtBQUFBLElBQUFDLE9BQUE7QUFBQSxJQUFBQyxVQUFBO0FBQUEsSUFBQUMsSUFBQTtBQUFBLElBQUFDLEtBQUE7QUFBQSxJQUFBQyxPQUFBO0FBQUEsSUFBQUMsVUFBQTtBQUFBLElBQUFDLFNBQUE7QUFBQSxJQUFBQyxNQUFBO0FBQUEsSUFBQUMsUUFBQSxHQUFBQSxLQUFBO0FBQUEsSUNDRUMsVUFBVSxHQUFHQyxjRERmOztBQUFBSixZQUFZO0FBQ1YsTUFBQUssSUFBQTtBQURXQSxTQUFBLEtBQUFDLFVBQUFDLE1BQUEsR0FBQUwsTUFBQU0sSUFBQSxDQUFBRixTQUFBOztBQUNYLE1BQWlDRCxLQUFLRSxNQUFMLEtBQWUsQ0FBaEQ7QUFBQSxXQUFPRSxXQUFXVCxTQUFYLEVBQVA7QUNPQzs7QUROREssU0FBT0EsS0FBS0gsS0FBTCxDQUFXLENBQVgsRUFBY0csS0FBS0UsTUFBTCxHQUFjLENBQTVCLENBQVA7QUNRQSxTRFBBRyxFQUFFQyxNQUFGLENBQVNOLElBQVQsRUFBZSxVQUFDTyxJQUFELEVBQU9DLEdBQVA7QUNRYixXRFBBRCxRQUFTSCxXQUFXVCxTQUFYLENBQXFCYSxHQUFyQixDQ09UO0FEUkYsS0FFRSxJQUZGLENDT0E7QURWVSxDQUFaOztBQVFBZixVQUFVLFVBQUNnQixJQUFELEVBQU9DLElBQVA7QUFDUixNQUFBQyxRQUFBLEVBQUFDLEtBQUEsRUFBQUMsR0FBQTs7QUNRQSxNQUFJSCxRQUFRLElBQVosRUFBa0I7QURUSEEsV0FBTztBQUFDSSxZQUFLO0FBQU4sS0FBUDtBQ2FkOztBRFpELE9BQTBDTCxJQUExQztBQUFBLFVBQU0sSUFBSU0sS0FBSixDQUFVLGlCQUFWLENBQU47QUNlQzs7QURiRCxPQUF5QkwsS0FBS0ksSUFBOUI7QUFBQUosV0FBTztBQUFBSSxZQUFNSjtBQUFOLEtBQVA7QUNrQkM7O0FEakJELE1BQUcsRUFBQUcsTUFBQUosS0FBQUssSUFBQSxZQUFBRCxJQUFBRyxLQUFBLGtCQUFIO0FBQ0VOLFdBQU9ELElBQVA7QUFDQUEsV0FBT0MsS0FBS0ksSUFBTCxDQUFVRSxLQUFqQjtBQUNBLFdBQU9OLEtBQUtJLElBQUwsQ0FBVUUsS0FBakI7QUNtQkQ7O0FEbEJESixVQUFXRixLQUFLSSxJQUFMLENBQVVGLEtBQVYsR0FBcUJSLFdBQVdhLEdBQVgsQ0FBZUMsS0FBZixDQUFxQlIsS0FBS0ksSUFBTCxDQUFVRixLQUEvQixDQUFyQixHQUFnRSxFQUEzRTtBQUNBRCxhQUFjRCxLQUFLSSxJQUFMLENBQVVBLElBQVYsR0FBb0JKLEtBQUtJLElBQUwsQ0FBVUEsSUFBOUIsR0FBd0MsRUFBdEQ7QUNvQkEsU0RuQkFWLFdBQVdLLElBQVgsQ0FBZ0JBLElBQWhCLEVBQXNCQyxLQUFLSSxJQUEzQixFQUFpQ0YsS0FBakMsS0FBOENELFdBQWMsTUFBSUEsUUFBbEIsR0FBa0MsRUFBaEYsQ0NtQkE7QUQ3QlEsQ0FBVjs7QUFhQWYsU0FBUyxVQUFDYSxJQUFELEVBQU9DLElBQVA7QUFDUCxNQUFBUyxZQUFBO0FBQUFBLGlCQUFlMUIsUUFBUWdCLElBQVIsRUFBY0MsSUFBZCxDQUFmO0FDcUJBLFNEcEJBVSxPQUFPQyxXQUFQLENBQW1CRixhQUFhRyxNQUFiLENBQW9CLENBQXBCLENBQW5CLENDb0JBO0FEdEJPLENBQVQ7O0FBS0E5QixRQUFRLFVBQUNELElBQUQ7QUNxQk4sU0RwQkFhLFdBQVdtQixRQUFYLENBQW9CaEMsSUFBcEIsQ0NvQkE7QURyQk0sQ0FBUjs7QUFJQUcsYUFBYSxVQUFDOEIsR0FBRDtBQ3FCWCxTRHBCQXBCLFdBQVdxQixhQUFYLENBQXlCRCxHQUF6QixDQ29CQTtBRHJCVyxDQUFiOztBQUlBdEMsbUJBQW1CO0FDcUJqQixTRHBCQWtCLFdBQVdzQixZQUFYLEVDb0JBO0FEckJpQixDQUFuQjs7QUFJQXZDLHFCQUFxQixVQUFDd0MsVUFBRDtBQ3FCbkIsU0RwQkF2QixXQUFXd0IsT0FBWCxHQUFxQlosS0FBckIsQ0FBMkJhLE9BQTNCLENBQW1DRixVQUFuQyxDQ29CQTtBRHJCbUIsQ0FBckI7O0FBSUFyQyxhQUFhLFVBQUNrQixHQUFEO0FBQ1gsTUFBb0NBLEdBQXBDO0FBQUEsV0FBT0osV0FBV1QsU0FBWCxDQUFxQmEsR0FBckIsQ0FBUDtBQ3NCQzs7QURyQkQsU0FBT0osV0FBV1QsU0FBWCxFQUFQO0FBRlcsQ0FBYjs7QUFJQU4sVUFDRTtBQUFBTSxhQUFXQSxTQUFYO0FBQ0FGLFdBQVNBLE9BRFQ7QUFFQUcsVUFBUUEsTUFGUjtBQUdBSixTQUFPQSxLQUhQO0FBSUFFLGNBQVlBLFVBSlo7QUFLQVIsb0JBQWtCQSxnQkFMbEI7QUFNQUksY0FBWUEsVUFOWjtBQU9BSCxzQkFBb0JBO0FBUHBCLENBREY7O0FBVUEsSUFBR2lDLE9BQU9VLFFBQVY7QUFDRSxPQUFBdkMsSUFBQSwyQ0FBQUYsT0FBQTtBQ3lCRSxRQUFJLENBQUNTLFFBQVFLLElBQVIsQ0FBYWQsT0FBYixFQUFzQkUsSUFBdEIsQ0FBTCxFQUFrQztBQUNsQ0gsV0FBT0MsUUFBUUUsSUFBUixDQUFQO0FEMUJGd0MsYUFBU0MsY0FBVCxDQUF3QnpDLElBQXhCLEVBQThCSCxJQUE5QjtBQURGO0FDOEJDOztBRDNCRCxJQUFHZ0MsT0FBT2EsUUFBVjtBQUNFQyxzQkFDRTtBQUFBekMsYUFBU0EsT0FBVDtBQUNBRyxZQUFRQTtBQURSLEdBREY7QUNpQ0QsQyIsImZpbGUiOiIvcGFja2FnZXMvYXJpbGxvX2Zsb3ctcm91dGVyLWhlbHBlcnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyIjIGNoZWNrIGZvciBzdWJzY3JpcHRpb25zIHRvIGJlIHJlYWR5XG5zdWJzUmVhZHkgPSAoc3Vicy4uLikgLT5cbiAgcmV0dXJuIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KCkgaWYgc3Vicy5sZW5ndGggaXMgMVxuICBzdWJzID0gc3Vicy5zbGljZSgwLCBzdWJzLmxlbmd0aCAtIDEpXG4gIF8ucmVkdWNlIHN1YnMsIChtZW1vLCBzdWIpIC0+XG4gICAgbWVtbyBhbmQgRmxvd1JvdXRlci5zdWJzUmVhZHkoc3ViKVxuICAsIHRydWVcblxuIyByZXR1cm4gcGF0aFxucGF0aEZvciA9IChwYXRoLCB2aWV3ID0ge2hhc2g6e319KSAtPlxuICB0aHJvdyBuZXcgRXJyb3IoJ25vIHBhdGggZGVmaW5lZCcpIHVubGVzcyBwYXRoXG4gICMgc2V0IGlmIHJ1biBvbiBzZXJ2ZXJcbiAgdmlldyA9IGhhc2g6IHZpZXcgdW5sZXNzIHZpZXcuaGFzaFxuICBpZiBwYXRoLmhhc2g/LnJvdXRlP1xuICAgIHZpZXcgPSBwYXRoXG4gICAgcGF0aCA9IHZpZXcuaGFzaC5yb3V0ZVxuICAgIGRlbGV0ZSB2aWV3Lmhhc2gucm91dGVcbiAgcXVlcnkgPSBpZiB2aWV3Lmhhc2gucXVlcnkgdGhlbiBGbG93Um91dGVyLl9xcy5wYXJzZSh2aWV3Lmhhc2gucXVlcnkpIGVsc2Uge31cbiAgaGFzaEJhbmcgPSBpZiB2aWV3Lmhhc2guaGFzaCB0aGVuIHZpZXcuaGFzaC5oYXNoIGVsc2UgJydcbiAgRmxvd1JvdXRlci5wYXRoKHBhdGgsIHZpZXcuaGFzaCwgcXVlcnkpICsgKGlmIGhhc2hCYW5nIHRoZW4gXCIjI3toYXNoQmFuZ31cIiBlbHNlICcnKVxuXG4jIHJldHVybiBhYnNvbHV0ZSB1cmxcbnVybEZvciA9IChwYXRoLCB2aWV3KSAtPlxuICByZWxhdGl2ZVBhdGggPSBwYXRoRm9yKHBhdGgsIHZpZXcpXG4gIE1ldGVvci5hYnNvbHV0ZVVybChyZWxhdGl2ZVBhdGguc3Vic3RyKDEpKVxuXG4jIGdldCBwYXJhbWV0ZXJcbnBhcmFtID0gKG5hbWUpIC0+XG4gIEZsb3dSb3V0ZXIuZ2V0UGFyYW0obmFtZSk7XG5cbiMgZ2V0IHF1ZXJ5IHBhcmFtZXRlclxucXVlcnlQYXJhbSA9IChrZXkpIC0+XG4gIEZsb3dSb3V0ZXIuZ2V0UXVlcnlQYXJhbShrZXkpO1xuXG4jIGdldCBjdXJyZW50IHJvdXRlIG5hbWVcbmN1cnJlbnRSb3V0ZU5hbWUgPSAoKSAtPlxuICBGbG93Um91dGVyLmdldFJvdXRlTmFtZSgpXG5cbiMgZ2V0IGN1cnJlbnQgcm91dGUgb3B0aW9uc1xuY3VycmVudFJvdXRlT3B0aW9uID0gKG9wdGlvbk5hbWUpIC0+XG4gIEZsb3dSb3V0ZXIuY3VycmVudCgpLnJvdXRlLm9wdGlvbnNbb3B0aW9uTmFtZV1cblxuIyBkZXByZWNhdGVkXG5pc1N1YlJlYWR5ID0gKHN1YikgLT5cbiAgcmV0dXJuIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KHN1YikgaWYgc3ViXG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeSgpXG5cbmhlbHBlcnMgPVxuICBzdWJzUmVhZHk6IHN1YnNSZWFkeVxuICBwYXRoRm9yOiBwYXRoRm9yXG4gIHVybEZvcjogdXJsRm9yXG4gIHBhcmFtOiBwYXJhbVxuICBxdWVyeVBhcmFtOiBxdWVyeVBhcmFtXG4gIGN1cnJlbnRSb3V0ZU5hbWU6IGN1cnJlbnRSb3V0ZU5hbWVcbiAgaXNTdWJSZWFkeTogaXNTdWJSZWFkeVxuICBjdXJyZW50Um91dGVPcHRpb246IGN1cnJlbnRSb3V0ZU9wdGlvblxuXG5pZiBNZXRlb3IuaXNDbGllbnRcbiAgVGVtcGxhdGUucmVnaXN0ZXJIZWxwZXIgbmFtZSwgZnVuYyBmb3Igb3duIG5hbWUsIGZ1bmMgb2YgaGVscGVyc1xuICBcbmlmIE1ldGVvci5pc1NlcnZlclxuICBGbG93Um91dGVySGVscGVycyA9IFxuICAgIHBhdGhGb3I6IHBhdGhGb3JcbiAgICB1cmxGb3I6IHVybEZvclxuIiwidmFyIGN1cnJlbnRSb3V0ZU5hbWUsIGN1cnJlbnRSb3V0ZU9wdGlvbiwgZnVuYywgaGVscGVycywgaXNTdWJSZWFkeSwgbmFtZSwgcGFyYW0sIHBhdGhGb3IsIHF1ZXJ5UGFyYW0sIHN1YnNSZWFkeSwgdXJsRm9yLCAgICAgICAgICAgICAgICAgICBcbiAgc2xpY2UgPSBbXS5zbGljZSxcbiAgaGFzUHJvcCA9IHt9Lmhhc093blByb3BlcnR5O1xuXG5zdWJzUmVhZHkgPSBmdW5jdGlvbigpIHtcbiAgdmFyIHN1YnM7XG4gIHN1YnMgPSAxIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMCkgOiBbXTtcbiAgaWYgKHN1YnMubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KCk7XG4gIH1cbiAgc3VicyA9IHN1YnMuc2xpY2UoMCwgc3Vicy5sZW5ndGggLSAxKTtcbiAgcmV0dXJuIF8ucmVkdWNlKHN1YnMsIGZ1bmN0aW9uKG1lbW8sIHN1Yikge1xuICAgIHJldHVybiBtZW1vICYmIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KHN1Yik7XG4gIH0sIHRydWUpO1xufTtcblxucGF0aEZvciA9IGZ1bmN0aW9uKHBhdGgsIHZpZXcpIHtcbiAgdmFyIGhhc2hCYW5nLCBxdWVyeSwgcmVmO1xuICBpZiAodmlldyA9PSBudWxsKSB7XG4gICAgdmlldyA9IHtcbiAgICAgIGhhc2g6IHt9XG4gICAgfTtcbiAgfVxuICBpZiAoIXBhdGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ25vIHBhdGggZGVmaW5lZCcpO1xuICB9XG4gIGlmICghdmlldy5oYXNoKSB7XG4gICAgdmlldyA9IHtcbiAgICAgIGhhc2g6IHZpZXdcbiAgICB9O1xuICB9XG4gIGlmICgoKHJlZiA9IHBhdGguaGFzaCkgIT0gbnVsbCA/IHJlZi5yb3V0ZSA6IHZvaWQgMCkgIT0gbnVsbCkge1xuICAgIHZpZXcgPSBwYXRoO1xuICAgIHBhdGggPSB2aWV3Lmhhc2gucm91dGU7XG4gICAgZGVsZXRlIHZpZXcuaGFzaC5yb3V0ZTtcbiAgfVxuICBxdWVyeSA9IHZpZXcuaGFzaC5xdWVyeSA/IEZsb3dSb3V0ZXIuX3FzLnBhcnNlKHZpZXcuaGFzaC5xdWVyeSkgOiB7fTtcbiAgaGFzaEJhbmcgPSB2aWV3Lmhhc2guaGFzaCA/IHZpZXcuaGFzaC5oYXNoIDogJyc7XG4gIHJldHVybiBGbG93Um91dGVyLnBhdGgocGF0aCwgdmlldy5oYXNoLCBxdWVyeSkgKyAoaGFzaEJhbmcgPyBcIiNcIiArIGhhc2hCYW5nIDogJycpO1xufTtcblxudXJsRm9yID0gZnVuY3Rpb24ocGF0aCwgdmlldykge1xuICB2YXIgcmVsYXRpdmVQYXRoO1xuICByZWxhdGl2ZVBhdGggPSBwYXRoRm9yKHBhdGgsIHZpZXcpO1xuICByZXR1cm4gTWV0ZW9yLmFic29sdXRlVXJsKHJlbGF0aXZlUGF0aC5zdWJzdHIoMSkpO1xufTtcblxucGFyYW0gPSBmdW5jdGlvbihuYW1lKSB7XG4gIHJldHVybiBGbG93Um91dGVyLmdldFBhcmFtKG5hbWUpO1xufTtcblxucXVlcnlQYXJhbSA9IGZ1bmN0aW9uKGtleSkge1xuICByZXR1cm4gRmxvd1JvdXRlci5nZXRRdWVyeVBhcmFtKGtleSk7XG59O1xuXG5jdXJyZW50Um91dGVOYW1lID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiBGbG93Um91dGVyLmdldFJvdXRlTmFtZSgpO1xufTtcblxuY3VycmVudFJvdXRlT3B0aW9uID0gZnVuY3Rpb24ob3B0aW9uTmFtZSkge1xuICByZXR1cm4gRmxvd1JvdXRlci5jdXJyZW50KCkucm91dGUub3B0aW9uc1tvcHRpb25OYW1lXTtcbn07XG5cbmlzU3ViUmVhZHkgPSBmdW5jdGlvbihzdWIpIHtcbiAgaWYgKHN1Yikge1xuICAgIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeShzdWIpO1xuICB9XG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeSgpO1xufTtcblxuaGVscGVycyA9IHtcbiAgc3Vic1JlYWR5OiBzdWJzUmVhZHksXG4gIHBhdGhGb3I6IHBhdGhGb3IsXG4gIHVybEZvcjogdXJsRm9yLFxuICBwYXJhbTogcGFyYW0sXG4gIHF1ZXJ5UGFyYW06IHF1ZXJ5UGFyYW0sXG4gIGN1cnJlbnRSb3V0ZU5hbWU6IGN1cnJlbnRSb3V0ZU5hbWUsXG4gIGlzU3ViUmVhZHk6IGlzU3ViUmVhZHksXG4gIGN1cnJlbnRSb3V0ZU9wdGlvbjogY3VycmVudFJvdXRlT3B0aW9uXG59O1xuXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gIGZvciAobmFtZSBpbiBoZWxwZXJzKSB7XG4gICAgaWYgKCFoYXNQcm9wLmNhbGwoaGVscGVycywgbmFtZSkpIGNvbnRpbnVlO1xuICAgIGZ1bmMgPSBoZWxwZXJzW25hbWVdO1xuICAgIFRlbXBsYXRlLnJlZ2lzdGVySGVscGVyKG5hbWUsIGZ1bmMpO1xuICB9XG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgRmxvd1JvdXRlckhlbHBlcnMgPSB7XG4gICAgcGF0aEZvcjogcGF0aEZvcixcbiAgICB1cmxGb3I6IHVybEZvclxuICB9O1xufVxuIl19
