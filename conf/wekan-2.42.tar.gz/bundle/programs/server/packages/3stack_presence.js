(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Accounts = Package['accounts-base'].Accounts;
var Random = Package.random.Random;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, presences, Presence;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/3stack_presence/lib/collection.coffee                                                       //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
presences = new Mongo.Collection('presences');
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/3stack_presence/lib/heartbeat.coffee                                                        //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Heartbeat,
    bind = function (fn, me) {
  return function () {
    return fn.apply(me, arguments);
  };
};

Heartbeat = function () {
  function Heartbeat(interval) {
    this.interval = interval;
    this.tock = bind(this.tock, this);
    this.tick = bind(this.tick, this);
    this.heartbeat = null;
    this.action = null;
    this.started = false;
  }

  Heartbeat.prototype.start = function (action) {
    this.action = action;

    if (this.started) {
      return;
    }

    this.started = true;

    this._enqueue();
  };

  Heartbeat.prototype.stop = function () {
    this.started = false;
    this.action = null;

    this._dequeue();
  };

  Heartbeat.prototype.tick = function () {
    if (typeof this.action === "function") {
      this.action();
    }
  };

  Heartbeat.prototype.tock = function () {
    if (!this.started) {
      return;
    }

    this._dequeue();

    this._enqueue();
  };

  Heartbeat.prototype._dequeue = function () {
    if (this.heartbeat != null) {
      Meteor.clearTimeout(this.heartbeat);
      this.heartbeat = null;
    }
  };

  Heartbeat.prototype._enqueue = function () {
    this.heartbeat = Meteor.setTimeout(this.tick, this.interval);
  };

  return Heartbeat;
}();

this.Heartbeat = Heartbeat;
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/3stack_presence/lib/server/monitor.coffee                                                   //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var DEFAULT_HEARTBEAT,
    DEFAULT_TTL,
    ServerMonitor,
    bind = function (fn, me) {
  return function () {
    return fn.apply(me, arguments);
  };
};

DEFAULT_TTL = 5 * 60 * 1000;
DEFAULT_HEARTBEAT = 60 * 1000;

ServerMonitor = function () {
  function ServerMonitor() {
    this.onBeat = bind(this.onBeat, this);
    this.onStartup = bind(this.onStartup, this);
    this.serverId = Random.id();
    console.log("Presence started serverId=" + this.serverId);
    this.options = {
      ttl: null,
      heartbeatInterval: null,
      checksum: null
    };
    this.heartbeat = new Heartbeat(DEFAULT_HEARTBEAT);
    this.started = false;
    Meteor.startup(this.onStartup);
  }

  ServerMonitor.prototype.configure = function (options) {
    var ref;

    if (this.started) {
      throw new Error("Must configure Presence on the server before Meteor.startup()");
    }

    _.extend(this.options, options);

    this.heartbeat.interval = (ref = this.options.heartbeatInterval) != null ? ref : DEFAULT_HEARTBEAT;
  };

  ServerMonitor.prototype.getTtl = function () {
    var ref;
    return new Date(+new Date() + ((ref = this.options.ttl) != null ? ref : DEFAULT_TTL));
  };

  ServerMonitor.prototype.onStartup = function () {
    this.started = true;
    this.heartbeat.start(this.onBeat);
  };

  ServerMonitor.prototype.onBeat = function () {
    try {
      presences.update({
        serverId: this.serverId
      }, {
        $set: {
          ttl: this.getTtl()
        }
      }, {
        multi: true
      });
    } finally {
      this.heartbeat.tock();
    }
  };

  ServerMonitor.prototype.checksum = function (userId, value) {
    if (this.options.checksum != null) {
      return this.options.checksum(userId, value);
    } else {
      return value;
    }
  };

  return ServerMonitor;
}();

this.ServerMonitor = ServerMonitor;
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/3stack_presence/lib/server/presence.coffee                                                  //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Presence = new ServerMonitor();
Meteor.onConnection(function (connection) {
  var now;
  connection.sessionKey = Random.id();
  now = new Date();
  presences.insert({
    _id: connection.sessionKey,
    serverId: Presence.serverId,
    ttl: Presence.getTtl(),
    clientAddress: connection.clientAddress,
    status: 'connected',
    connectedAt: now,
    lastSeen: now,
    state: {},
    userId: null
  });
  connection.onClose(function () {
    presences.remove({
      _id: connection.sessionKey
    });
  });
});
Meteor.publish(null, function () {
  var loginToken;
  loginToken = null;

  if (this.userId != null) {
    loginToken = Presence.checksum(this.userId, Accounts._getLoginToken(this.connection.id));
  }

  presences.update({
    _id: this.connection.sessionKey
  }, {
    $set: {
      loginToken: loginToken,
      userId: this.userId,
      lastSeen: new Date()
    }
  });
  this.ready();
});
Meteor.methods({
  'setPresence': function (state) {
    check(state, Match.Any);
    this.unblock();
    presences.update({
      _id: this.connection.sessionKey
    }, {
      $set: {
        userId: this.userId,
        lastSeen: new Date(),
        state: state,
        status: 'online'
      }
    });
    return null;
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['3stack:presence'] = {}, {
  Presence: Presence,
  presences: presences
});

})();

//# sourceURL=meteor://💻app/packages/3stack_presence.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9jb2xsZWN0aW9uLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9oZWFydGJlYXQuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvaGVhcnRiZWF0LmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvM3N0YWNrX3ByZXNlbmNlL2xpYi9zZXJ2ZXIvbW9uaXRvci5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zZXJ2ZXIvbW9uaXRvci5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzLzNzdGFja19wcmVzZW5jZS9saWIvc2VydmVyL3ByZXNlbmNlLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvbGliL3NlcnZlci9wcmVzZW5jZS5jb2ZmZWUiXSwibmFtZXMiOlsicHJlc2VuY2VzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiSGVhcnRiZWF0IiwiYmluZCIsImZuIiwibWUiLCJhcHBseSIsImFyZ3VtZW50cyIsImludGVydmFsIiwidG9jayIsInRpY2siLCJoZWFydGJlYXQiLCJhY3Rpb24iLCJzdGFydGVkIiwicHJvdG90eXBlIiwic3RhcnQiLCJfZW5xdWV1ZSIsInN0b3AiLCJfZGVxdWV1ZSIsIk1ldGVvciIsImNsZWFyVGltZW91dCIsInNldFRpbWVvdXQiLCJERUZBVUxUX0hFQVJUQkVBVCIsIkRFRkFVTFRfVFRMIiwiU2VydmVyTW9uaXRvciIsIm9uQmVhdCIsIm9uU3RhcnR1cCIsInNlcnZlcklkIiwiUmFuZG9tIiwiaWQiLCJjb25zb2xlIiwibG9nIiwib3B0aW9ucyIsInR0bCIsImhlYXJ0YmVhdEludGVydmFsIiwiY2hlY2tzdW0iLCJzdGFydHVwIiwiY29uZmlndXJlIiwicmVmIiwiRXJyb3IiLCJfIiwiZXh0ZW5kIiwiZ2V0VHRsIiwiRGF0ZSIsInVwZGF0ZSIsIiRzZXQiLCJtdWx0aSIsInVzZXJJZCIsInZhbHVlIiwiUHJlc2VuY2UiLCJvbkNvbm5lY3Rpb24iLCJjb25uZWN0aW9uIiwibm93Iiwic2Vzc2lvbktleSIsImluc2VydCIsIl9pZCIsImNsaWVudEFkZHJlc3MiLCJzdGF0dXMiLCJjb25uZWN0ZWRBdCIsImxhc3RTZWVuIiwic3RhdGUiLCJvbkNsb3NlIiwicmVtb3ZlIiwicHVibGlzaCIsImxvZ2luVG9rZW4iLCJBY2NvdW50cyIsIl9nZXRMb2dpblRva2VuIiwicmVhZHkiLCJtZXRob2RzIiwiY2hlY2siLCJNYXRjaCIsIkFueSIsInVuYmxvY2siXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxZQUFZLElBQUlDLE1BQU1DLFVBQVYsQ0FBcUIsV0FBckIsQ0FBWixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsSUFBQUMsU0FBQTtBQUFBLElBQUFDLE9BQUEsVUFBQUMsRUFBQSxFQUFBQyxFQUFBO0FBQUE7QUFBQSxXQUFBRCxHQUFBRSxLQUFBLENBQUFELEVBQUEsRUFBQUUsU0FBQTtBQUFBO0FBQUE7O0FBQU1MLFlBQUE7QUFDUyxXQUFBQSxTQUFBLENBQUNNLFFBQUQ7QUFBQyxTQUFDQSxRQUFELEdBQUFBLFFBQUE7QUNLWixTQUFLQyxJQUFMLEdBQVlOLEtBQUssS0FBS00sSUFBVixFQUFnQixJQUFoQixDQUFaO0FBQ0EsU0FBS0MsSUFBTCxHQUFZUCxLQUFLLEtBQUtPLElBQVYsRUFBZ0IsSUFBaEIsQ0FBWjtBRExBLFNBQUNDLFNBQUQsR0FBYSxJQUFiO0FBQ0EsU0FBQ0MsTUFBRCxHQUFVLElBQVY7QUFDQSxTQUFDQyxPQUFELEdBQVcsS0FBWDtBQUhXOztBQ1liWCxZQUFVWSxTQUFWLENEUEFDLEtDT0EsR0RQTyxVQUFDSCxNQUFEO0FBQUMsU0FBQ0EsTUFBRCxHQUFBQSxNQUFBOztBQUNOLFFBQUcsS0FBQ0MsT0FBSjtBQUNFO0FDU0Q7O0FEUkQsU0FBQ0EsT0FBRCxHQUFXLElBQVg7O0FBQ0EsU0FBQ0csUUFBRDtBQUpLLEdDT1A7O0FBU0FkLFlBQVVZLFNBQVYsQ0RUQUcsSUNTQSxHRFRNO0FBQ0osU0FBQ0osT0FBRCxHQUFXLEtBQVg7QUFDQSxTQUFDRCxNQUFELEdBQVUsSUFBVjs7QUFDQSxTQUFDTSxRQUFEO0FBSEksR0NTTjs7QUFNQWhCLFlBQVVZLFNBQVYsQ0RUQUosSUNTQSxHRFRNO0FDVUosUUFBSSxPQUFPLEtBQUtFLE1BQVosS0FBdUIsVUFBM0IsRUFBdUM7QURUdkMsV0FBQ0EsTUFBRDtBQ1dDO0FEWkcsR0NTTjs7QUFNQVYsWUFBVVksU0FBVixDRFhBTCxJQ1dBLEdEWE07QUFDSixTQUFPLEtBQUNJLE9BQVI7QUFDRTtBQ1lEOztBRFhELFNBQUNLLFFBQUQ7O0FBQ0EsU0FBQ0YsUUFBRDtBQUpJLEdDV047O0FBUUFkLFlBQVVZLFNBQVYsQ0RaQUksUUNZQSxHRFpVO0FBQ1IsUUFBRyxLQUFBUCxTQUFBLFFBQUg7QUFDRVEsYUFBT0MsWUFBUCxDQUFvQixLQUFDVCxTQUFyQjtBQUNBLFdBQUNBLFNBQUQsR0FBYSxJQUFiO0FDYUQ7QURoQk8sR0NZVjs7QUFPQVQsWUFBVVksU0FBVixDRGJBRSxRQ2FBLEdEYlU7QUFDUixTQUFDTCxTQUFELEdBQWFRLE9BQU9FLFVBQVAsQ0FBa0IsS0FBQ1gsSUFBbkIsRUFBeUIsS0FBQ0YsUUFBMUIsQ0FBYjtBQURRLEdDYVY7O0FBSUEsU0FBT04sU0FBUDtBQUVELENEdkRLOztBQXdDTixLQUFDQSxTQUFELEdBQWFBLFNBQWIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBRXhDQSxJQUFBb0IsaUJBQUE7QUFBQSxJQUFBQyxXQUFBO0FBQUEsSUFBQUMsYUFBQTtBQUFBLElBQUFyQixPQUFBLFVBQUFDLEVBQUEsRUFBQUMsRUFBQTtBQUFBO0FBQUEsV0FBQUQsR0FBQUUsS0FBQSxDQUFBRCxFQUFBLEVBQUFFLFNBQUE7QUFBQTtBQUFBOztBQUFBZ0IsY0FBYyxJQUFFLEVBQUYsR0FBSyxJQUFuQjtBQUNBRCxvQkFBb0IsS0FBRyxJQUF2Qjs7QUFFTUUsZ0JBQUE7QUFDUyxXQUFBQSxhQUFBO0FDS1gsU0FBS0MsTUFBTCxHQUFjdEIsS0FBSyxLQUFLc0IsTUFBVixFQUFrQixJQUFsQixDQUFkO0FBQ0EsU0FBS0MsU0FBTCxHQUFpQnZCLEtBQUssS0FBS3VCLFNBQVYsRUFBcUIsSUFBckIsQ0FBakI7QURMQSxTQUFDQyxRQUFELEdBQVlDLE9BQU9DLEVBQVAsRUFBWjtBQUNBQyxZQUFRQyxHQUFSLENBQVksK0JBQTZCLEtBQUNKLFFBQTFDO0FBQ0EsU0FBQ0ssT0FBRCxHQUNFO0FBQUFDLFdBQUssSUFBTDtBQUNBQyx5QkFBbUIsSUFEbkI7QUFFQUMsZ0JBQVU7QUFGVixLQURGO0FBSUEsU0FBQ3hCLFNBQUQsR0FBYSxJQUFJVCxTQUFKLENBQWNvQixpQkFBZCxDQUFiO0FBQ0EsU0FBQ1QsT0FBRCxHQUFXLEtBQVg7QUFDQU0sV0FBT2lCLE9BQVAsQ0FBZSxLQUFDVixTQUFoQjtBQVRXOztBQ21CYkYsZ0JBQWNWLFNBQWQsQ0RSQXVCLFNDUUEsR0RSVyxVQUFDTCxPQUFEO0FBQ1QsUUFBQU0sR0FBQTs7QUFBQSxRQUFHLEtBQUN6QixPQUFKO0FBQ0UsWUFBTSxJQUFJMEIsS0FBSixDQUFVLCtEQUFWLENBQU47QUNVRDs7QURUREMsTUFBRUMsTUFBRixDQUFTLEtBQUNULE9BQVYsRUFBbUJBLE9BQW5COztBQUVBLFNBQUNyQixTQUFELENBQVdILFFBQVgsSUFBQThCLE1BQUEsS0FBQU4sT0FBQSxDQUFBRSxpQkFBQSxZQUFBSSxHQUFBLEdBQW1EaEIsaUJBQW5EO0FBTFMsR0NRWDs7QUFTQUUsZ0JBQWNWLFNBQWQsQ0RUQTRCLE1DU0EsR0RUUTtBQUFHLFFBQUFKLEdBQUE7QUNXVCxXRFhTLElBQUlLLElBQUosQ0FBUyxDQUFFLElBQUlBLElBQUosRUFBRixJQUFnQixDQUFBTCxNQUFBLEtBQUFOLE9BQUEsQ0FBQUMsR0FBQSxZQUFBSyxHQUFBLEdBQWdCZixXQUFoQyxDQUFULENDV1Q7QURYTSxHQ1NSOztBQUtBQyxnQkFBY1YsU0FBZCxDRFpBWSxTQ1lBLEdEWlc7QUFDVCxTQUFDYixPQUFELEdBQVcsSUFBWDtBQUNBLFNBQUNGLFNBQUQsQ0FBV0ksS0FBWCxDQUFpQixLQUFDVSxNQUFsQjtBQUZTLEdDWVg7O0FBS0FELGdCQUFjVixTQUFkLENEWkFXLE1DWUEsR0RaUTtBQUNOO0FBQ0UxQixnQkFBVTZDLE1BQVYsQ0FBaUI7QUFDZmpCLGtCQUFVLEtBQUNBO0FBREksT0FBakIsRUFFRztBQUNEa0IsY0FBTTtBQUNKWixlQUFLLEtBQUNTLE1BQUQ7QUFERDtBQURMLE9BRkgsRUFNRztBQUNESSxlQUFPO0FBRE4sT0FOSDtBQURGO0FBV0UsV0FBQ25DLFNBQUQsQ0FBV0YsSUFBWDtBQ2FEO0FEekJLLEdDWVI7O0FBZ0JBZSxnQkFBY1YsU0FBZCxDRGJBcUIsUUNhQSxHRGJVLFVBQUNZLE1BQUQsRUFBU0MsS0FBVDtBQUNSLFFBQUcsS0FBQWhCLE9BQUEsQ0FBQUcsUUFBQSxRQUFIO0FBQ0UsYUFBTyxLQUFDSCxPQUFELENBQVNHLFFBQVQsQ0FBa0JZLE1BQWxCLEVBQTBCQyxLQUExQixDQUFQO0FBREY7QUFHRSxhQUFPQSxLQUFQO0FDY0Q7QURsQk8sR0NhVjs7QUFRQSxTQUFPeEIsYUFBUDtBQUVELENEakVLOztBQWdETixLQUFDQSxhQUFELEdBQWlCQSxhQUFqQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FFbkRBeUIsV0FBVyxJQUFJekIsYUFBSixFQUFYO0FBR0FMLE9BQU8rQixZQUFQLENBQW9CLFVBQUNDLFVBQUQ7QUFDbEIsTUFBQUMsR0FBQTtBQUFBRCxhQUFXRSxVQUFYLEdBQXdCekIsT0FBT0MsRUFBUCxFQUF4QjtBQUNBdUIsUUFBTSxJQUFJVCxJQUFKLEVBQU47QUFDQTVDLFlBQVV1RCxNQUFWLENBQ0U7QUFBQUMsU0FBS0osV0FBV0UsVUFBaEI7QUFDQTFCLGNBQVVzQixTQUFTdEIsUUFEbkI7QUFFQU0sU0FBS2dCLFNBQVNQLE1BQVQsRUFGTDtBQUdBYyxtQkFBZUwsV0FBV0ssYUFIMUI7QUFJQUMsWUFBUSxXQUpSO0FBS0FDLGlCQUFhTixHQUxiO0FBTUFPLGNBQVVQLEdBTlY7QUFPQVEsV0FBTyxFQVBQO0FBUUFiLFlBQVE7QUFSUixHQURGO0FBV0FJLGFBQVdVLE9BQVgsQ0FBbUI7QUFDakI5RCxjQUFVK0QsTUFBVixDQUFpQjtBQUFBUCxXQUFLSixXQUFXRTtBQUFoQixLQUFqQjtBQURGO0FBZEY7QUFxQkFsQyxPQUFPNEMsT0FBUCxDQUFlLElBQWYsRUFBcUI7QUFDbkIsTUFBQUMsVUFBQTtBQUFBQSxlQUFhLElBQWI7O0FBQ0EsTUFBRyxLQUFBakIsTUFBQSxRQUFIO0FBRUVpQixpQkFBYWYsU0FBU2QsUUFBVCxDQUFrQixLQUFDWSxNQUFuQixFQUEyQmtCLFNBQVNDLGNBQVQsQ0FBd0IsS0FBQ2YsVUFBRCxDQUFZdEIsRUFBcEMsQ0FBM0IsQ0FBYjtBQ0dEOztBREREOUIsWUFBVTZDLE1BQVYsQ0FDRTtBQUFBVyxTQUFLLEtBQUNKLFVBQUQsQ0FBWUU7QUFBakIsR0FERixFQUdFO0FBQUFSLFVBQ0U7QUFBQW1CLGtCQUFZQSxVQUFaO0FBQ0FqQixjQUFRLEtBQUNBLE1BRFQ7QUFFQVksZ0JBQVUsSUFBSWhCLElBQUo7QUFGVjtBQURGLEdBSEY7QUFPQSxPQUFDd0IsS0FBRDtBQWJGO0FBaUJBaEQsT0FBT2lELE9BQVAsQ0FDRTtBQUFBLGlCQUFlLFVBQUNSLEtBQUQ7QUFDYlMsVUFBTVQsS0FBTixFQUFhVSxNQUFNQyxHQUFuQjtBQUNBLFNBQUNDLE9BQUQ7QUFFQXpFLGNBQVU2QyxNQUFWLENBQ0U7QUFBQVcsV0FBSyxLQUFDSixVQUFELENBQVlFO0FBQWpCLEtBREYsRUFHRTtBQUFBUixZQUNFO0FBQUFFLGdCQUFRLEtBQUNBLE1BQVQ7QUFDQVksa0JBQVUsSUFBSWhCLElBQUosRUFEVjtBQUVBaUIsZUFBT0EsS0FGUDtBQUdBSCxnQkFBUTtBQUhSO0FBREYsS0FIRjtBQVNBLFdBQU8sSUFBUDtBQWJGO0FBQUEsQ0FERixFIiwiZmlsZSI6Ii9wYWNrYWdlcy8zc3RhY2tfcHJlc2VuY2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJwcmVzZW5jZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncHJlc2VuY2VzJyk7XG4iLCJjbGFzcyBIZWFydGJlYXRcbiAgY29uc3RydWN0b3I6IChAaW50ZXJ2YWwpLT5cbiAgICBAaGVhcnRiZWF0ID0gbnVsbFxuICAgIEBhY3Rpb24gPSBudWxsXG4gICAgQHN0YXJ0ZWQgPSBmYWxzZVxuXG4gIHN0YXJ0OiAoQGFjdGlvbiktPlxuICAgIGlmIEBzdGFydGVkXG4gICAgICByZXR1cm5cbiAgICBAc3RhcnRlZCA9IHRydWVcbiAgICBAX2VucXVldWUoKVxuICAgIHJldHVyblxuXG4gIHN0b3A6IC0+XG4gICAgQHN0YXJ0ZWQgPSBmYWxzZVxuICAgIEBhY3Rpb24gPSBudWxsXG4gICAgQF9kZXF1ZXVlKClcbiAgICByZXR1cm5cblxuICB0aWNrOiA9PlxuICAgIEBhY3Rpb24/KClcbiAgICByZXR1cm5cblxuICB0b2NrOiA9PlxuICAgIHVubGVzcyBAc3RhcnRlZFxuICAgICAgcmV0dXJuXG4gICAgQF9kZXF1ZXVlKClcbiAgICBAX2VucXVldWUoKVxuICAgIHJldHVyblxuXG4gIF9kZXF1ZXVlOiAtPlxuICAgIGlmIEBoZWFydGJlYXQ/XG4gICAgICBNZXRlb3IuY2xlYXJUaW1lb3V0KEBoZWFydGJlYXQpXG4gICAgICBAaGVhcnRiZWF0ID0gbnVsbFxuICAgIHJldHVyblxuXG4gIF9lbnF1ZXVlOiAtPlxuICAgIEBoZWFydGJlYXQgPSBNZXRlb3Iuc2V0VGltZW91dChAdGljaywgQGludGVydmFsKVxuICAgIHJldHVyblxuXG5ASGVhcnRiZWF0ID0gSGVhcnRiZWF0XG4iLCJ2YXIgSGVhcnRiZWF0LFxuICBiaW5kID0gZnVuY3Rpb24oZm4sIG1lKXsgcmV0dXJuIGZ1bmN0aW9uKCl7IHJldHVybiBmbi5hcHBseShtZSwgYXJndW1lbnRzKTsgfTsgfTtcblxuSGVhcnRiZWF0ID0gKGZ1bmN0aW9uKCkge1xuICBmdW5jdGlvbiBIZWFydGJlYXQoaW50ZXJ2YWwpIHtcbiAgICB0aGlzLmludGVydmFsID0gaW50ZXJ2YWw7XG4gICAgdGhpcy50b2NrID0gYmluZCh0aGlzLnRvY2ssIHRoaXMpO1xuICAgIHRoaXMudGljayA9IGJpbmQodGhpcy50aWNrLCB0aGlzKTtcbiAgICB0aGlzLmhlYXJ0YmVhdCA9IG51bGw7XG4gICAgdGhpcy5hY3Rpb24gPSBudWxsO1xuICAgIHRoaXMuc3RhcnRlZCA9IGZhbHNlO1xuICB9XG5cbiAgSGVhcnRiZWF0LnByb3RvdHlwZS5zdGFydCA9IGZ1bmN0aW9uKGFjdGlvbikge1xuICAgIHRoaXMuYWN0aW9uID0gYWN0aW9uO1xuICAgIGlmICh0aGlzLnN0YXJ0ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5zdGFydGVkID0gdHJ1ZTtcbiAgICB0aGlzLl9lbnF1ZXVlKCk7XG4gIH07XG5cbiAgSGVhcnRiZWF0LnByb3RvdHlwZS5zdG9wID0gZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5zdGFydGVkID0gZmFsc2U7XG4gICAgdGhpcy5hY3Rpb24gPSBudWxsO1xuICAgIHRoaXMuX2RlcXVldWUoKTtcbiAgfTtcblxuICBIZWFydGJlYXQucHJvdG90eXBlLnRpY2sgPSBmdW5jdGlvbigpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuYWN0aW9uID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuYWN0aW9uKCk7XG4gICAgfVxuICB9O1xuXG4gIEhlYXJ0YmVhdC5wcm90b3R5cGUudG9jayA9IGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy5zdGFydGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuX2RlcXVldWUoKTtcbiAgICB0aGlzLl9lbnF1ZXVlKCk7XG4gIH07XG5cbiAgSGVhcnRiZWF0LnByb3RvdHlwZS5fZGVxdWV1ZSA9IGZ1bmN0aW9uKCkge1xuICAgIGlmICh0aGlzLmhlYXJ0YmVhdCAhPSBudWxsKSB7XG4gICAgICBNZXRlb3IuY2xlYXJUaW1lb3V0KHRoaXMuaGVhcnRiZWF0KTtcbiAgICAgIHRoaXMuaGVhcnRiZWF0ID0gbnVsbDtcbiAgICB9XG4gIH07XG5cbiAgSGVhcnRiZWF0LnByb3RvdHlwZS5fZW5xdWV1ZSA9IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMuaGVhcnRiZWF0ID0gTWV0ZW9yLnNldFRpbWVvdXQodGhpcy50aWNrLCB0aGlzLmludGVydmFsKTtcbiAgfTtcblxuICByZXR1cm4gSGVhcnRiZWF0O1xuXG59KSgpO1xuXG50aGlzLkhlYXJ0YmVhdCA9IEhlYXJ0YmVhdDtcbiIsIkRFRkFVTFRfVFRMID0gNSo2MCoxMDAwXG5ERUZBVUxUX0hFQVJUQkVBVCA9IDYwKjEwMDBcblxuY2xhc3MgU2VydmVyTW9uaXRvclxuICBjb25zdHJ1Y3RvcjogLT5cbiAgICBAc2VydmVySWQgPSBSYW5kb20uaWQoKVxuICAgIGNvbnNvbGUubG9nKFwiUHJlc2VuY2Ugc3RhcnRlZCBzZXJ2ZXJJZD0je0BzZXJ2ZXJJZH1cIilcbiAgICBAb3B0aW9ucyA9XG4gICAgICB0dGw6IG51bGxcbiAgICAgIGhlYXJ0YmVhdEludGVydmFsOiBudWxsXG4gICAgICBjaGVja3N1bTogbnVsbFxuICAgIEBoZWFydGJlYXQgPSBuZXcgSGVhcnRiZWF0KERFRkFVTFRfSEVBUlRCRUFUKVxuICAgIEBzdGFydGVkID0gZmFsc2VcbiAgICBNZXRlb3Iuc3RhcnR1cChAb25TdGFydHVwKVxuXG4gIGNvbmZpZ3VyZTogKG9wdGlvbnMpLT5cbiAgICBpZiBAc3RhcnRlZFxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTXVzdCBjb25maWd1cmUgUHJlc2VuY2Ugb24gdGhlIHNlcnZlciBiZWZvcmUgTWV0ZW9yLnN0YXJ0dXAoKVwiKVxuICAgIF8uZXh0ZW5kKEBvcHRpb25zLCBvcHRpb25zKVxuXG4gICAgQGhlYXJ0YmVhdC5pbnRlcnZhbCA9IEBvcHRpb25zLmhlYXJ0YmVhdEludGVydmFsID8gREVGQVVMVF9IRUFSVEJFQVRcbiAgICByZXR1cm5cblxuICBnZXRUdGw6IC0+IG5ldyBEYXRlKCsobmV3IERhdGUoKSkgKyAoQG9wdGlvbnMudHRsID8gREVGQVVMVF9UVEwpKVxuXG4gIG9uU3RhcnR1cDogPT5cbiAgICBAc3RhcnRlZCA9IHRydWVcbiAgICBAaGVhcnRiZWF0LnN0YXJ0KEBvbkJlYXQpXG4gICAgcmV0dXJuXG5cbiAgb25CZWF0OiA9PlxuICAgIHRyeVxuICAgICAgcHJlc2VuY2VzLnVwZGF0ZSh7XG4gICAgICAgIHNlcnZlcklkOiBAc2VydmVySWRcbiAgICAgIH0sIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIHR0bDogQGdldFR0bCgpXG4gICAgICAgIH1cbiAgICAgIH0sIHtcbiAgICAgICAgbXVsdGk6IHRydWVcbiAgICAgIH0pXG4gICAgZmluYWxseVxuICAgICAgQGhlYXJ0YmVhdC50b2NrKClcbiAgICByZXR1cm5cblxuICBjaGVja3N1bTogKHVzZXJJZCwgdmFsdWUpLT5cbiAgICBpZiBAb3B0aW9ucy5jaGVja3N1bT9cbiAgICAgIHJldHVybiBAb3B0aW9ucy5jaGVja3N1bSh1c2VySWQsIHZhbHVlKVxuICAgIGVsc2VcbiAgICAgIHJldHVybiB2YWx1ZVxuXG5AU2VydmVyTW9uaXRvciA9IFNlcnZlck1vbml0b3JcbiIsInZhciBERUZBVUxUX0hFQVJUQkVBVCwgREVGQVVMVF9UVEwsIFNlcnZlck1vbml0b3IsXG4gIGJpbmQgPSBmdW5jdGlvbihmbiwgbWUpeyByZXR1cm4gZnVuY3Rpb24oKXsgcmV0dXJuIGZuLmFwcGx5KG1lLCBhcmd1bWVudHMpOyB9OyB9O1xuXG5ERUZBVUxUX1RUTCA9IDUgKiA2MCAqIDEwMDA7XG5cbkRFRkFVTFRfSEVBUlRCRUFUID0gNjAgKiAxMDAwO1xuXG5TZXJ2ZXJNb25pdG9yID0gKGZ1bmN0aW9uKCkge1xuICBmdW5jdGlvbiBTZXJ2ZXJNb25pdG9yKCkge1xuICAgIHRoaXMub25CZWF0ID0gYmluZCh0aGlzLm9uQmVhdCwgdGhpcyk7XG4gICAgdGhpcy5vblN0YXJ0dXAgPSBiaW5kKHRoaXMub25TdGFydHVwLCB0aGlzKTtcbiAgICB0aGlzLnNlcnZlcklkID0gUmFuZG9tLmlkKCk7XG4gICAgY29uc29sZS5sb2coXCJQcmVzZW5jZSBzdGFydGVkIHNlcnZlcklkPVwiICsgdGhpcy5zZXJ2ZXJJZCk7XG4gICAgdGhpcy5vcHRpb25zID0ge1xuICAgICAgdHRsOiBudWxsLFxuICAgICAgaGVhcnRiZWF0SW50ZXJ2YWw6IG51bGwsXG4gICAgICBjaGVja3N1bTogbnVsbFxuICAgIH07XG4gICAgdGhpcy5oZWFydGJlYXQgPSBuZXcgSGVhcnRiZWF0KERFRkFVTFRfSEVBUlRCRUFUKTtcbiAgICB0aGlzLnN0YXJ0ZWQgPSBmYWxzZTtcbiAgICBNZXRlb3Iuc3RhcnR1cCh0aGlzLm9uU3RhcnR1cCk7XG4gIH1cblxuICBTZXJ2ZXJNb25pdG9yLnByb3RvdHlwZS5jb25maWd1cmUgPSBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgdmFyIHJlZjtcbiAgICBpZiAodGhpcy5zdGFydGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNdXN0IGNvbmZpZ3VyZSBQcmVzZW5jZSBvbiB0aGUgc2VydmVyIGJlZm9yZSBNZXRlb3Iuc3RhcnR1cCgpXCIpO1xuICAgIH1cbiAgICBfLmV4dGVuZCh0aGlzLm9wdGlvbnMsIG9wdGlvbnMpO1xuICAgIHRoaXMuaGVhcnRiZWF0LmludGVydmFsID0gKHJlZiA9IHRoaXMub3B0aW9ucy5oZWFydGJlYXRJbnRlcnZhbCkgIT0gbnVsbCA/IHJlZiA6IERFRkFVTFRfSEVBUlRCRUFUO1xuICB9O1xuXG4gIFNlcnZlck1vbml0b3IucHJvdG90eXBlLmdldFR0bCA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciByZWY7XG4gICAgcmV0dXJuIG5ldyBEYXRlKCsobmV3IERhdGUoKSkgKyAoKHJlZiA9IHRoaXMub3B0aW9ucy50dGwpICE9IG51bGwgPyByZWYgOiBERUZBVUxUX1RUTCkpO1xuICB9O1xuXG4gIFNlcnZlck1vbml0b3IucHJvdG90eXBlLm9uU3RhcnR1cCA9IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMuc3RhcnRlZCA9IHRydWU7XG4gICAgdGhpcy5oZWFydGJlYXQuc3RhcnQodGhpcy5vbkJlYXQpO1xuICB9O1xuXG4gIFNlcnZlck1vbml0b3IucHJvdG90eXBlLm9uQmVhdCA9IGZ1bmN0aW9uKCkge1xuICAgIHRyeSB7XG4gICAgICBwcmVzZW5jZXMudXBkYXRlKHtcbiAgICAgICAgc2VydmVySWQ6IHRoaXMuc2VydmVySWRcbiAgICAgIH0sIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIHR0bDogdGhpcy5nZXRUdGwoKVxuICAgICAgICB9XG4gICAgICB9LCB7XG4gICAgICAgIG11bHRpOiB0cnVlXG4gICAgICB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5oZWFydGJlYXQudG9jaygpO1xuICAgIH1cbiAgfTtcblxuICBTZXJ2ZXJNb25pdG9yLnByb3RvdHlwZS5jaGVja3N1bSA9IGZ1bmN0aW9uKHVzZXJJZCwgdmFsdWUpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLmNoZWNrc3VtICE9IG51bGwpIHtcbiAgICAgIHJldHVybiB0aGlzLm9wdGlvbnMuY2hlY2tzdW0odXNlcklkLCB2YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIFNlcnZlck1vbml0b3I7XG5cbn0pKCk7XG5cbnRoaXMuU2VydmVyTW9uaXRvciA9IFNlcnZlck1vbml0b3I7XG4iLCJQcmVzZW5jZSA9IG5ldyBTZXJ2ZXJNb25pdG9yKClcblxuIyBvbiBhbnkgY29ubmVjdGlvbiAtIGxvZyB0aGUgY2xpZW50IGluIHByZXNlbmNlcywgYW5kIHNldCB0aGUgb25DbG9zZSBoYW5kbGVyXG5NZXRlb3Iub25Db25uZWN0aW9uIChjb25uZWN0aW9uKS0+XG4gIGNvbm5lY3Rpb24uc2Vzc2lvbktleSA9IFJhbmRvbS5pZCgpXG4gIG5vdyA9IG5ldyBEYXRlKClcbiAgcHJlc2VuY2VzLmluc2VydFxuICAgIF9pZDogY29ubmVjdGlvbi5zZXNzaW9uS2V5XG4gICAgc2VydmVySWQ6IFByZXNlbmNlLnNlcnZlcklkXG4gICAgdHRsOiBQcmVzZW5jZS5nZXRUdGwoKVxuICAgIGNsaWVudEFkZHJlc3M6IGNvbm5lY3Rpb24uY2xpZW50QWRkcmVzc1xuICAgIHN0YXR1czogJ2Nvbm5lY3RlZCdcbiAgICBjb25uZWN0ZWRBdDogbm93XG4gICAgbGFzdFNlZW46IG5vd1xuICAgIHN0YXRlOiB7fVxuICAgIHVzZXJJZDogbnVsbFxuXG4gIGNvbm5lY3Rpb24ub25DbG9zZSAtPlxuICAgIHByZXNlbmNlcy5yZW1vdmUoX2lkOiBjb25uZWN0aW9uLnNlc3Npb25LZXkpXG4gICAgcmV0dXJuXG4gIHJldHVyblxuXG4jIHRoaXMgYXV0b3B1Ymxpc2ggd2lsbCBiZSBjYWxsZWQgZWFjaCB0aW1lIHRoZSB1c2VyIGxvZ3Mgb3V0IC8gaW5cbiMgaXQgc2hvdWxkIGFsc28gYmUgdGhlIGZpcnN0IGNhbGwgYWZ0ZXIgdGhlIE1ldGVvci5vbkNvbm5lY3Rpb24gY2FsbFxuTWV0ZW9yLnB1Ymxpc2ggbnVsbCwgLT5cbiAgbG9naW5Ub2tlbiA9IG51bGxcbiAgaWYgQHVzZXJJZD9cbiAgICAjIFVzZSB1c2VyLWRlZmluZWQgZGlnZXN0IGlmIG9wdGlvbiBwcm92aWRlZFxuICAgIGxvZ2luVG9rZW4gPSBQcmVzZW5jZS5jaGVja3N1bShAdXNlcklkLCBBY2NvdW50cy5fZ2V0TG9naW5Ub2tlbihAY29ubmVjdGlvbi5pZCkpXG5cbiAgcHJlc2VuY2VzLnVwZGF0ZVxuICAgIF9pZDogQGNvbm5lY3Rpb24uc2Vzc2lvbktleVxuICAsXG4gICAgJHNldDpcbiAgICAgIGxvZ2luVG9rZW46IGxvZ2luVG9rZW5cbiAgICAgIHVzZXJJZDogQHVzZXJJZFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgQHJlYWR5KClcbiAgcmV0dXJuXG5cbiMgYWxsb3cgdGhlIGNsaWVudCB0byBwcm92aWRlIHN0YXRlZnVsIGluZm9ybWF0aW9uIGFib3V0IGl0c2VsZlxuTWV0ZW9yLm1ldGhvZHNcbiAgJ3NldFByZXNlbmNlJzogKHN0YXRlKS0+XG4gICAgY2hlY2soc3RhdGUsIE1hdGNoLkFueSlcbiAgICBAdW5ibG9jaygpXG5cbiAgICBwcmVzZW5jZXMudXBkYXRlXG4gICAgICBfaWQ6IEBjb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgICAsXG4gICAgICAkc2V0OlxuICAgICAgICB1c2VySWQ6IEB1c2VySWRcbiAgICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgICAgICAgc3RhdGU6IHN0YXRlXG4gICAgICAgIHN0YXR1czogJ29ubGluZSdcblxuICAgIHJldHVybiBudWxsXG4iLCIgICAgICAgICAgICAgXG5cblByZXNlbmNlID0gbmV3IFNlcnZlck1vbml0b3IoKTtcblxuTWV0ZW9yLm9uQ29ubmVjdGlvbihmdW5jdGlvbihjb25uZWN0aW9uKSB7XG4gIHZhciBub3c7XG4gIGNvbm5lY3Rpb24uc2Vzc2lvbktleSA9IFJhbmRvbS5pZCgpO1xuICBub3cgPSBuZXcgRGF0ZSgpO1xuICBwcmVzZW5jZXMuaW5zZXJ0KHtcbiAgICBfaWQ6IGNvbm5lY3Rpb24uc2Vzc2lvbktleSxcbiAgICBzZXJ2ZXJJZDogUHJlc2VuY2Uuc2VydmVySWQsXG4gICAgdHRsOiBQcmVzZW5jZS5nZXRUdGwoKSxcbiAgICBjbGllbnRBZGRyZXNzOiBjb25uZWN0aW9uLmNsaWVudEFkZHJlc3MsXG4gICAgc3RhdHVzOiAnY29ubmVjdGVkJyxcbiAgICBjb25uZWN0ZWRBdDogbm93LFxuICAgIGxhc3RTZWVuOiBub3csXG4gICAgc3RhdGU6IHt9LFxuICAgIHVzZXJJZDogbnVsbFxuICB9KTtcbiAgY29ubmVjdGlvbi5vbkNsb3NlKGZ1bmN0aW9uKCkge1xuICAgIHByZXNlbmNlcy5yZW1vdmUoe1xuICAgICAgX2lkOiBjb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgICB9KTtcbiAgfSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2gobnVsbCwgZnVuY3Rpb24oKSB7XG4gIHZhciBsb2dpblRva2VuO1xuICBsb2dpblRva2VuID0gbnVsbDtcbiAgaWYgKHRoaXMudXNlcklkICE9IG51bGwpIHtcbiAgICBsb2dpblRva2VuID0gUHJlc2VuY2UuY2hlY2tzdW0odGhpcy51c2VySWQsIEFjY291bnRzLl9nZXRMb2dpblRva2VuKHRoaXMuY29ubmVjdGlvbi5pZCkpO1xuICB9XG4gIHByZXNlbmNlcy51cGRhdGUoe1xuICAgIF9pZDogdGhpcy5jb25uZWN0aW9uLnNlc3Npb25LZXlcbiAgfSwge1xuICAgICRzZXQ6IHtcbiAgICAgIGxvZ2luVG9rZW46IGxvZ2luVG9rZW4sXG4gICAgICB1c2VySWQ6IHRoaXMudXNlcklkLFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKClcbiAgICB9XG4gIH0pO1xuICB0aGlzLnJlYWR5KCk7XG59KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnc2V0UHJlc2VuY2UnOiBmdW5jdGlvbihzdGF0ZSkge1xuICAgIGNoZWNrKHN0YXRlLCBNYXRjaC5BbnkpO1xuICAgIHRoaXMudW5ibG9jaygpO1xuICAgIHByZXNlbmNlcy51cGRhdGUoe1xuICAgICAgX2lkOiB0aGlzLmNvbm5lY3Rpb24uc2Vzc2lvbktleVxuICAgIH0sIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgdXNlcklkOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKCksXG4gICAgICAgIHN0YXRlOiBzdGF0ZSxcbiAgICAgICAgc3RhdHVzOiAnb25saW5lJ1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59KTtcbiJdfQ==
