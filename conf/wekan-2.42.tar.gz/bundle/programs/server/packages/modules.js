(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var meteorInstall = Package['modules-runtime'].meteorInstall;

var require = meteorInstall({"node_modules":{"meteor":{"modules":{"server.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/modules/server.js                                                                   //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
require("./install-packages.js");
require("./process.js");
require("./reify.js");

//////////////////////////////////////////////////////////////////////////////////////////////////

},"install-packages.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/modules/install-packages.js                                                         //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
function install(name, mainModule) {
  var meteorDir = {};

  // Given a package name <name>, install a stub module in the
  // /node_modules/meteor directory called <name>.js, so that
  // require.resolve("meteor/<name>") will always return
  // /node_modules/meteor/<name>.js instead of something like
  // /node_modules/meteor/<name>/index.js, in the rare but possible event
  // that the package contains a file called index.js (#6590).

  if (typeof mainModule === "string") {
    // Set up an alias from /node_modules/meteor/<package>.js to the main
    // module, e.g. meteor/<package>/index.js.
    meteorDir[name + ".js"] = mainModule;
  } else {
    // back compat with old Meteor packages
    meteorDir[name + ".js"] = function (r, e, module) {
      module.exports = Package[name];
    };
  }

  meteorInstall({
    node_modules: {
      meteor: meteorDir
    }
  });
}

// This file will be modified during computeJsOutputFilesMap to include
// install(<name>) calls for every Meteor package.

install("meteor");
install("meteor-base");
install("ecmascript-runtime");
install("modules-runtime");
install("modules", "meteor/modules/server.js");
install("ecmascript-runtime-server", "meteor/ecmascript-runtime-server/runtime.js");
install("babel-compiler");
install("ecmascript");
install("stylus");
install("standard-minifier-css");
install("standard-minifier-js");
install("jquery");
install("tracker");
install("underscore");
install("base64");
install("es5-shim", "meteor/es5-shim/server.js");
install("promise", "meteor/promise/server.js");
install("babel-runtime", "meteor/babel-runtime/babel-runtime.js");
install("ejson", "meteor/ejson/ejson.js");
install("check", "meteor/check/match.js");
install("id-map");
install("random");
install("mongo-id");
install("diff-sequence");
install("observe-sequence");
install("reactive-var");
install("ordered-dict");
install("deps");
install("htmljs");
install("blaze");
install("mquandalle:jade");
install("aldeed:simple-schema");
install("npm-mongo");
install("geojson-utils", "meteor/geojson-utils/main.js");
install("minimongo", "meteor/minimongo/minimongo_server.js");
install("retry");
install("callback-hook");
install("ddp-common");
install("ddp-client", "meteor/ddp-client/namespace.js");
install("rate-limit");
install("ddp-rate-limiter");
install("logging");
install("routepolicy");
install("boilerplate-generator", "meteor/boilerplate-generator/generator.js");
install("webapp-hashing");
install("webapp", "meteor/webapp/webapp_server.js");
install("audit-argument-checks");
install("ddp-server");
install("ddp");
install("allow-deny");
install("binary-heap");
install("mongo");
install("raix:eventemitter");
install("aldeed:collection2-core");
install("aldeed:schema-index");
install("aldeed:schema-deny");
install("aldeed:collection2");
install("cfs:standard-packages");
install("cottz:publish-relations", "meteor/cottz:publish-relations/lib/server/index.js");
install("dburles:collection-helpers");
install("idmontie:migrations");
install("accounts-base", "meteor/accounts-base/server_main.js");
install("matb33:collection-hooks");
install("livedata");
install("mongo-livedata");
install("reload");
install("autoupdate");
install("meteor-platform");
install("meteorhacks:collection-utils");
install("meteorhacks:aggregate");
install("session");
install("ui");
install("spacebars");
install("templating-compiler");
install("templating-runtime");
install("templating");
install("matteodem:easy-search");
install("mquandalle:collection-mutations");
install("kenton:accounts-sandstorm");
install("service-configuration");
install("url");
install("http");
install("useraccounts:core");
install("reactive-dict", "meteor/reactive-dict/migration.js");
install("kadira:flow-router");
install("kadira:blaze-layout");
install("coffeescript");
install("softwarerero:accounts-t9n");
install("useraccounts:flow-routing");
install("useraccounts:unstyled");
install("yasaricli:slugify");
install("sha");
install("npm-bcrypt", "meteor/npm-bcrypt/wrapper.js");
install("srp");
install("email");
install("accounts-password");
install("wekan:wekan-ldap", "meteor/wekan:wekan-ldap/server/index.js");
install("wekan:accounts-cas");
install("localstorage");
install("oauth");
install("accounts-oauth");
install("oauth2");
install("wekan-oidc");
install("wekan-accounts-oidc");
install("3stack:presence");
install("alethes:pages");
install("zimme:active-route");
install("arillo:flow-router-helpers");
install("kadira:dochead");
install("meteorhacks:picker");
install("meteorhacks:subs-manager");
install("mquandalle:autofocus");
install("ongoworks:speakingurl");
install("raix:handlebar-helpers");
install("meteorspark:util");
install("cfs:http-methods");
install("tap:i18n");
install("fortawesome:fontawesome");
install("mousetrap:mousetrap");
install("mquandalle:jquery-textcomplete");
install("mquandalle:jquery-ui-drag-drop-sort");
install("mquandalle:mousetrap-bindglobal");
install("peerlibrary:assert");
install("peerlibrary:reactive-field");
install("peerlibrary:computed-field");
install("peerlibrary:base-component");
install("peerlibrary:blaze-components");
install("perak:markdown");
install("templates:tabs");
install("verron:autosize");
install("simple:json-routes");
install("rajit:bootstrap3-datepicker");
install("shell-server", "meteor/shell-server/main.js");
install("simple:authenticate-user-by-token");
install("simple:rest-bearer-token-parser");
install("simple:rest-json-error-handler");
install("simple:rest-accounts-password");
install("horka:swipebox");
install("dynamic-import", "meteor/dynamic-import/server.js");
install("staringatlights:inject-data");
install("meteorhacks:meteorx");
install("staringatlights:fast-render");
install("mixmax:smart-disconnect");
install("cfs:base-package");
install("cfs:storage-adapter");
install("cfs:gridfs");
install("eluck:accounts-lockout");
install("rzymek:fullcalendar");
install("momentjs:moment");
install("browser-policy-common");
install("browser-policy-framing", "meteor/browser-policy-framing/browser-policy-framing.js");
install("mquandalle:moment");
install("msavin:usercache");
install("wekan-scrollbar");
install("mquandalle:perfect-scrollbar");
install("mdg:meteor-apm-agent");
install("meteorhacks:unblock");
install("hot-code-push");
install("cfs:data-man");
install("cfs:file");
install("cfs:tempstore");
install("cfs:http-publish");
install("cfs:access-point");
install("cfs:reactive-property");
install("cfs:reactive-list");
install("cfs:power-queue");
install("cfs:upload-http");
install("cfs:collection");
install("cfs:collection-filters");
install("cfs:worker");
install("mdg:validation-error");

//////////////////////////////////////////////////////////////////////////////////////////////////

},"process.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/modules/process.js                                                                  //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
if (! global.process) {
  try {
    // The application can run `npm install process` to provide its own
    // process stub; otherwise this module will provide a partial stub.
    global.process = require("process");
  } catch (missing) {
    global.process = {};
  }
}

var proc = global.process;

if (Meteor.isServer) {
  // Make require("process") work on the server in all versions of Node.
  meteorInstall({
    node_modules: {
      "process.js": function (r, e, module) {
        module.exports = proc;
      }
    }
  });
} else {
  proc.platform = "browser";
  proc.nextTick = proc.nextTick || Meteor._setImmediate;
}

if (typeof proc.env !== "object") {
  proc.env = {};
}

var hasOwn = Object.prototype.hasOwnProperty;
for (var key in meteorEnv) {
  if (hasOwn.call(meteorEnv, key)) {
    proc.env[key] = meteorEnv[key];
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////

},"reify.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/modules/reify.js                                                                    //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
var Module = module.constructor;
var Mp = Module.prototype;
require("reify/lib/runtime").enable(Mp);
Mp.importSync = Mp.importSync || Mp.import;
Mp.import = Mp.import || Mp.importSync;

//////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"reify":{"lib":{"runtime":{"index.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// node_modules/meteor/modules/node_modules/reify/lib/runtime/index.js                          //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
"use strict";

// This module should be compatible with PhantomJS v1, just like the other files
// in reify/lib/runtime. Node 4+ features like const/let and arrow functions are
// not acceptable here, and importing any npm packages should be contemplated
// with extreme skepticism.

var utils = require("./utils.js");
var Entry = require("./entry.js");

// The exports.enable method can be used to enable the Reify runtime for
// specific module objects, or for Module.prototype (where implemented),
// to make the runtime available throughout the entire module system.
exports.enable = function (mod) {
  if (typeof mod.export !== "function" ||
      typeof mod.importSync !== "function") {
    mod.export = moduleExport;
    mod.exportDefault = moduleExportDefault;
    mod.runSetters = runSetters;
    mod.watch = moduleWatch;

    // Used for copying the properties of a namespace object to
    // mod.exports to implement `export * from "module"` syntax.
    mod.makeNsSetter = moduleMakeNsSetter;

    // To be deprecated:
    mod.runModuleSetters = runSetters;
    mod.importSync = importSync;

    return true;
  }

  return false;
};

function moduleWatch(exported, setters, key) {
  utils.setESModule(this.exports);
  Entry.getOrCreate(this.exports, this);

  if (utils.isObject(setters)) {
    Entry.getOrCreate(exported).addSetters(this, setters, key);
  }
}

// If key is provided, it will be used to identify the given setters so
// that they can be replaced if module.importSync is called again with the
// same key. This avoids potential memory leaks from import declarations
// inside loops. The compiler generates these keys automatically (and
// deterministically) when compiling nested import declarations.
function importSync(id, setters, key) {
  return this.watch(this.require(id), setters, key);
}

// Register getter functions for local variables in the scope of an export
// statement. Pass true as the second argument to indicate that the getter
// functions always return the same values.
function moduleExport(getters, constant) {
  utils.setESModule(this.exports);
  var entry = Entry.getOrCreate(this.exports, this);
  entry.addGetters(getters, constant);
  if (this.loaded) {
    // If the module has already been evaluated, then we need to trigger
    // another round of entry.runSetters calls, which begins by calling
    // entry.runModuleGetters(module).
    entry.runSetters();
  }
}

// Register a getter function that always returns the given value.
function moduleExportDefault(value) {
  return this.export({
    default: function () {
      return value;
    }
  }, true);
}

// Platform-specific code should find a way to call this method whenever
// the module system is about to return module.exports from require. This
// might happen more than once per module, in case of dependency cycles,
// so we want Module.prototype.runSetters to run each time.
function runSetters(valueToPassThrough) {
  var entry = Entry.get(this.exports);
  if (entry !== null) {
    entry.runSetters();
  }

  if (this.loaded) {
    // If this module has finished loading, then we must create an Entry
    // object here, so that we can add this module to entry.ownerModules
    // by passing it as the second argument to Entry.getOrCreate.
    Entry.getOrCreate(this.exports, this);
  }

  // Assignments to exported local variables get wrapped with calls to
  // module.runSetters, so module.runSetters returns the
  // valueToPassThrough parameter to allow the value of the original
  // expression to pass through. For example,
  //
  //   export var a = 1;
  //   console.log(a += 3);
  //
  // becomes
  //
  //   module.export("a", () => a);
  //   var a = 1;
  //   console.log(module.runSetters(a += 3));
  //
  // This ensures module.runSetters runs immediately after the assignment,
  // and does not interfere with the larger computation.
  return valueToPassThrough;
}

// Returns a function that takes a namespace object and copies the
// properties of the namespace to module.exports, excluding any "default"
// property, which is useful for implementing `export * from "module"`.
function moduleMakeNsSetter() {
  var module = this;
  // Discussion of why the "default" property is skipped:
  // https://github.com/tc39/ecma262/issues/948
  return function (namespace) {
    Object.keys(namespace).forEach(function (key) {
      if (key !== "default") {
        utils.copyKey(key, module.exports, namespace);
      }
    });
  };
}

//////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},"babel-runtime":{"helpers":{"extends.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// node_modules/babel-runtime/helpers/extends.js                                                //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
"use strict";

exports.__esModule = true;

var _assign = require("../core-js/object/assign");

var _assign2 = _interopRequireDefault(_assign);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _assign2.default || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};
//////////////////////////////////////////////////////////////////////////////////////////////////

}},"package.json":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// node_modules/babel-runtime/package.json                                                      //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
module.exports = {
  "_args": [
    [
      "babel-runtime@6.26.0",
      "/root/repos/wekan"
    ]
  ],
  "_from": "babel-runtime@6.26.0",
  "_id": "babel-runtime@6.26.0",
  "_inBundle": false,
  "_integrity": "sha1-llxwWGaOgrVde/4E/yM3vItWR/4=",
  "_location": "/babel-runtime",
  "_phantomChildren": {},
  "_requested": {
    "type": "version",
    "registry": true,
    "raw": "babel-runtime@6.26.0",
    "name": "babel-runtime",
    "escapedName": "babel-runtime",
    "rawSpec": "6.26.0",
    "saveSpec": null,
    "fetchSpec": "6.26.0"
  },
  "_requiredBy": [
    "/"
  ],
  "_resolved": "https://registry.npmjs.org/babel-runtime/-/babel-runtime-6.26.0.tgz",
  "_spec": "6.26.0",
  "_where": "/root/repos/wekan",
  "author": {
    "name": "Sebastian McKenzie",
    "email": "sebmck@gmail.com"
  },
  "dependencies": {
    "core-js": "^2.4.0",
    "regenerator-runtime": "^0.11.0"
  },
  "description": "babel selfContained runtime",
  "devDependencies": {
    "babel-helpers": "^6.22.0",
    "babel-plugin-transform-runtime": "^6.23.0"
  },
  "license": "MIT",
  "name": "babel-runtime",
  "repository": {
    "type": "git",
    "url": "https://github.com/babel/babel/tree/master/packages/babel-runtime"
  },
  "version": "6.26.0"
};

//////////////////////////////////////////////////////////////////////////////////////////////////

},"regenerator":{"index.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// node_modules/babel-runtime/regenerator/index.js                                              //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
module.exports = require("regenerator-runtime");

//////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/modules/server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package.modules = exports, {
  meteorInstall: meteorInstall
});

})();
