(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:jquery-ui-drag-drop-sort'] = {};

})();
