(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"mquandalle:collection-mutations":{"mutations.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mquandalle_collection-mutations/mutations.js             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Mongo.Collection.prototype.mutations = function (mutations) {
  const collection = this;
  collection.helpers(_.chain(mutations).map((action, name) => {
    return [name, function (...args) {
      const mutation = action.apply(this, args);

      if (mutation) {
        collection.update(this._id, mutation);
      }
    }];
  }).object().value());
};
///////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/mquandalle:collection-mutations/mutations.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:collection-mutations'] = {};

})();

//# sourceURL=meteor://💻app/packages/mquandalle_collection-mutations.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbXF1YW5kYWxsZTpjb2xsZWN0aW9uLW11dGF0aW9ucy9tdXRhdGlvbnMuanMiXSwibmFtZXMiOlsiTW9uZ28iLCJDb2xsZWN0aW9uIiwicHJvdG90eXBlIiwibXV0YXRpb25zIiwiY29sbGVjdGlvbiIsImhlbHBlcnMiLCJfIiwiY2hhaW4iLCJtYXAiLCJhY3Rpb24iLCJuYW1lIiwiYXJncyIsIm11dGF0aW9uIiwiYXBwbHkiLCJ1cGRhdGUiLCJfaWQiLCJvYmplY3QiLCJ2YWx1ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNQyxVQUFOLENBQWlCQyxTQUFqQixDQUEyQkMsU0FBM0IsR0FBdUMsVUFBU0EsU0FBVCxFQUFvQjtBQUN6RCxRQUFNQyxhQUFhLElBQW5CO0FBRUFBLGFBQVdDLE9BQVgsQ0FBbUJDLEVBQUVDLEtBQUYsQ0FBUUosU0FBUixFQUFtQkssR0FBbkIsQ0FBdUIsQ0FBQ0MsTUFBRCxFQUFTQyxJQUFULEtBQWtCO0FBQzFELFdBQU8sQ0FBQ0EsSUFBRCxFQUFPLFVBQVMsR0FBR0MsSUFBWixFQUFrQjtBQUM5QixZQUFNQyxXQUFXSCxPQUFPSSxLQUFQLENBQWEsSUFBYixFQUFtQkYsSUFBbkIsQ0FBakI7O0FBQ0EsVUFBSUMsUUFBSixFQUFjO0FBQ1pSLG1CQUFXVSxNQUFYLENBQWtCLEtBQUtDLEdBQXZCLEVBQTRCSCxRQUE1QjtBQUNEO0FBQ0YsS0FMTSxDQUFQO0FBTUQsR0FQa0IsRUFPaEJJLE1BUGdCLEdBT1BDLEtBUE8sRUFBbkI7QUFRRCxDQVhELEMiLCJmaWxlIjoiL3BhY2thZ2VzL21xdWFuZGFsbGVfY29sbGVjdGlvbi1tdXRhdGlvbnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJNb25nby5Db2xsZWN0aW9uLnByb3RvdHlwZS5tdXRhdGlvbnMgPSBmdW5jdGlvbihtdXRhdGlvbnMpIHtcbiAgY29uc3QgY29sbGVjdGlvbiA9IHRoaXM7XG5cbiAgY29sbGVjdGlvbi5oZWxwZXJzKF8uY2hhaW4obXV0YXRpb25zKS5tYXAoKGFjdGlvbiwgbmFtZSkgPT4ge1xuICAgIHJldHVybiBbbmFtZSwgZnVuY3Rpb24oLi4uYXJncykge1xuICAgICAgY29uc3QgbXV0YXRpb24gPSBhY3Rpb24uYXBwbHkodGhpcywgYXJncyk7XG4gICAgICBpZiAobXV0YXRpb24pIHtcbiAgICAgICAgY29sbGVjdGlvbi51cGRhdGUodGhpcy5faWQsIG11dGF0aW9uKTtcbiAgICAgIH1cbiAgICB9XTtcbiAgfSkub2JqZWN0KCkudmFsdWUoKSk7XG59O1xuIl19
